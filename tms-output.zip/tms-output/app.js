(function() {
  'use strict';

  var globals = typeof global === 'undefined' ? self : global;
  if (typeof globals.require === 'function') return;

  var modules = {};
  var cache = {};
  var aliases = {};
  var has = {}.hasOwnProperty;

  var expRe = /^\.\.?(\/|$)/;
  var expand = function(root, name) {
    var results = [], part;
    var parts = (expRe.test(name) ? root + '/' + name : name).split('/');
    for (var i = 0, length = parts.length; i < length; i++) {
      part = parts[i];
      if (part === '..') {
        results.pop();
      } else if (part !== '.' && part !== '') {
        results.push(part);
      }
    }
    return results.join('/');
  };

  var dirname = function(path) {
    return path.split('/').slice(0, -1).join('/');
  };

  var localRequire = function(path) {
    return function expanded(name) {
      var absolute = expand(dirname(path), name);
      return globals.require(absolute, path);
    };
  };

  var initModule = function(name, definition) {
    var hot = hmr && hmr.createHot(name);
    var module = {id: name, exports: {}, hot: hot};
    cache[name] = module;
    definition(module.exports, localRequire(name), module);
    return module.exports;
  };

  var expandAlias = function(name) {
    return aliases[name] ? expandAlias(aliases[name]) : name;
  };

  var _resolve = function(name, dep) {
    return expandAlias(expand(dirname(name), dep));
  };

  var require = function(name, loaderPath) {
    if (loaderPath == null) loaderPath = '/';
    var path = expandAlias(name);

    if (has.call(cache, path)) return cache[path].exports;
    if (has.call(modules, path)) return initModule(path, modules[path]);

    throw new Error("Cannot find module '" + name + "' from '" + loaderPath + "'");
  };

  require.alias = function(from, to) {
    aliases[to] = from;
  };

  var extRe = /\.[^.\/]+$/;
  var indexRe = /\/index(\.[^\/]+)?$/;
  var addExtensions = function(bundle) {
    if (extRe.test(bundle)) {
      var alias = bundle.replace(extRe, '');
      if (!has.call(aliases, alias) || aliases[alias].replace(extRe, '') === alias + '/index') {
        aliases[alias] = bundle;
      }
    }

    if (indexRe.test(bundle)) {
      var iAlias = bundle.replace(indexRe, '');
      if (!has.call(aliases, iAlias)) {
        aliases[iAlias] = bundle;
      }
    }
  };

  require.register = require.define = function(bundle, fn) {
    if (bundle && typeof bundle === 'object') {
      for (var key in bundle) {
        if (has.call(bundle, key)) {
          require.register(key, bundle[key]);
        }
      }
    } else {
      modules[bundle] = fn;
      delete cache[bundle];
      addExtensions(bundle);
    }
  };

  require.list = function() {
    var list = [];
    for (var item in modules) {
      if (has.call(modules, item)) {
        list.push(item);
      }
    }
    return list;
  };

  var hmr = globals._hmr && new globals._hmr(_resolve, require, modules, cache);
  require._cache = cache;
  require.hmr = hmr && hmr.wrap;
  require.brunch = true;
  globals.require = require;
})();

(function() {
var global = typeof window === 'undefined' ? this : window;
var __makeRelativeRequire = function(require, mappings, pref) {
  var none = {};
  var tryReq = function(name, pref) {
    var val;
    try {
      val = require(pref + '/node_modules/' + name);
      return val;
    } catch (e) {
      if (e.toString().indexOf('Cannot find module') === -1) {
        throw e;
      }

      if (pref.indexOf('node_modules') !== -1) {
        var s = pref.split('/');
        var i = s.lastIndexOf('node_modules');
        var newPref = s.slice(0, i).join('/');
        return tryReq(name, newPref);
      }
    }
    return none;
  };
  return function(name) {
    if (name in mappings) name = mappings[name];
    if (!name) return;
    if (name[0] !== '.' && pref) {
      var val = tryReq(name, pref);
      if (val !== none) return val;
    }
    return require(name);
  }
};
require.register("api/index.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

var _config = require('config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  init: function init() {
    return new _promise2.default(function (resolve) {
      _vue2.default.http.options.root = _config2.default.SERVICE_ROOT;
      resolve();
    });
  },
  onProgress: function onProgress(start, finish) {
    _vue2.default.http.interceptors.push(function (request, next) {
      start();

      next(function (response) {
        setTimeout(function () {
          finish(response.ok);
        }, 50);

        return response;
      });
    });
  },
  setToken: function setToken(token) {
    _vue2.default.http.headers.common['X-AUTH-TOKEN'] = null;
    if (token && token.id) _vue2.default.http.headers.common['X-AUTH-TOKEN'] = token.id;
  },
  removeToken: function removeToken() {
    this.setToken(null);
  }
};

});

require.register("api/resources/dashboard.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('dashboard', null, {
    osnovno: { method: 'GET', url: 'dashboard/osnovno' },
    header: { method: 'GET', url: 'dashboard/header' },
    statistika: { method: 'GET', url: 'dashboard/statistika' },
    zavrseniZahtjeviPoDanimaProslaSedmica: { method: 'GET', url: 'dashboard/zavrseniZahtjeviPoDanimaProslaSedmica' },
    kreiraniZahtjeviPoDanimaProslaSedmica: { method: 'GET', url: 'dashboard/kreiraniZahtjeviPoDanimaProslaSedmica' },
    brojZahtjevaPoProjektu: { method: 'GET', url: 'dashboard/brojZahtjevaPoProjektu' },
    zahtjeviNajduzeUPotrebnoUraditi: { method: 'GET', url: 'dashboard/zahtjeviNajduzeUPotrebnoUraditi' },
    zahtjeviZadnjiDodatiKojeJePotrebnoUraditi: { method: 'GET', url: 'dashboard/zahtjeviZadnjiDodatiKojeJePotrebnoUraditi' },
    sviProjektiKorisnika: { method: 'GET', url: 'dashboard/sviProjektiKorisnika' },
    zahtjeviPoDanimaAktivnaGodina: { method: 'GET', url: 'dashboard/zahtjeviPoDanimaAktivnaGodina' },
    zahtjeviPoMjesecima: { method: 'GET', url: 'dashboard/zahtjeviPoMjesecima' },
    zahtjeviZadnjiDodatiNisuRijeseni: { method: 'GET', url: 'dashboard/zahtjeviZadnjiDodatiNisuRijeseni' },
    zahtjeviZadnjiDodatiRijeseni: { method: 'GET', url: 'dashboard/zahtjeviZadnjiDodatiRijeseni' },
    zahtjeviPoSedmicama: { method: 'GET', url: 'dashboard/zahtjeviPoSedmicama' }

  });
};

});

require.register("api/resources/index.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NotifikacijeResource = exports.ZahtjevResource = exports.UlogaTipoviDodatneInformacijeResource = exports.ProjekatResource = exports.UlogaResource = exports.PravoUpravljanjaKorisnikomResource = exports.DashboardResource = exports.LogResource = exports.SifarnikResource = exports.PostavkeResource = exports.KorisnikResource = exports.PrevodResource = exports.TokenResource = undefined;

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

var _prevod = require('./prevod');

var _prevod2 = _interopRequireDefault(_prevod);

var _token = require('./token');

var _token2 = _interopRequireDefault(_token);

var _korisnik = require('./korisnik');

var _korisnik2 = _interopRequireDefault(_korisnik);

var _postavke = require('./postavke');

var _postavke2 = _interopRequireDefault(_postavke);

var _sifarnik = require('./sifarnik');

var _sifarnik2 = _interopRequireDefault(_sifarnik);

var _log = require('./log');

var _log2 = _interopRequireDefault(_log);

var _dashboard = require('./dashboard');

var _dashboard2 = _interopRequireDefault(_dashboard);

var _pravoupravljanjakorisnikom = require('./pravoupravljanjakorisnikom');

var _pravoupravljanjakorisnikom2 = _interopRequireDefault(_pravoupravljanjakorisnikom);

var _uloga = require('./uloga');

var _uloga2 = _interopRequireDefault(_uloga);

var _projekat = require('./projekat');

var _projekat2 = _interopRequireDefault(_projekat);

var _zahtjev = require('./zahtjev');

var _zahtjev2 = _interopRequireDefault(_zahtjev);

var _notifikacije = require('./notifikacije');

var _notifikacije2 = _interopRequireDefault(_notifikacije);

var _ulogaTipoviDodatneInformacije = require('./uloga-tipovi-dodatne-informacije');

var _ulogaTipoviDodatneInformacije2 = _interopRequireDefault(_ulogaTipoviDodatneInformacije);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var apiResource = function apiResource(resource) {
    var constructor = function constructor(url, params, actions, options) {
        return _vue2.default.resource(url, params, actions, options);
    };

    return function () {
        return resource(constructor);
    };
};

var PrevodResource = apiResource(_prevod2.default);

var TokenResource = apiResource(_token2.default);

var KorisnikResource = apiResource(_korisnik2.default);

var PostavkeResource = apiResource(_postavke2.default);

var SifarnikResource = apiResource(_sifarnik2.default);

var LogResource = apiResource(_log2.default);

var DashboardResource = apiResource(_dashboard2.default);

var PravoUpravljanjaKorisnikomResource = apiResource(_pravoupravljanjakorisnikom2.default);

var UlogaResource = apiResource(_uloga2.default);

var ProjekatResource = apiResource(_projekat2.default);

var ZahtjevResource = apiResource(_zahtjev2.default);

var NotifikacijeResource = apiResource(_notifikacije2.default);

var UlogaTipoviDodatneInformacijeResource = apiResource(_ulogaTipoviDodatneInformacije2.default);

exports.TokenResource = TokenResource;
exports.PrevodResource = PrevodResource;
exports.KorisnikResource = KorisnikResource;
exports.PostavkeResource = PostavkeResource;
exports.SifarnikResource = SifarnikResource;
exports.LogResource = LogResource;
exports.DashboardResource = DashboardResource;
exports.PravoUpravljanjaKorisnikomResource = PravoUpravljanjaKorisnikomResource;
exports.UlogaResource = UlogaResource;
exports.ProjekatResource = ProjekatResource;
exports.UlogaTipoviDodatneInformacijeResource = UlogaTipoviDodatneInformacijeResource;
exports.ZahtjevResource = ZahtjevResource;
exports.NotifikacijeResource = NotifikacijeResource;

});

require.register("api/resources/korisnik.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('korisnici/{korisnickoIme}', null, {
    promijeniLozinku: { method: 'PUT', url: 'korisnici/{korisnickoIme}/lozinka' },
    postaviLozinku: { method: 'POST', url: 'korisnici/{korisnickoIme}/lozinka' },
    onemogucen: { method: 'PUT', url: 'korisnici/{korisnickoIme}/onemogucen' },
    aktiviraj: { method: 'GET', url: 'korisnici/aktiviraj' },
    azurirajLicneDetalje: { method: 'PUT', url: 'korisnici/{korisnickoIme}/licni-detalji' },
    azurirajProjekteKorisnika: { method: 'POST', url: 'korisnici/{korisnickoIme}/projekti' },
    vratiKategorijeKorisnika: { method: 'GET', url: 'zahtjevkategorija/{korisnickoIme}' },
    vratiSupportKorisnikeZaZahtjevKategoriju: { method: 'GET', url: 'korisnici/zahtjevKategorija/{zahtjevKategorijaId}' }
  });
};

});

require.register("api/resources/log.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = function (resource) {
    return resource('log/{logId}', null, {
        level: {
            method: 'GET',
            url: 'log/log_level'
        },
        kategorija: {
            method: 'GET',
            url: 'log/log_kategorija'
        },
        akcije: {
            method: 'GET',
            url: 'log/log_akcija'
        },
        entiteti: {
            method: 'GET',
            url: 'log/log_entiteti'
        },
        akcija: {
            method: 'GET',
            url: 'log/akcija'
        },
        entitet: {
            method: 'GET',
            url: 'log/entitet'
        },
        entitetById: {
            method: 'GET',
            url: 'log/entitet/{entitetId}/{entitet}'
        },
        entitet_verzija: {
            method: 'GET',
            url: 'log/entitet/{entitetId}/{entitet}/verzija/{verzijaId}'
        }
    });
};

});

require.register("api/resources/notifikacije.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
   value: true
});

exports.default = function (resource) {
   return resource('notifikacije', {}, {
      /* otvori: {
         method: 'PUT',
         url: 'notifikacije/otvori'
       },*/
      vratiNotifikacije: { method: 'GET', url: 'notifikacije' },
      otvori: { method: 'PUT', url: 'notifikacije/otvori' },
      otvoriKorisnikoveNotifikacijeZaZahtjev: { method: 'PUT', url: 'notifikacije/zahtjev/{zahtjevId}/otvori' }
   });
};

});

require.register("api/resources/postavke.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('postavke');
};

});

require.register("api/resources/pravoupravljanjakorisnikom.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('korisnici/pravoupravljanjakorisnikom/{ulogaId}');
};

});

require.register("api/resources/prevod.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('prevod/{tabela}/id/{id}', null, {

    getPrevodLista: {
      method: 'GET',
      url: 'prevod/{tabela}/id/{id}'
    },

    prevedi: {
      method: 'POST',
      url: 'prevod/{tabela}/id/{id}'
    }
  });
};

});

require.register("api/resources/projekat.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('projekat', null, {
    vratiSveProjekte: { method: 'GET', url: 'projekat' },
    vratiProjekat: { method: 'GET', url: 'projekat/{projekatId}' },
    azurirajProjekat: { method: 'PUT', url: 'projekat/{projekatId}' },
    vratiZahtjevPrioriteteZaProjekat: { method: 'GET', url: 'zahtjevprioritet/projekat/{projekatId}' },
    vratiKonfiguracijuProjekta: { method: 'GET', url: 'projekatkonfiguracija/projekat/{projekatId}' },
    vratiTipoveZahtjevaZaProjekat: { method: 'GET', url: 'zahtjevtip/projekat/{projekatId}' },
    vratiStatuseZahtjevaZaProjekat: { method: 'GET', url: 'zahtjevstatus/projekat/{projekatId}' },
    snimiKonfiguracijuProjekta: { method: 'PUT', url: 'projekatkonfiguracija/projekat/{projekatId}' },
    dodajNoviStatusZahtjevaZaProjekat: { method: 'POST', url: 'zahtjevstatus/projekat/{projekatId}' },
    dodajNoviPrioritetZahtjevaZaProjekat: { method: 'POST', url: 'zahtjevprioritet/projekat/{projekatId}' },
    dodajNoviTipZahtjevaZaProjekat: { method: 'POST', url: 'zahtjevtip/projekat/{projekatId}' },
    vratiDijeloveProjekta: { method: 'GET', url: 'dioprojekta/projekat/{projekatId}' },
    dodajNoviDioProjekta: { method: 'POST', url: 'dioprojekta/projekat/{projekatId}' },
    azurirajDefaultniZahtjevPrioritetProjekta: { method: 'PUT', url: 'zahtjevprioritet/projekat/{projekatId}' },
    azurirajDefaultniZahtjevStatusProjekta: { method: 'PUT', url: 'zahtjevstatus/projekat/{projekatId}' },
    azurirajDefaultniZahtjevTipProjekta: { method: 'PUT', url: 'zahtjevtip/projekat/{projekatId}' },
    vratiZahtjevKategorijeZaDioProjekta: { method: 'GET', url: 'zahtjevkategorija/dioprojekta/{dioProjektaId}' },
    dodajNovuZahtjevKategoriju: { method: 'POST', url: 'zahtjevkategorija/dioprojekta/{dioProjektaId}' },
    vratiKorisnikeProjekta: { method: 'GET', url: 'projekat/{projekatId}/korisnici' },
    vratiProjekteZaKorisnikUlogu: { method: 'GET', url: 'projekat/korisnik/{korisnickoIme}/uloga/{ulogaId}' },
    azurirajPoredakStatusa: { method: 'PUT', url: 'zahtjevstatus/projekat/{projekatId}/poredak'

      /*onemogucen: { method: 'PUT', url: 'korisnici/{korisnickoIme}/onemogucen' },   
      aktiviraj: { method: 'GET', url: 'korisnici/aktiviraj' },
      azurirajLicneDetalje: { method: 'PUT', url: 'korisnici/{korisnickoIme}/licni-detalji' }*/
    } });
};

});

require.register("api/resources/sifarnik.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('sifarnik/', null, {
    nekesirano: {
      method: 'GET',
      url: 'sifarnik/{sifarnik}/nekesirano'
    },
    polja: {
      method: 'GET',
      url: 'sifarnik/{tipSifarnika}/polja'
    }
  });
};

});

require.register("api/resources/token.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('korisnici/{korisnickoIme}/tokeni{/tokenId}', null, {
    temp: {
      method: 'POST',
      url: 'korisnici/{korisnickoIme}/tokeni/temp'
    },
    provjeriLozinku: {
      method: 'POST',
      url: 'korisnici/{korisnickoIme}/tokeni/provjerilozinku'
    }
  });
};

});

require.register("api/resources/uloga-tipovi-dodatne-informacije.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('korisnici/ulogatipovidodatneinformacije', {}, {
    sveZaUlogu: { method: 'GET', url: 'korisnici/ulogatipovidodatneinformacije/zaulogu/{ulogaId}' },
    snimiZaUlogu: { method: 'PUT', url: 'korisnici/ulogatipovidodatneinformacije/zaulogu/{ulogaId}' }
  });
};

});

require.register("api/resources/uloga.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (resource) {
  return resource('korisnici/uloga/{ulogaId}', {}, {
    grupePrava: { method: 'GET', url: 'korisnici/uloga/{ulogaId}/grupeprava' },
    dozvoljeneAkcije: { method: 'GET', url: 'korisnici/uloga/{ulogaId}/dozvoljeneakcije' },
    snimiDozvoljeneAkcije: { method: 'PUT', url: 'korisnici/uloga/{ulogaId}/dozvoljeneakcije' }
  });
};

});

require.register("api/resources/zahtjev.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = function (resource) {
    return resource('zahtjev', null, {
        vratiSveZahtjeve: { method: 'GET', url: 'zahtjevi' },
        vratiSveZahtjeveProjekta: { method: 'GET', url: 'zahtjevi/projekat/{projekatId}' },
        dodajNoviZahtjev: { method: 'POST', url: 'zahtjevi/projekat/{projekatId}' },
        vratiZahtjev: { method: 'GET', url: 'zahtjevi/{zahtjevId}' },
        azurirajZahtjev: { method: 'PUT', url: 'zahtjevi/{zahtjevId}' },
        dodajKomentar: { method: 'POST', url: 'zahtjevkomentari/zahtjev/{zahtjevId}' },
        vratiKomentareZahtjeva: { method: 'GET', url: 'zahtjevkomentari/zahtjev/{zahtjevId}' },
        azurirajStatusZahtjeva: { method: 'PUT', url: 'zahtjevi/{zahtjevId}/zahtjevStatus' },
        vratiPrilogZahtjeva: { method: 'GET', url: 'prilogZahtjeva/{prilogId}' },
        vratiIzmjeneStatusaZahtjeva: { method: 'GET', url: 'zahtjevi/{zahtjevId}/zahtjevStatusi' },
        brisanjeZahtjeva: { method: 'PUT', url: 'zahtjevi/{zahtjevId}/brisanje'

            /*onemogucen: { method: 'PUT', url: 'korisnici/{korisnickoIme}/onemogucen' },   
            aktiviraj: { method: 'GET', url: 'korisnici/aktiviraj' },
            azurirajLicneDetalje: { method: 'PUT', url: 'korisnici/{korisnickoIme}/licni-detalji' }*/
        } });
};

});

require.register("auth/dozvoljene-akcije-storage.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _config = require('config');

var _config2 = _interopRequireDefault(_config);

var _store = require('store');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  getDozvoljeneAkcije: function getDozvoljeneAkcije() {
    return _store2.default.get(_config2.default.DOZVOLJENE_AKCIJE_NAME);
  },
  setDozvoljeneAkcije: function setDozvoljeneAkcije(dozvoljeneAkcije) {
    _store2.default.set(_config2.default.DOZVOLJENE_AKCIJE_NAME, dozvoljeneAkcije);
  },
  removeDozvoljeneAkcije: function removeDozvoljeneAkcije() {
    _store2.default.remove(_config2.default.DOZVOLJENE_AKCIJE_NAME);
  }
};

});

require.register("auth/identity.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _api = require('api');

var _api2 = _interopRequireDefault(_api);

var _tokenStorage = require('./token-storage');

var _tokenStorage2 = _interopRequireDefault(_tokenStorage);

var _dozvoljeneAkcijeStorage = require('./dozvoljene-akcije-storage');

var _dozvoljeneAkcijeStorage2 = _interopRequireDefault(_dozvoljeneAkcijeStorage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  token: null,
  dozvoljeneAkcije: [],

  getToken: function getToken() {
    return this.token;
  },
  imaPravo: function imaPravo(akcija) {
    if (this.dozvoljeneAkcije) {
      return this.dozvoljeneAkcije.some(function (a) {
        return a === akcija;
      });
    }
    return false;
  },
  dodatnaInformacijaPoSifri: function dodatnaInformacijaPoSifri(sifra) {
    var informacije = this.token.vlasnik.dodatneInformacije.items.filter(function (a) {
      return a.tipDodatneInformacije.sifra === sifra;
    });
    if (informacije.length > 0) {
      return informacije[0].vrijednost;
    }
    return null;
  },
  frontendModul: function frontendModul() {
    return this.token.frontendModul;
  },
  frontendModulNaslov: function frontendModulNaslov() {
    if (this.token) {
      return this.token.frontendModulNaslov;
    }
  },
  setDozvoljeneAkcije: function setDozvoljeneAkcije(dozvoljeneAkcije) {
    this.dozvoljeneAkcije = dozvoljeneAkcije;
    _dozvoljeneAkcijeStorage2.default.setDozvoljeneAkcije(dozvoljeneAkcije);
  },
  setToken: function setToken(token) {
    this.token = token;
    _api2.default.setToken(token);
    _tokenStorage2.default.setToken({
      korisnickoIme: token.vlasnik.korisnickoIme,
      tokenId: token.id
    });
  },
  removeToken: function removeToken() {
    this.token = null;
    _api2.default.removeToken();
    _tokenStorage2.default.removeToken();
  },
  getStorage: function getStorage() {
    return _tokenStorage2.default;
  },
  getDozvoljeneAkcijeStorage: function getDozvoljeneAkcijeStorage() {
    return _dozvoljeneAkcijeStorage2.default;
  },
  id: function id() {
    if (this.token && this.token.id) return this.token.id;
    return null;
  },
  korisnickoIme: function korisnickoIme() {
    if (this.token && this.token.vlasnik) return this.token.vlasnik.korisnickoIme;
    return null;
  },
  uloga: function uloga() {
    if (this.token && this.token.vlasnik) return this.token.uloga;
    return null;
  },
  trenutnaUlogaId: function trenutnaUlogaId() {
    if (this.token && this.token.vlasnik) return this.token.ulogaId;
    return null;
  },
  punoIme: function punoIme() {
    if (this.token && this.token.vlasnik) return this.token.vlasnik.punoIme;
    return null;
  },
  isAuthenticated: function isAuthenticated() {
    return this.id() != null;
  }
};

});

require.register("auth/index.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _resources = require('api/resources');

var _identity = require('./identity');

var _identity2 = _interopRequireDefault(_identity);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  init: function init() {
    return new _promise2.default(function (resolve) {
      var tokenStorage = _identity2.default.getStorage();
      if (!tokenStorage.hasToken()) {
        resolve();
        return;
      }

      var storedToken = tokenStorage.getToken();
      var promise = (0, _resources.TokenResource)().get(storedToken);

      // Procitaj dozvoljene akcije iz localstorage
      var dozvoljeneAkcijeStorate = _identity2.default.getDozvoljeneAkcijeStorage();
      var storedDozvoljeneAkcije = dozvoljeneAkcijeStorate.getDozvoljeneAkcije();
      _identity2.default.setDozvoljeneAkcije(storedDozvoljeneAkcije);

      promise.then(function (response) {
        _identity2.default.setToken(response.body);
        resolve();
      }, function () {
        _identity2.default.removeToken();
        resolve();
      });
    });
  },
  signIn: function signIn(korisnickoIme, lozinka, ulogaId) {
    console.log("SIGN IN");
    var promise = (0, _resources.TokenResource)().save({ korisnickoIme: korisnickoIme }, {
      lozinka: lozinka,
      ulogaId: ulogaId
    });

    return promise.then(function (response) {
      console.log("RES", response);
      var listaDozvoljenih = response.body.vlasnik.dozvoljeneAkcije.items.map(function (a) {
        return a.sifra;
      });
      console.log("doz", listaDozvoljenih);
      _identity2.default.setDozvoljeneAkcije(listaDozvoljenih);

      console.log("doz2", listaDozvoljenih);
      _identity2.default.setToken(response.body);
      return response.body;
    }, function (response) {
      _identity2.default.removeToken();
      return _promise2.default.reject(response);
    });
  },
  signOut: function signOut() {
    var token = _identity2.default.getToken();
    if (!token) return;

    (0, _resources.TokenResource)().remove({
      korisnickoIme: token.vlasnik.korisnickoIme,
      tokenId: token.id
    });

    _identity2.default.removeToken();
  },
  isAuthenticated: function isAuthenticated() {
    return _identity2.default.isAuthenticated();
  }
};

});

require.register("auth/token-storage.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _config = require('config');

var _config2 = _interopRequireDefault(_config);

var _store = require('store');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  hasToken: function hasToken() {
    var token = this.getToken();
    if (token) return true;
    return false;
  },
  getToken: function getToken() {
    return _store2.default.get(_config2.default.AUTH_TOKEN_NAME);
  },
  setToken: function setToken(token) {
    _store2.default.set(_config2.default.AUTH_TOKEN_NAME, token);
  },
  removeToken: function removeToken() {
    _store2.default.remove(_config2.default.AUTH_TOKEN_NAME);
  }
};

});

require.register("config.jsenv", function(exports, require, module) {
module.exports = {"AUTH_TOKEN_NAME":"TMS_TOKEN","DOZVOLJENE_AKCIJE_NAME":"TMS_DOZVOLJENE_AKCIJE","SERVICE_ROOT":"api","ENVIRONMENT":"production"}
});

;require.register("helpers/common-mixin.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _identity = require('../auth/identity');

var _identity2 = _interopRequireDefault(_identity);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CommonMixin = {
    methods: {
        imaPravo: function imaPravo(action) {
            return _identity2.default.imaPravo(action);
        },
        frontendModul: function frontendModul() {
            return _identity2.default.frontendModul();
        },
        updateDatumRodjenja: function updateDatumRodjenja(maticniBroj, komponenta) {
            if (maticniBroj.length >= 7) {
                var dan = maticniBroj.substring(0, 2);
                var mjesec = maticniBroj.substring(2, 4);
                var dioGodine = maticniBroj.substring(4, 7);
                var godina = parseInt(dioGodine) > 100 ? '1' + dioGodine : '2' + dioGodine;

                var noviDatum = godina + '-' + mjesec + '-' + dan;
                komponenta.update(noviDatum);
            }
        },
        prikaziPolje: function prikaziPolje(stranica, vidljivost) {
            if (stranica == "lista") {
                return vidljivost.indexOf(1) != -1;
            }
            if (stranica == "dodavanje") {
                return vidljivost.indexOf(2) != -1;
            }
            if (stranica == "edit") {
                return vidljivost.indexOf(3) != -1;
            }
            return false;
        },
        getTipPolja: function getTipPolja(tip) {
            switch (tip) {
                case 1:
                    return 'number';
                case 2:
                    return 'text';
                case 3:
                    return 'select';
                case 4:
                    return 'checkbox';
            }
        },
        mergeQueryToInput: function mergeQueryToInput(query, inputs) {
            for (var attrname in query) {
                inputs[attrname] = query[attrname];
            }

            // Ovaj dio pretvara atribute objekta u broj ili datum ako moze
            // potrebno je zbog toga sto svi atributi objekta budu stringovi inicijalno
            // a u palikaciji su neki brojevi npr page ili count
            (0, _keys2.default)(inputs).map(function (key) {
                if (inputs[key] != null && typeof inputs[key] == "string") {
                    var numValue = parseInt(inputs[key]);
                    if (!isNaN(numValue)) {
                        inputs[key] = numValue;
                    } else {
                        var datumValue = _moment2.default.utc(inputs[key]);
                        if (datumValue.isValid()) {
                            inputs[key] = datumValue.toDate();
                        }
                    }
                }
            });
            return inputs;
        },
        osvjeziQuery: function osvjeziQuery(inputs) {
            inputs = (0, _assign2.default)({}, inputs);
            for (var attrname in inputs) {
                if (inputs[attrname] == null) inputs[attrname] = "";
            }
            this.$router.push({
                query: inputs
            });
        },
        prikaziDvijeDecimale: function prikaziDvijeDecimale(broj) {
            if (broj != null && broj != undefined) {
                return broj.toLocaleString(undefined, { minimumFractionDigits: 2 });
            } else return "0, 00";
        }
    }
};

exports.default = CommonMixin;

});

require.register("helpers/core-mixin.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
var CoreMixin = {
    data: function data() {
        return {
            core: {
                razredi: [{
                    id: 1,
                    naziv: '1'
                }, {
                    id: 2,
                    naziv: '2'
                }, {
                    id: 3,
                    naziv: '3'
                }, {
                    id: 4,
                    naziv: '4'
                }, {
                    id: 5,
                    naziv: '5'
                }, {
                    id: 6,
                    naziv: '6'
                }, {
                    id: 7,
                    naziv: '7'
                }, {
                    id: 8,
                    naziv: '8'
                }, {
                    id: 9,
                    naziv: '9'
                }]
            }
        };
    }
};

exports.default = CoreMixin;

});

require.register("helpers/form-mixin.js", function(exports, require, module) {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var FormMixin = {
    methods: {
        focusInvalidInput: function focusInvalidInput(forma) {
            var firstInvalid = forma.inputs.sort(compare).find(function (input) {
                return input.errorBucket && input.errorBucket.length > 0;
            });

            function compare(a, b) {
                // Sortiraj po poziciji na stranici
                var topa = a.$el.getBoundingClientRect().top;
                var topb = b.$el.getBoundingClientRect().top;
                if (topa < topb) {
                    return -1;
                }
                if (topa > topb) {
                    return 1;
                }

                // Ako su u istom redu sortiraj po horizontalnoj poziciji
                var lefta = a.$el.getBoundingClientRect().left;
                var leftb = b.$el.getBoundingClientRect().left;
                if (lefta < leftb) {
                    return -1;
                }
                if (lefta > leftb) {
                    return 1;
                }

                return 0;
            }

            function scroll() {
                window.scrollBy(0, -150);
            }

            if (firstInvalid) {
                this.$nextTick(firstInvalid.focusInput);
                this.$nextTick(firstInvalid.focus);
                this.$nextTick(scroll);
            }
        },
        focusInvalidInputTimeout: function focusInvalidInputTimeout(forma, timeout) {
            var _this = this;

            setTimeout(function () {
                _this.focusInvalidInput(forma);
            }, timeout);
        }
    }
};

exports.default = FormMixin;

});

require.register("helpers/help-tip-dialog-mixin.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});


var HelpTipDialogMixin = {
    methods: {
        ZatvoriHelpDialog: function ZatvoriHelpDialog() {
            this.activeHelpTip = false;
        },
        VratiContentPoId: function VratiContentPoId(formaId) {
            var helpTip = this.tekst.find(function (item) {
                return item.id === formaId;
            });
            return helpTip.content;
        },
        VratiTitlePoId: function VratiTitlePoId(formaId) {
            var helpTip = this.tekst.find(function (item) {
                return item.id === formaId;
            });
            return helpTip.title;
        }
    },
    data: function data() {
        return {
            tekst: []
        };
    },
    created: function created() {
        this.tekst = [{
            id: 'korisnik-dodavanje',
            title: 'Dodaj korisnika',
            content: 'Va\u017Eno je odrediti ulogu korisnika ispravno zbog prava pristupa i kasnijih aktivnosti korisnika.'
        }, {
            id: 'korisnik-list',
            title: 'Korisnici',
            content: 'Pregled korisnika sa ponu\u0111enim setom aktivnosti za svakog korisnika.'
        }, {
            id: 'korisnik-edit',
            title: 'Izmijeni korisnika',
            content: 'Unosom obaveznih polja na izmjeni podataka i klikom na dugme "Snimi" mijenjamo podatke korisnika.'
        }, {
            id: 'izvjestaj-list',
            title: 'Izvještaji',
            content: 'Forma za izbor i prikaz izvje\u0161taja.\n            Nakon izbora izvje\u0161taja sa liste klikom na "Prika\u017Ei" prikazuje se report forma.\n            Zavisno od izvje\u0161taja na report formi biramo parametre po kojima pretra\u017Eujemo izvje\u0161taj.'
        }];
    }
};

exports.default = HelpTipDialogMixin;

});

require.register("helpers/pagination-mixin.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _lodash = require('lodash.debounce');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var PaginationMixin = {
    mounted: function mounted() {
        var _this = this;

        this.updateData = (0, _lodash2.default)(this.updateData, 300, { leading: true });
        if (!this.disableUpdate) {
            this.updateData();
        }
        this.$watch('pagination', function (novi, stari) {
            if (novi.page !== stari.page || novi.rowsPerPage !== stari.rowsPerPage) {
                _this.inputs.page = novi.page;
                _this.inputs.count = novi.rowsPerPage;

                if (!_this.disableUpdate) {
                    _this.updateData();
                }
            }
        }, { deep: true });
    },
    data: function data() {
        return {
            pagination: {
                page: 1,
                rowsPerPage: 30
            },
            rowsPerPageItems: [10, 20, 30, 50]
        };
    },

    methods: {
        resetujPaginaciju: function resetujPaginaciju() {
            this.inputs.page = 1;
            this.pagination.page = 1;
            this.updateData();
        }
    }
};

exports.default = PaginationMixin;

});

require.register("helpers/resolve-mixin.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _values = require('babel-runtime/core-js/object/values');

var _values2 = _interopRequireDefault(_values);

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var evaluateAll = function evaluateAll(vm, resolve) {
  var keys = (0, _keys2.default)(resolve);

  return keys.reduce(function (result, key) {
    var func = resolve[key];
    if (typeof func === "function") result[key] = func.apply(vm);
    return result;
  }, {});
};

var processResult = function processResult(result) {
  // hack, c'est la js
  if (result && result.status && result.headers) {
    if (result.ok) return result.body;
    return null;
  }

  return result;
};

var promiseAll = function promiseAll(promises) {
  var values = (0, _values2.default)(promises);
  var keys = (0, _keys2.default)(promises);

  return _promise2.default.all(values).then(function (results) {
    return keys.reduce(function (result, key, index) {
      result[key] = processResult(results[index]);
      return result;
    }, {});
  });
};

var doResolve = function doResolve(vm) {
  if (!vm.$options.resolve) return;

  var promises = evaluateAll(vm, vm.$options.resolve);
  promiseAll(promises).then(function (result) {
    vm.$set(vm, 'resolved', result);
  });
};

exports.default = {
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next(doResolve);
  },
  beforeRouteUpdate: function beforeRouteUpdate(to, from, next) {
    if (this.$options.resolve) this.$set(this, 'resolved', null);

    next();
    doResolve(this);
  }
};

});

require.register("helpers/upload-mixin.js", function(exports, require, module) {
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _assign = require("babel-runtime/core-js/object/assign");

var _assign2 = _interopRequireDefault(_assign);

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _config = require("config");

var _config2 = _interopRequireDefault(_config);

var _resources = require("api/resources");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var UploadMixin = {
	data: function data() {
		return {
			identity: _identity2.default,
			uploadUrl: _config2.default.SERVICE_ROOT + '/upload',
			dropzoneOptionsOsnovno: {
				maxFiles: 1,
				queueLimit: 1,
				maxFileSize: 30,
				acceptedFiles: ".pdf",
				dictDefaultMessage: '<i aria-hidden="true" class="material-icons icon">file_upload</i>'
			}
		};
	},

	computed: {
		isAdministrator: function isAdministrator() {
			return this.identity.isAdministrator();
		},
		dropzoneOptions: function dropzoneOptions() {
			return (0, _assign2.default)(this.dropzoneOptionsOsnovno, {
				clickable: true,
				headers: this.headers,
				url: this.uploadUrl,
				success: this.uspjesanUpload,
				error: this.neuspjesanUpload,
				init: function init() {
					this.on('addedfile', function () {
						if (this.files.length > 1) {
							this.removeFile(this.files[0]);
						}
					});
				}
			});
		},
		headers: function headers() {
			if (this.identity != null) {
				return {
					'X-AUTH-TOKEN': this.identity.id()
				};
			}
			return null;
		}
	},
	methods: {
		uspjesanUpload: function uspjesanUpload(file, response) {
			var uploadId = response.options.find(function (a) {
				return a.key === 'uploadId';
			}).value[0];
			var item = this.uploads.find(function (a) {
				return a.id == uploadId;
			}).item;
			var dokumentId = response.result;

			item.dokumentId = dokumentId;

			this.$toast.success("Dokument uspješno poslan");
		},
		neuspjesanUpload: function neuspjesanUpload() {
			this.$toast.error("Greška prilikom slanja dokumenta");
		},
		preuzmiDokument: function preuzmiDokument(dokumentId) {
			var that = this;

			function success(model) {
				var dokumentUrl = that.uploadUrl + "/" + dokumentId + "?ttxid=" + model.body.id;
				window.open(dokumentUrl, "_blank", "");
			}

			(0, _resources.TokenResource)().temp({
				korisnickoIme: _identity2.default.korisnickoIme()
			}, {
				korisnickoIme: _identity2.default.korisnickoIme()
			}).then(success);
		},


		// Posto na stranici imamo vise upload komponenti potrebno je slati id da se zna na koju komponentu se odnosi
		// kada se dobije callback i za to nam sluzi uploads folder
		addParam: function addParam(formData, item) {
			if (this.uploads == null) {
				this.uploads = [];
			}

			var upload = {
				item: item,
				id: Math.floor(Math.random() * 100000 + 1)
			};
			this.uploads.push(upload);

			formData.append("uploadId", upload.id);
		},
		remove: function remove(file) {
			console.log("remove", file);
			//this.removeFile(file);
			file.previewElement.remove();
		}
	}
};

exports.default = UploadMixin;

});

require.register("index.js", function(exports, require, module) {
'use strict';

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

require('lodash.debounce');

require('simplemde');

require('marked');

require('babel-runtime/core-js/json/stringify');

require('vue-select');

require('codemirror');

require('./lang/ml');

var _sortablejs = require('sortablejs');

var _sortablejs2 = _interopRequireDefault(_sortablejs);

var _vueToasted = require('vue-toasted');

var _vueToasted2 = _interopRequireDefault(_vueToasted);

var _vueConfig = require('vue-config');

var _vueConfig2 = _interopRequireDefault(_vueConfig);

var _config = require('config');

var _config2 = _interopRequireDefault(_config);

var _vueRouter = require('vue-router');

var _vueRouter2 = _interopRequireDefault(_vueRouter);

var _vueResource = require('vue-resource');

var _vueResource2 = _interopRequireDefault(_vueResource);

var _vuetify = require('vuetify');

var _vuetify2 = _interopRequireDefault(_vuetify);

var _vuejsDatepicker = require('vuejs-datepicker');

var _vuejsDatepicker2 = _interopRequireDefault(_vuejsDatepicker);

require('pace-progress/pace.js');

var _vue2Leaflet = require('vue2-leaflet');

var _vue2Leaflet2 = _interopRequireDefault(_vue2Leaflet);

require('chart.js');

require('hchs-vue-charts');

var _vueCharts = require('vue-charts');

var _vueCharts2 = _interopRequireDefault(_vueCharts);

var _vueMoment = require('vue-moment');

var _vueMoment2 = _interopRequireDefault(_vueMoment);

var _vueFontawesome = require('vue-fontawesome');

var _vueSpinner = require('vue-spinner');

var _resolveMixin = require('./helpers/resolve-mixin');

var _resolveMixin2 = _interopRequireDefault(_resolveMixin);

var _formMixin = require('helpers/form-mixin');

var _formMixin2 = _interopRequireDefault(_formMixin);

var _page = require('./modules/home/components/page');

var _page2 = _interopRequireDefault(_page);

var _vuex = require('vuex');

var _vuex2 = _interopRequireDefault(_vuex);

var _vuexStore = require('./vuex-store');

var _vuexStore2 = _interopRequireDefault(_vuexStore);

var _mDatepicker = require('./modules/home/components/m-datepicker');

var _mDatepicker2 = _interopRequireDefault(_mDatepicker);

var _odustaniBtn = require('./modules/home/components/odustani-btn');

var _odustaniBtn2 = _interopRequireDefault(_odustaniBtn);

var _oIframe = require('./modules/home/components/o-iframe');

var _oIframe2 = _interopRequireDefault(_oIframe);

var _mInfoDialog = require('./modules/home/components/m-info-dialog');

var _mInfoDialog2 = _interopRequireDefault(_mInfoDialog);

var _helpTipDialog = require('./modules/home/components/help-tip-dialog');

var _helpTipDialog2 = _interopRequireDefault(_helpTipDialog);

var _dateFormat = require('./modules/home/components/date-format');

var _dateFormat2 = _interopRequireDefault(_dateFormat);

var _prettyprint = require('./modules/home/components/prettyprint');

var _prettyprint2 = _interopRequireDefault(_prettyprint);

var _vue2Dropzone = require('vue2-dropzone');

var _vue2Dropzone2 = _interopRequireDefault(_vue2Dropzone);

var _commonMixin = require('./helpers/common-mixin.js');

var _commonMixin2 = _interopRequireDefault(_commonMixin);

var _coreMixin = require('./helpers/core-mixin.js');

var _coreMixin2 = _interopRequireDefault(_coreMixin);

var _obrisiModal = require('./modules/home/components/obrisi-modal');

var _obrisiModal2 = _interopRequireDefault(_obrisiModal);

var _mQuestionDialog = require('./modules/home/components/m-question-dialog');

var _mQuestionDialog2 = _interopRequireDefault(_mQuestionDialog);

var _upit = require('./modules/home/components/upit');

var _upit2 = _interopRequireDefault(_upit);

var _notification = require('./modules/home/components/notification');

var _notification2 = _interopRequireDefault(_notification);

var _loading = require('./modules/home/components/loading');

var _loading2 = _interopRequireDefault(_loading);

var _card = require('./modules/home/components/card');

var _card2 = _interopRequireDefault(_card);

var _chartCard = require('./modules/home/components/chart-card');

var _chartCard2 = _interopRequireDefault(_chartCard);

var _statsCard = require('./modules/home/components/stats-card');

var _statsCard2 = _interopRequireDefault(_statsCard);

var _vueScrollBehavior = require('vue-scroll-behavior');

var _vueScrollBehavior2 = _interopRequireDefault(_vueScrollBehavior);

var _vuedraggable = require('vuedraggable');

var _vuedraggable2 = _interopRequireDefault(_vuedraggable);

var _app = require('./modules/app');

var _app2 = _interopRequireDefault(_app);

var _api = require('./api');

var _api2 = _interopRequireDefault(_api);

var _postavke = require('./postavke');

var _postavke2 = _interopRequireDefault(_postavke);

var _auth = require('./auth');

var _auth2 = _interopRequireDefault(_auth);

var _identity = require('./auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _postavke3 = require('./postavke/postavke');

var _postavke4 = _interopRequireDefault(_postavke3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// fix for https://github.com/nblackburn/vue-brunch/issues/6
window.Sortable = _sortablejs2.default;

_vue2.default.use(_vueToasted2.default);

// set up config

_vue2.default.use(_vueConfig2.default, _config2.default);

// use vue-router

_vue2.default.use(_vueRouter2.default);

// use vue-resource

_vue2.default.use(_vueResource2.default);

_vue2.default.use(_vuetify2.default, {
    theme: {
        primary: '#2C9898',
        primary_dark: '#077070',
        secondary: '#FE4A4A',
        tertiary: '#828282',
        accent: '#B5ED45',
        error: '#f55a4e',
        info: '#00d3ee',
        success: '#5cb860',
        warning: '#ffa21a'
    }
});

_vue2.default.component('Datepicker', _vuejsDatepicker2.default);

window.Pace.start({
    restartOnRequestAfter: true
});
// use vue leaflet

_vue2.default.component('v-map', _vue2Leaflet2.default.Map);
_vue2.default.component('v-tilelayer', _vue2Leaflet2.default.TileLayer);
_vue2.default.component('v-marker', _vue2Leaflet2.default.Marker);
_vue2.default.component('v-tooltip', _vue2Leaflet2.default.Tooltip);
_vue2.default.component('v-map', _vue2Leaflet2.default.Map);

// import vSelect from 'vue-select';
// Vue.component('v-select', vSelect);

// vue charts

_vue2.default.use(window.VueCharts);

_vue2.default.use(_vueCharts2.default);

// use vue-moment

_vue2.default.use(_vueMoment2.default);

// use font awesome icon component

_vue2.default.component('icon', _vueFontawesome.icon);

// loading spinner component

_vue2.default.component('spinner', _vueSpinner.SyncLoader);

// add resolve mixin

_vue2.default.mixin(_resolveMixin2.default);

_vue2.default.mixin(_formMixin2.default);

_vue2.default.component('page', _page2.default);

_vue2.default.use(_vuex2.default);

_vue2.default.component('m-date-picker', _mDatepicker2.default);

_vue2.default.component('odustani-btn', _odustaniBtn2.default);

_vue2.default.component('o-iframe', _oIframe2.default);

_vue2.default.component('m-info-dialog', _mInfoDialog2.default);

_vue2.default.component('help-tip-dialog', _helpTipDialog2.default);

_vue2.default.component('date-format', _dateFormat2.default);

_vue2.default.component('prettyprint', _prettyprint2.default);

_vue2.default.component('vue-dropzone', _vue2Dropzone2.default);

_vue2.default.use(_vue2Dropzone2.default);

_vue2.default.mixin(_commonMixin2.default);

_vue2.default.mixin(_coreMixin2.default);

_vue2.default.component('obrisi-modal', _obrisiModal2.default);

_vue2.default.component('potvrda-modal', _mQuestionDialog2.default);

_vue2.default.component('upit', _upit2.default);

_vue2.default.component('notification', _notification2.default);

_vue2.default.component('loading', _loading2.default);

_vue2.default.component('material-card', _card2.default);

_vue2.default.component('material-chart-card', _chartCard2.default);

_vue2.default.component('material-stats-card', _statsCard2.default);

_vue2.default.component('draggable', _vuedraggable2.default);

// load app component


// use bootstrapping to start application


_api2.default.init().then(function () {
    return _auth2.default.init();
}).then(function () {
    return _postavke2.default.init();
}).then(function () {
    // set up routes
    var appRouter = new _vueRouter2.default({
        // mode:'history',
        routes: _app2.default.routes,
        scrollBehavior: function scrollBehavior(to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition;
            } else {
                return {
                    x: 0,
                    y: 0
                };
            }
        }
    });

    _vue2.default.use(_vueScrollBehavior2.default, {
        router: appRouter
    });
    // mapiranje pocetka naziva rute u Naziv stranice
    var PAGE_TITLE = [{
        naziv: "Postavke",
        ruta: "home.postavke"
    }, {
        naziv: "Dashboard",
        ruta: "home.dashboard"
    }, {
        naziv: "Log",
        ruta: "home.log"
    }, {
        naziv: "Šifarnici",
        ruta: "home.sifarnik"
    }, {
        naziv: "Korisnici",
        ruta: "home.korisnik"
    }, {
        naziv: "Izvještaji",
        ruta: "home.izvjestaj"
    }, {
        naziv: "Projekti",
        ruta: "home.projekat"
    }, {
        naziv: "Zadaci",
        ruta: "home.zahtjev"
    }];

    appRouter.beforeEach(function (toRoute, fromRoute, nextRoute) {
        var next_required_permission = toRoute.meta.permission_name;

        if (next_required_permission) {
            if (!_identity2.default.imaPravo(next_required_permission)) {
                console.log("nema prava", next_required_permission);
                nextRoute(false);
                return;
            }
        }
        nextRoute();
    });

    appRouter.afterEach(function (toRoute) {
        for (var i = 0; i < PAGE_TITLE.length; i++) {
            if (toRoute.name.startsWith(PAGE_TITLE[i].ruta)) {
                window.document.title = PAGE_TITLE[i].naziv;
            }
        }
    });

    // create and mount vue app
    var vm = new _vue2.default({
        router: appRouter,
        store: _vuexStore2.default,
        render: function render(h) {
            return h(_app2.default);
        },
        created: function created() {
            var jezik = this.$store.getters['home/odabraniJezik'];
            if (jezik) {
                console.log('nakon refresha', jezik);
                this.$ml.change(jezik);
            }

            var naslovSistema = _postavke4.default.naslovSistema();
            this.$store.commit('home/setNaslovSistema', naslovSistema);
            document.title = naslovSistema;
        }
    });

    vm.$mount('#app');
});

});

require.register("lang/bs.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    sidebar: {
        radna_ploca: 'Dashboard',
        komponente: 'Komponente',
        cesta_pitanja: 'Česta pitanja',
        pomoc: 'POMOĆ'
    }

};

});

require.register("lang/en.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    sidebar: {
        radna_ploca: 'Radna ploča',
        komponente: 'Komponente',
        cesta_pitanja: 'Česta pitanja',
        pomoc: 'POMOĆ'
    }

};

});

require.register("lang/hr.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    sidebar: {
        radna_ploca: 'Radna ploča',
        komponente: 'Komponente',
        cesta_pitanja: 'Česta pitanja',
        pomoc: 'POMOĆ'
    }

};

});

require.register("lang/ml.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

var _bs = require('./bs');

var _bs2 = _interopRequireDefault(_bs);

var _hr = require('./hr');

var _hr2 = _interopRequireDefault(_hr);

var _sr = require('./sr');

var _sr2 = _interopRequireDefault(_sr);

var _vueMultilanguage = require('vue-multilanguage');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(_vueMultilanguage.MLInstaller);
// import EN from './en';
exports.default = new _vueMultilanguage.MLCreate({
  initial: 0,
  // save: 'production' === 'production',
  languages: [new _vueMultilanguage.MLanguage(0).create(_bs2.default), new _vueMultilanguage.MLanguage(1).create(_hr2.default), new _vueMultilanguage.MLanguage(2).create(_sr2.default)
  // ,
  // new MLanguage(3).create(EN)
  ]
});

});

require.register("lang/sr.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    sidebar: {
        radna_ploca: 'Radna ploča',
        komponente: 'Komponente',
        cesta_pitanja: 'Česta pitanja',
        pomoc: 'POMOĆ'
    }

};

});

require.register("modules/app.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

var _auth = require('auth');

var _auth2 = _interopRequireDefault(_auth);

var _module = require('./auth/module');

var _module2 = _interopRequireDefault(_module);

var _module3 = require('./home/module');

var _module4 = _interopRequireDefault(_module3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var requireAuth = function requireAuth(to, from, next) {
    if (!_auth2.default.isAuthenticated()) {
        next({
            name: 'auth.prijava'
        });
    } else {
        next();
    }
};

exports.default = {
    name: 'App',
    created: function created() {
        var _this = this;

        var toastOptions = {
            className: "v-alert v-alert--notification",
            position: "top-center",
            duration: 5000,
            action: {
                icon: 'cancel',
                onClick: function onClick(e, toastObject) {
                    toastObject.goAway(0);
                }
            }
        };

        _vue2.default.prototype.$toast = {
            error: function error(message) {
                return _this.$toasted.error(message, toastOptions);
            },
            show: function show(message) {
                return _this.$toasted.show(message, toastOptions);
            },
            info: function info(message) {
                return _this.$toasted.info(message, toastOptions);
            },
            success: function success(message) {
                return _this.$toasted.success(message, toastOptions);
            }
        };
    },
    mounted: function mounted() {},


    routes: [{
        path: '*',
        redirect: '/home/dashboard'
    }, {
        path: '/auth',
        component: _module2.default,
        children: _module2.default.routes
    }, {
        path: '/home',
        component: _module4.default,
        children: _module4.default.routes,
        beforeEnter: requireAuth
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('transition',{attrs:{"name":"fade"}},[_c('router-view')],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/auth/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _prijava = require('./prijava');

var _prijava2 = _interopRequireDefault(_prijava);

var _config = require('config');

var _config2 = _interopRequireDefault(_config);

var _auth = require('auth');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var routes = [{
    path: 'aktiviraj',
    name: 'auth.aktiviraj'
}];

routes.unshift({
    path: '',
    redirect: 'prijava'
});
routes.push({
    path: 'prijava',
    name: 'auth.prijava',
    component: _prijava2.default
});

exports.default = {
    name: 'Auth',
    routes: routes
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/auth/prijava.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _auth = require('auth');

var _auth2 = _interopRequireDefault(_auth);

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _resources = require('api/resources');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Prijava',
    data: function data() {
        return {
            valid: false,
            e1: true,
            korisnickoIme: '',
            odabranaUloga: null,
            uloge: null,
            korisnickoImeRules: [function (v) {
                return !!v || 'Korisničko ime je obavezno';
            }],
            lozinkaRules: [function (v) {
                return !!v || 'Lozinka je obavezna';
            }],
            lozinka: ''
        };
    },


    methods: {
        provjeriLozinku: function provjeriLozinku() {
            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);
            var that = this;

            function success(model) {
                console.log(model);
                var uloge = model.body.items;
                if (uloge.length === 1) {
                    that.onSubmit(uloge[0].id);
                } else {
                    that.uloge = uloge;
                    that.odabranaUloga = uloge[0].id;
                }
            }

            function error() {
                that.$toast.error("Pogrešno korisničko ime ili lozinka. Pokušajte ponovo...");
            }

            if (that.valid) {
                (0, _resources.TokenResource)().provjeriLozinku({
                    korisnickoIme: that.korisnickoIme
                }, {
                    lozinka: that.lozinka
                }).then(success, error);
            }
        },
        onSubmit: function onSubmit(ulogaId) {
            var that = this;
            var success = function success() {
                console.log("RADI");

                var token = _identity2.default.getToken();
                if (token.vlasnik.jezik) {
                    that.$store.commit('tmsVuex/setOdabraniJezik', token.vlasnik.jezik);
                }
                window.location.href = '/';
            };
            var error = function error() {
                that.$toast.error("Pogrešno korisničko ime ili lozinka. Pokušajte ponovo...");
            };

            _auth2.default.signIn(that.korisnickoIme, that.lozinka, ulogaId).then(success, error);
        }
    },

    beforeMount: function beforeMount() {
        if (_auth2.default.isAuthenticated()) {
            this.$router.push({
                name: 'home.dashboard'
            });
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-app',{attrs:{"id":"prijava-cont"}},[_c('v-layout',{staticClass:"text-xs-center flex-0",attrs:{"row":""}},[_c('v-flex',{attrs:{"id":"prijava"}})],1),_vm._v(" "),_c('v-layout',{staticClass:"prijava-form",staticStyle:{"margin-top":"220px"},attrs:{"justify-center":"","wrap":""}},[_c('v-flex',{attrs:{"xs12":"","md8":"","lg4":""}},[_c('material-card',{attrs:{"color":"primary","title":"Prijava","text":"Unesite podatke za prijavu"}},[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-container',{attrs:{"py-0":""}},[_c('v-layout',{attrs:{"column":"","wrap":""}},[_c('v-flex',{attrs:{"xs12":"","md4":""}},[_c('v-text-field',{staticClass:"required",attrs:{"autofocus":true,"placeholder":" ","id":"korisnicko-ime","label":"Korisničko ime","rules":_vm.korisnickoImeRules,"required":""},on:{"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.provjeriLozinku()}},model:{value:(_vm.korisnickoIme),callback:function ($$v) {_vm.korisnickoIme=$$v},expression:"korisnickoIme"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","md4":""}},[_c('v-text-field',{staticClass:"required",attrs:{"placeholder":" ","id":"lozinka","label":"Lozinka","append-icon":_vm.e1 ? 'visibility' : 'visibility_off',"append-icon-cb":function () { return (_vm.e1 = !_vm.e1); },"type":_vm.e1 ? 'password' : 'text',"rules":_vm.lozinkaRules,"required":""},on:{"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.provjeriLozinku()}},model:{value:(_vm.lozinka),callback:function ($$v) {_vm.lozinka=$$v},expression:"lozinka"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","text-xs-right":""}},[_c('v-btn',{attrs:{"type":"button","id":"prijava-btn","color":"primary"},on:{"click":function($event){return _vm.provjeriLozinku()}}},[_vm._v("Prijava")])],1)],1)],1)],1)],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/event-bus.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var EventBus = new _vue2.default(); // event-bus.js
exports.default = EventBus;

});

require.register("modules/home/components/card.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _offset = require('./offset');

var _offset2 = _interopRequireDefault(_offset);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'Card',
  components: {
    Offset: _offset2.default
  },
  inheritAttrs: false,

  props: {
    color: {
      type: String,
      default: 'secondary'
    },
    elevation: {
      type: [Number, String],
      default: 10
    },
    inline: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    offset: {
      type: [Number, String],
      default: 24
    },
    title: {
      type: String,
      default: undefined
    },
    text: {
      type: String,
      default: undefined
    }
  },

  computed: {
    hasOffset: function hasOffset() {
      return this.$slots.header || this.$slots.offset || this.title || this.text;
    },
    styles: function styles() {
      if (!this.hasOffset) return null;

      return {
        marginBottom: this.offset + 'px',
        marginTop: this.offset + 'px'
      };
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-card',_vm._g(_vm._b({style:(_vm.styles)},'v-card',_vm.$attrs,false),_vm.$listeners),[(_vm.hasOffset)?_c('offset',{attrs:{"inline":_vm.inline,"full-width":_vm.fullWidth,"offset":_vm.offset}},[(!_vm.$slots.offset)?_c('v-card',{staticClass:"v-card--material__header",class:("elevation-" + _vm.elevation),attrs:{"color":_vm.color,"dark":""}},[(!_vm.title && !_vm.text)?_vm._t("header"):_c('span',[_c('h4',{staticClass:"title font-weight-light mb-2",domProps:{"textContent":_vm._s(_vm.title)}}),_vm._v(" "),_c('p',{staticClass:"category font-weight-thin",domProps:{"textContent":_vm._s(_vm.text)}})])],2):_vm._t("offset")],2):_vm._e(),_vm._v(" "),_c('v-card-text',[_vm._t("default")],2),_vm._v(" "),(_vm.$slots.actions)?_c('v-divider',{staticClass:"mx-3"}):_vm._e(),_vm._v(" "),(_vm.$slots.actions)?_c('v-card-actions',[_vm._t("actions")],2):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/chart-card.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lineChart = require('./charts/line-chart.vue');

var _lineChart2 = _interopRequireDefault(_lineChart);

var _barChart = require('./charts/bar-chart.vue');

var _barChart2 = _interopRequireDefault(_barChart);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ChartCard',
  components: {
    LineChart: _lineChart2.default,
    BarChart: _barChart2.default
  },
  data: function data() {
    return {};
  },

  inheritAttrs: false,

  props: {
    data: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    eventHandlers: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    line_options: {
      type: Object,
      default: function _default() {
        return {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true,
                fontColor: 'rgba(255, 255, 255, 0.7)'
              },
              gridLines: {
                color: 'rgba(255, 255, 255, 0.2)',
                borderDash: [1],
                borderDashOffset: 0.8,
                lineWidth: 2,
                drawBorder: false,
                zeroLineColor: 'rgba(255, 255, 255, 0.2)'
              }
            }],
            xAxes: [{
              ticks: {
                fontColor: 'rgba(255, 255, 255, 0.7)'
              },
              gridLines: {
                color: 'rgba(255, 255, 255, 0.2)',
                borderDash: [1],
                borderDashOffset: 0.8,
                lineWidth: 2,
                drawBorder: false,
                zeroLineColor: 'rgba(255, 255, 255, 0.2)'
              }
            }]
          },
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: false
          },
          layout: {
            padding: {
              left: 5,
              right: 15,
              top: 15,
              bottom: 5
            }
          }
        };
      }
    },
    ratio: {
      type: String,
      default: undefined
    },
    responsiveOptions: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    type: {
      type: String,
      required: true,
      validator: function validator(v) {
        return ['Bar', 'Line', 'Pie'].includes(v);
      }
    },
    bar_options: {
      type: Object,
      default: function _default() {
        return {
          scales: {
            yAxes: [{
              ticks: {
                fontColor: 'rgba(255, 255, 255, 0.7)'
              },
              gridLines: {
                color: 'rgba(255, 255, 255, 0.2)',
                borderDash: [1],
                borderDashOffset: 0.8,
                lineWidth: 2,
                drawBorder: false,
                zeroLineColor: 'rgba(255, 255, 255, 0.2)'
              }
            }],
            xAxes: [{
              barThickness: 15,
              ticks: {
                fontColor: 'rgba(255, 255, 255, 0.7)'
              },
              gridLines: {
                display: false,
                color: 'rgba(255, 255, 255, 0.2)',
                borderDash: [1],
                borderDashOffset: 0.8,
                lineWidth: 2,
                drawBorder: false,
                zeroLineColor: 'rgba(255, 255, 255, 0.2)'
              }
            }]
          },
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: false
          },
          layout: {
            padding: {
              left: 5,
              right: 15,
              top: 15,
              bottom: 5
            }
          }
        };
      }
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('material-card',_vm._g(_vm._b({staticClass:"v-card--material-chart"},'material-card',_vm.$attrs,false),_vm.$listeners),[(_vm.type=='Bar')?_c('bar-chart',{attrs:{"slot":"header","height":200,"chartdata":_vm.data,"options":_vm.bar_options},slot:"header"}):_vm._e(),_vm._v(" "),(_vm.type=='Line')?_c('line-chart',{attrs:{"slot":"header","height":200,"chartdata":_vm.data,"options":_vm.line_options},slot:"header"}):_vm._e(),_vm._v(" "),_vm._t("default"),_vm._v(" "),_vm._t("actions",null,{"slot":"actions"})],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/charts/bar-chart.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vueChartjs = require('vue-chartjs');

exports.default = {
  extends: _vueChartjs.Bar,
  props: {
    chartdata: {
      type: Object,
      default: null
    },
    options: {
      type: Object,
      default: null
    }
  },
  mounted: function mounted() {
    this.renderChart(this.chartdata, this.options);
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)

});

;require.register("modules/home/components/charts/line-chart.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vueChartjs = require("vue-chartjs");

exports.default = {
  extends: _vueChartjs.Line,
  props: {
    chartdata: {
      type: Object,
      default: null
    },
    options: {
      type: Object,
      default: null
    }
  },
  mounted: function mounted() {
    this.renderChart(this.chartdata, this.options);
  },

  watch: {
    chartdata: function chartdata(newValue, oldValue) {
      console.log("IZMJENA", newValue);
      if (newValue !== oldValue) {
        this.renderChart(newValue, this.options);
      }
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)

});

;require.register("modules/home/components/constant.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var MONTH_NAMES = exports.MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

});

require.register("modules/home/components/custom-map.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _postavke = require('postavke/postavke');

var _postavke2 = _interopRequireDefault(_postavke);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'CustomMap',

    props: {
        center: {
            default: function _default() {
                return [43.8400724, 18.3410865];
            }
        }
    },

    data: function data() {
        return {
            postavke: _postavke2.default
        };
    },


    methods: {
        onClick: function onClick(args) {
            this.$emit('click', args);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-map',{staticClass:"map-widget",attrs:{"zoom":12,"center":_vm.center},on:{"l-click":_vm.onClick}},[_c('v-tilelayer',{attrs:{"url":_vm.postavke.urlKarte(),"attribution":_vm.postavke.autorskaPravaKarte()}}),_vm._v(" "),_vm._t("default")],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/date-format.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'DateFormat',

    props: {
        vrijednost: {
            default: null
        },
        format: {
            default: 'DD. MM. YYYY.'
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('span',{staticClass:"date"},[_vm._v(_vm._s(_vm._f("moment")(_vm.vrijednost,_vm.format)))])}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/help-tip-dialog.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: "HelpTipDialog",
  props: {
    title: {
      default: null
    },
    content: {
      default: null
    },
    okDugme: {
      default: "Uredu"
    }

  },
  data: function data() {
    return {
      dialog: true,
      identity: _identity2.default
    };
  },
  created: function created() {
    var _this = this;

    window.addEventListener("keyup", function (evt) {
      if (evt.keyCode == 27) _this.zatvori();
    });
    window.addEventListener("click", function () {
      _this.zatvori();
    });
  },


  methods: {
    zatvori: function zatvori(result) {
      this.$emit("zatvori", result);
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-layout',{staticStyle:{"position":"relative"},attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"id":"dialog-help-tip","lazy":"","absolute":"","max-width":"600px"},model:{value:(_vm.dialog),callback:function ($$v) {_vm.dialog=$$v},expression:"dialog"}},[_c('v-card',[_c('v-card-title',{staticClass:"headline"},[_vm._v(_vm._s(_vm.title))]),_vm._v(" "),_c('v-card-text',[_c('ul',{staticClass:"tags"},_vm._l((_vm.content.split('.')),function(red){return _c('li',[_vm._v(_vm._s(red))])}),0)]),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{staticClass:"secondary--text darken-1",attrs:{"flat":"flat"},nativeOn:{"click":function($event){return _vm.zatvori(false)}}},[_vm._v(_vm._s(_vm.okDugme))])],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []
__vue__options__._scopeId = "data-v-93b1322e"

});

;require.register("modules/home/components/loading.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'Loading'
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"loading"}},[_c('v-app',[_c('v-progress-circular',{attrs:{"indeterminate":"","size":120}})],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/m-datepicker.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'MDatePicker',
    props: {
        value: {
            default: null
        },
        mask: {
            default: '##. ##. ####.'
        },
        dateFormat: {
            default: 'DDMMYYYY'
        },
        inputClass: {
            type: String
        },
        required: {
            type: Boolean,
            default: false
        },
        label: {
            type: String
        },
        disabled: {
            type: Boolean,
            default: false
        },
        allowedDates: {
            default: function _default() {
                return function () {
                    return true;
                };
            }
        }
    },
    data: function data() {
        return {
            menu: false,
            dateTimeValueInput: '',
            dateTimeValuePicker: null,
            rules: []
        };
    },

    computed: {
        dateTimeValue: function dateTimeValue() {
            return this.value;
        }
    },
    created: function created() {
        var _this = this;

        if (this.required) {
            this.rules.push(function (v) {
                return !!v || "Polje je obavezno";
            });
        }
        this.rules.push(function (v) {
            return !v || _moment2.default.utc(v, _this.dateFormat, true).isValid() || 'Datum nije ispravan';
        });
        this.rules.push(function (v) {
            return !v || !_moment2.default.utc(v, _this.dateFormat, true).isValid() || _this.allowedDates(_moment2.default.utc(v, _this.dateFormat, true).toDate()) || 'Datum nije dozvoljen';
        });

        this.update(this.value);
    },


    watch: {
        value: function value(newValue, oldValue) {
            if (newValue !== oldValue) {
                var datum = _moment2.default.utc(newValue);
                if (newValue != null && this.ispravanDatum(datum)) {
                    this.dateTimeValueInput = _moment2.default.utc(newValue).format(this.dateFormat);
                    this.dateTimeValuePicker = _moment2.default.utc(newValue).format("YYYY-MM-DD");
                } else {
                    this.dateTimeValueInput = "";

                    this.dateTimeValuePicker = _moment2.default.utc().format();
                }
            }
        }
    },

    methods: {
        update: function update(value) {
            var datum = _moment2.default.utc(value);
            if (this.ispravanDatum(datum)) {
                this.dateTimeValuePicker = _moment2.default.utc(value).format("YYYY-MM-DD");
                this.dateTimeValueInput = _moment2.default.utc(value).format(this.dateFormat);
                this.emit();
            }
        },
        closeMenu: function closeMenu() {
            this.$refs.menu.save(this.dateTimeValuePicker);

            var datum = _moment2.default.utc(this.dateTimeValuePicker);
            if (!this.ispravanDatum(datum)) {
                this.dateTimeValuePicker = '';
            }
            this.emit();
        },
        ispravanDatum: function ispravanDatum(datum) {
            return datum.isValid() && this.allowedDates(datum.toDate());
        },
        updateDatepicker: function updateDatepicker() {
            var datum = _moment2.default.utc(this.dateTimeValueInput, this.dateFormat, true);
            if (this.ispravanDatum(datum)) {
                this.dateTimeValuePicker = datum.format("YYYY-MM-DD");
            } else {
                this.dateTimeValuePicker = '';
            }
            this.emit();
        },
        emit: function emit() {
            var datum = _moment2.default.utc(this.dateTimeValuePicker);

            if (this.ispravanDatum(datum)) {
                this.$emit('input', _moment2.default.utc(this.dateTimeValuePicker).toDate());
            } else {
                this.$emit('input', null);
            }
        },
        getStringDate: function getStringDate() {
            return this.dateTimeValueInput;
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-layout',[_c('v-flex',[_c('v-menu',{ref:"menu",attrs:{"disabled":_vm.disabled,"offset-x":"","close-on-content-click":false,"full-width":""},model:{value:(_vm.menu),callback:function ($$v) {_vm.menu=$$v},expression:"menu"}},[_c('v-text-field',{class:{inputClass: true, 'required': _vm.required},attrs:{"slot":"activator","append-icon":"event","mask":_vm.mask,"label":_vm.label,"rules":_vm.rules,"header-date-format":_vm.headerDate,"type":"text","disabled":_vm.disabled,"required":_vm.required},on:{"input":function($event){return _vm.updateDatepicker()}},slot:"activator",model:{value:(_vm.dateTimeValueInput),callback:function ($$v) {_vm.dateTimeValueInput=$$v},expression:"dateTimeValueInput"}}),_vm._v(" "),_c('v-date-picker',{ref:"datepicker",staticClass:"datepicker-menu",attrs:{"width":"290","no-title":"","locale":"sr-Latn-BA","actions":"","allowed-dates":_vm.allowedDates,"first-day-of-week":1},nativeOn:{"dblclick":function($event){return _vm.closeMenu($event)}},model:{value:(_vm.dateTimeValuePicker),callback:function ($$v) {_vm.dateTimeValuePicker=$$v},expression:"dateTimeValuePicker"}},[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary"},nativeOn:{"click":function($event){_vm.menu = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary"},nativeOn:{"click":function($event){return _vm.closeMenu($event)}}},[_vm._v("Odaberi")])],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/m-info-dialog.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'MInfoDialog',
    props: {
        title: {
            default: null
        },
        content: {
            default: null
        },
        okDugme: {
            default: "Uredu"
        }
    },
    data: function data() {
        return {
            dialog: false
        };
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-layout',[_c('v-btn',{attrs:{"flat":""},nativeOn:{"click":function($event){$event.stopPropagation();_vm.dialog = true}}},[_vm._v("Normal")]),_vm._v(" "),_c('v-dialog',{model:{value:(_vm.dialog),callback:function ($$v) {_vm.dialog=$$v},expression:"dialog"}},[_c('v-card',[_c('v-card-title',{staticClass:"headline"},[_vm._v(_vm._s(_vm.title))]),_vm._v(" "),_c('v-card-text',[_vm._v(_vm._s(_vm.content))]),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{staticClass:"green--text darken-1",attrs:{"flat":"flat"},nativeOn:{"click":function($event){_vm.dialog = false}}},[_vm._v(_vm._s(_vm.okDugme))])],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/m-question-dialog.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: "MQuestionDialog",
    props: {
        aktivan: {
            type: Boolean
        },
        header: {
            default: null
        },
        body: {
            default: null
        },
        okDugme: {
            default: "Uredu"
        },
        odustani: {
            default: "Odustani"
        },
        width: {
            type: String,
            default: "500"
        }
    },
    data: function data() {
        return {
            dialog: false
        };
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-layout',{staticStyle:{"position":"relative"},attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":_vm.width},model:{value:(_vm.aktivan),callback:function ($$v) {_vm.aktivan=$$v},expression:"aktivan"}},[_c('v-card',{staticClass:"upis-dialog"},[_c('v-card-title',{staticClass:"headline"},[_vm._v(_vm._s(_vm.header))]),_vm._v(" "),_c('v-card-text',[_vm._v(_vm._s(_vm.body))]),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.$emit('close', {potvrdi: true})}}},[_vm._v(_vm._s(_vm.okDugme))]),_vm._v(" "),_c('v-btn',{attrs:{"flat":"flat"},on:{"click":function($event){return _vm.$emit('close', {potvrdi: false})}}},[_vm._v(_vm._s(_vm.odustani))])],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/markdown-editor.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _simplemde = require('simplemde');

var _simplemde2 = _interopRequireDefault(_simplemde);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'MarkdownEditor',

    props: {
        value: String
    },

    ready: function ready() {
        this.initialize();
        this.syncValue();
    },
    mounted: function mounted() {
        this.initialize();
    },


    methods: {
        initialize: function initialize() {
            var config = {
                element: this.$el,
                initialValue: this.value,
                spellChecker: false,
                status: false
            };

            this.simpleMde = new _simplemde2.default(config);
            this.bindingEvents();
        },
        bindingEvents: function bindingEvents() {
            var _this = this;

            this.simpleMde.codemirror.on('change', function () {
                _this.$emit('input', _this.simpleMde.value());
            });
        },
        syncValue: function syncValue() {
            var _this2 = this;

            this.simpleMde.codemirror.on('change', function () {
                _this2.value = _this2.simpleMde.value();
            });
        }
    },

    destroyed: function destroyed() {
        this.simpleMde = null;
    },


    watch: {
        value: function value(val) {
            if (val === this.simpleMde.value()) return;
            this.simpleMde.value(val);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('textarea')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/markdown.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _marked = require('marked');

var _marked2 = _interopRequireDefault(_marked);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Markdown',

    props: {
        value: String
    },

    computed: {
        renderedMarkdown: function renderedMarkdown() {
            return (0, _marked2.default)(this.value);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{domProps:{"innerHTML":_vm._s(_vm.renderedMarkdown)}})}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/notification.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  name: 'Notification',
  inheritAttrs: false,

  props: {
    elevation: {
      type: [Number, String],
      default: 6
    },
    value: {
      type: Boolean,
      default: true
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-alert',_vm._g(_vm._b({staticClass:"v-alert--notification",class:[("elevation-" + _vm.elevation)],attrs:{"value":_vm.value}},'v-alert',_vm.$attrs,false),_vm.$listeners),[_vm._t("default")],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/notifikacija.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    props: {
        broj: {
            type: Number
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticStyle:{"max-height":"30px"}},[_c('v-badge',{attrs:{"overlap":"","color":"error"}},[(_vm.broj > 0)?_c('span',{attrs:{"slot":"badge"},slot:"badge"},[_vm._v(_vm._s(_vm.broj))]):_vm._e(),_vm._v(" "),_c('v-avatar',{attrs:{"size":"30px"}},[_c('v-icon',{attrs:{"dark":"","color":"grey"}},[_vm._v("notifications")])],1)],1)],1)}
__vue__options__.staticRenderFns = []
__vue__options__._scopeId = "data-v-697778d9"

});

;require.register("modules/home/components/o-iframe.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'Oiframe',
    props: {
        url: {
            default: null
        },
        ratio: {
            default: false
        }
    },

    mounted: function mounted() {
        this.setUrl();
    },
    created: function created() {
        var that = this;

        setInterval(function () {
            that.fixSize();
        }, 200);
    },


    watch: {
        url: function url() {
            this.setUrl();
        }
    },
    methods: {
        setUrl: function setUrl() {

            var vif = this.$refs.theiframe;
            if (this.url && this.url != '#') vif.src = this.url;
            this.calculateSize();
        },
        fixSize: function fixSize() {
            var vif = document.getElementById('theiframe');
            if (vif) {
                var table = vif.contentWindow.document.getElementById('ReportViewerRSFReports_fixedTable');
                if (table) {
                    table.style.width = '100%';
                }
            }
        },
        calculateSize: function calculateSize() {

            var vif = this.$refs.theiframe;
            var maxWidth = vif.parentElement.getBoundingClientRect().width;
            var maxHeight = vif.parentElement.getBoundingClientRect().height;
            var height = 0;
            if (ratio) {
                var ratio = vif.height / vif.width;
                height = maxWidth * ratio;
            } else {
                height = maxHeight - 35;
            }
            vif.style.height = height + 'px';
            vif.style.width = '100%';
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('iframe',{ref:"theiframe",attrs:{"id":"theiframe","frameborder":"0","allowfullscreen":"","scrolling":"yes"}})}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/obrisi-modal.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: "ObrisiModal",
    props: {
        aktivan: {
            type: Boolean
        },
        header: {
            type: String
        },
        body: {
            type: String
        },
        obrisi: {
            type: String,
            default: "Obriši"
        },
        odustani: {
            type: String,
            default: "Odustani"
        },
        width: {
            type: String,
            default: "290"
        },
        item: {
            type: Number
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-layout',{staticStyle:{"position":"relative"},attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":_vm.width},model:{value:(_vm.aktivan),callback:function ($$v) {_vm.aktivan=$$v},expression:"aktivan"}},[_c('v-card',[_c('v-card-title',{staticClass:"headline"},[_vm._v(_vm._s(_vm.header))]),_vm._v(" "),_c('v-card-text',{staticClass:"mb-3"},[_vm._v("\r\n                "+_vm._s(_vm.body))]),_vm._v(" "),_c('v-card-actions',{staticClass:"text-xs-center"},[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"tertiary"},on:{"click":function($event){return _vm.$emit('close', {obrisi: false, id: _vm.item})}}},[_vm._v(_vm._s(_vm.odustani))]),_vm._v(" "),_c('v-btn',{attrs:{"primary":""},on:{"click":function($event){return _vm.$emit('close', {obrisi: true, id: _vm.item})}}},[_vm._v(_vm._s(_vm.obrisi))]),_vm._v(" "),_c('v-spacer')],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/odustani-btn.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'OdustaniBtn',
    methods: {
        odustani: function odustani() {
            this.$emit('odustani', true);
            this.$router.go(-1);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-btn',{attrs:{"color":"tertiary"},on:{"click":function($event){return _vm.odustani()}}},[_vm._v("\r\n    Odustani")])}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/offset.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  name: 'Offset',
  props: {
    fullWidth: {
      type: Boolean,
      default: false
    },
    offset: {
      type: [Number, String],
      default: 0
    }
  },

  computed: {
    classes: function classes() {
      return {
        'v-offset--full-width': this.fullWidth
      };
    },
    styles: function styles() {
      return {
        top: '-' + this.offset + 'px',
        marginBottom: '-' + this.offset + 'px'
      };
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"v-offset",class:_vm.classes,style:(_vm.styles)},[_vm._t("default")],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/page.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'Page',

    props: {
        resolved: {
            default: true
        },
        title: {
            default: null
        }
    },

    methods: {
        navigate: function navigate(location) {
            this.$router.push(location);
        }
    },

    computed: {
        haveTitle: function haveTitle() {
            return this.title && this.title.length;
        },
        haveHeader: function haveHeader() {
            return this.haveTitle;
        },
        isResolving: function isResolving() {
            return !this.resolved;
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-content"},[(_vm.haveTitle)?_c('h2',{staticClass:"glavni-naslov"},[_vm._v(_vm._s(_vm.title))]):_vm._t("default")],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/prettyprint.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Prettyprint',
    props: {
        value: String
    },

    mounted: function mounted() {
        var codeholder = this.$refs.codeholder;
        this.editor = window.CodeMirror.fromTextArea(codeholder, {
            lineNumbers: true,
            mode: 'javascript',
            matchBrackets: true,
            theme: 'solarized' });

        var jsonObject = JSON.parse(this.value);
        var pretty = (0, _stringify2.default)(jsonObject, null, 2);
        this.editor.setValue(pretty);
    },


    watch: {
        value: function value() {

            var jsonObject = JSON.parse(this.value);
            var pretty = (0, _stringify2.default)(jsonObject, null, 2);
            this.editor.setValue(pretty);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"row"},[_c('textarea',{ref:"codeholder"})])}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/stats-card.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _card = require('./card');

var _card2 = _interopRequireDefault(_card);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'StatsCard',
  inheritAttrs: false,
  components: {
    Card: _card2.default
  },

  props: {
    color: {
      type: String,
      default: 'secondary'
    },
    elevation: {
      type: [Number, String],
      default: 10
    },
    inline: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    offset: {
      type: [Number, String],
      default: 24
    },
    text: {
      type: String,
      default: undefined
    },
    icon: {
      type: String,
      required: true
    },
    subIcon: {
      type: String,
      default: undefined
    },
    subIconColor: {
      type: String,
      default: undefined
    },
    subTextColor: {
      type: String,
      default: undefined
    },
    subText: {
      type: String,
      default: undefined
    },
    title: {
      type: String,
      default: undefined
    },
    value: {
      type: String,
      default: undefined
    },
    smallValue: {
      type: String,
      default: undefined
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('material-card',_vm._g(_vm._b({staticClass:"v-card--material-stats"},'material-card',_vm.$attrs,false),_vm.$listeners),[_c('v-card',{staticClass:"pa-4",class:("elevation-" + _vm.elevation),attrs:{"slot":"offset","color":_vm.color,"dark":""},slot:"offset"},[_c('v-icon',{attrs:{"size":"40"}},[_vm._v("\n      "+_vm._s(_vm.icon)+"\n    ")])],1),_vm._v(" "),_c('div',{staticClass:"text-xs-right"},[_c('p',{staticClass:"category grey--text font-weight-light",domProps:{"textContent":_vm._s(_vm.title)}}),_vm._v(" "),_c('h3',{staticClass:"title display-1 font-weight-light"},[_vm._v("\n      "+_vm._s(_vm.value)+" "),_c('small',[_vm._v(_vm._s(_vm.smallValue))])])]),_vm._v(" "),_c('template',{slot:"actions"},[_c('v-icon',{staticClass:"mr-2",attrs:{"color":_vm.subIconColor,"size":"20"}},[_vm._v("\n      "+_vm._s(_vm.subIcon)+"\n    ")]),_vm._v(" "),_c('span',{staticClass:"caption font-weight-light",class:_vm.subTextColor,domProps:{"textContent":_vm._s(_vm.subText)}})],1)],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/components/upit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: "Upit",
    props: {
        poruka: {
            default: "Jeste li sigurni da želite napustiti trenutnu formu?"
        },
        da: {
            default: "Da"
        },
        ne: {
            default: "Ne"
        },
        buttonClass: {
            default: "secondary--text darken-1"
        },
        width: {
            default: 290
        },
        outline: {
            default: false
        }
    },
    data: function data() {
        return {
            dialog: {}
        };
    },


    methods: {
        odgovori: function odgovori(result) {
            this.dialog = false;
            this.$emit("odgovor", result);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('v-app',[_c('v-dialog',{attrs:{"persistent":"","max-width":_vm.width},model:{value:(_vm.dialog),callback:function ($$v) {_vm.dialog=$$v},expression:"dialog"}},[_c('v-card',[_c('v-card-title',[_c('div',{staticClass:"headline"},[_vm._v("Upozorenje")])]),_vm._v(" "),_c('v-card-text',[_vm._v(_vm._s(_vm.poruka)+" ")]),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{class:_vm.buttonClass,attrs:{"outline":_vm.outline,"flat":"flat"},nativeOn:{"click":function($event){return _vm.odgovori(false)}}},[_vm._v(_vm._s(_vm.ne))]),_vm._v(" "),_c('v-btn',{class:_vm.buttonClass,attrs:{"outline":_vm.outline,"flat":"flat"},nativeOn:{"click":function($event){return _vm.odgovori(true)}}},[_vm._v(_vm._s(_vm.da))])],1)],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/dashboard.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _defineProperty2 = require("babel-runtime/helpers/defineProperty");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _chartist = require("chartist");

var _chartist2 = _interopRequireDefault(_chartist);

var _list = require("./zahtjev/list.vue");

var _list2 = _interopRequireDefault(_list);

var _list3 = require("./projekat/list.vue");

var _list4 = _interopRequireDefault(_list3);

var _resources = require("api/resources");

var _blok = require("./widgets/blok");

var _blok2 = _interopRequireDefault(_blok);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "Dashboard",
    components: {
        ListaZahtjevaProjekat: _list2.default,
        ListaProjekata: _list4.default
    },

    data: function data() {
        return (0, _defineProperty3.default)({
            stiglo: false,
            ucitanBrojKreiranihZahtjevaPoDanimaProslaSedmica: false,
            ucitanBrojZavrsenihZahtjevaPoDanimaProslaSedmica: false,
            ucitanBrojZahtjevaPoProjektu: false,
            ucitaniZahtjeviNajduzeUPotrebnoUraditi: false,
            ucitaniZahtjeviZadnjiDodatiKojeJePotrebnoUraditi: false,
            ucitaniSviProjektiKorisnika: false,
            ucitanBrojZahtjevaPoSedmicama: false,
            ucitanBrojZahtjevaPoMjesecima: false,
            ucitanBrojZahtjevaPoDanimaAktivnaGodina: false,
            ucitaniZahtjeviZadnjiDodatiNisuRijeseni: false,
            ucitaniZahtjeviZadnjiRijeseni: false,
            identity: _identity2.default,
            trenutnaUlogaId: {},

            model: {},
            zavrseniZahtjeviProslaSedmicaChart: {
                data: {
                    labels: ['Pon', 'Uto', 'Sri', 'Čet', 'Pet', 'Sub', 'Ned'],
                    datasets: [{
                        fill: false,
                        label: 'Dnevni broj zadataka',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: []
                    }]

                }
            },
            kreiraniZahtjeviProslaSedmicaChart: {
                data: {
                    labels: ['Pon', 'Uto', 'Sri', 'Čet', 'Pet', 'Sub', 'Ned'],
                    datasets: [{
                        fill: false,
                        label: 'Dnevni broj zadataka',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: []
                    }]

                }
            },
            zahtjeviPoProjektimaChart: {

                data: {
                    labels: [],
                    datasets: [{
                        fill: false,
                        label: 'Broj zadataka',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: []
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            },

            dataCompletedTasksChart: {
                data: {
                    labels: ['12am', '3pm', '6pm', '9pm', '12pm', '3am', '6am', '9am'],
                    datasets: [{
                        fill: false,
                        label: 'Completed Tasks',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: [230, 750, 450, 300, 280, 240, 200, 190]
                    }]
                }
            },
            emailsSubscriptionChart: {
                data: {
                    labels: ['Ja', 'Fe', 'Ma', 'Ap', 'Mai', 'Ju', 'Jul', 'Au', 'Se', 'Oc', 'No', 'De'],
                    datasets: [{
                        label: 'Email Subscription',
                        borderColor: 'rgba(255, 255, 255, 0.9)',
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        data: [542, 443, 320, 780, 553, 453, 326, 434, 568, 610, 756, 895]
                    }]
                }
            },

            zahtjeviPoMjesecimaChart: {
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'],
                    datasets: [{
                        fill: false,
                        label: 'Zadaci po mjesecima',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: []
                    }]

                }
            },

            zahtjeviPoDanimaAktivnaGodinaChart: {
                data: {
                    labels: ['Pon', 'Uto', 'Sri', 'Čet', 'Pet', "Sub", "Ned"],
                    datasets: [{
                        fill: false,
                        label: 'Zadaci po danima',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: []
                    }]

                }
            },

            zahtjeviPoSedmicamaChart: {
                data: {
                    labels: ['5', '4', '3', '2', '1'],
                    datasets: [{
                        fill: false,
                        label: 'Zadaci po sedmicama',
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        backgroundColor: 'white',
                        lineTension: 0,
                        data: []
                    }]

                }
            },
            zahtjeviNajduzeUPotrebnoUraditi: [],
            zahtjeviZadnjiDodatiKojeJePotrebnoUraditi: [],
            nazivZahtjeviNajduzeUPotrebnoUraditi: "Zadaci najduže u statusu: potrebno uraditi",
            nazivZahtjeviZadnjiDodatiKojeJePotrebnoUraditi: "Zadnji dodati zadaci koje potrebno uraditi",
            zahtjeviZadnjiDodatiNisuRijeseni: [],
            zahtjeviZadnjiRijeseni: [],

            tabs: 0,
            list: {
                0: false,
                1: false,
                2: false
            },
            lozinka: ""
        }, "identity", _identity2.default);
    },
    created: function created() {

        this.ulogaPorvjera();

        this.ucitajStatistikuZaDashboard();

        if (_identity2.default.imaPravo('osnovno_dashboard_zavrseni_zahtjevi_prosla_sedmica')) this.ucitajBrojZavrsenihZahtjevaPoDanimaProslaSedmica();

        if (_identity2.default.imaPravo('osnovno_dashboard_prijavljeni_zahtjevi_prosle_sedmice')) this.ucitajBrojKreiranihZahtjevaPoDanimaProslaSedmica();

        if (_identity2.default.imaPravo('osnovno_dashboard_broj_zahtjeva_po_projektu')) this.ucitajBrojZahtjevaPoProjektu();

        if (_identity2.default.imaPravo('osnovno_dashboard_zahtjevi_najduze_u_potrebno_uraditi')) this.ucitajZahtjeviNajduzeUPotrebnoUraditi();

        if (_identity2.default.imaPravo('osnovno_dashboard_zadnji_dodati_zahtjevi_potrebno_uraditi')) this.ucitajZahtjeviZadnjiDodatiKojeJePotrebnoUraditi();

        if (_identity2.default.imaPravo('osnovno_dashboard_broj_zahtjeva_po_mjesecima')) this.ucitajBrojZahtjevaPoMjesecima();

        if (_identity2.default.imaPravo('osnovno_dashboard_broj_zahtjeva_po_danima_aktivna_godina')) this.ucitajBrojZahtjevaPoDanimaAktivnaGodina();

        if (_identity2.default.imaPravo('osnovno_dashboard_zahtjevi_zadnji_dodati_nisu_rijeseni')) this.ucitajZahtjeviZadnjiDodatiNisuRijeseni();

        if (_identity2.default.imaPravo('osnovno_dashboard_zahtjevi_rijeseni')) this.ucitajZahtjeviZadnjiRijeseni();

        if (_identity2.default.imaPravo('osnovno_dashboard_broj_rijesenih_zahtjeva_po_sedmicama')) this.ucitajBrojZahtjevaPoSedmicama();

        window.addEventListener("resize", this.handleResize);
    },

    methods: {
        ucitajStatistikuZaDashboard: function ucitajStatistikuZaDashboard() {
            if (this.$route.name == "home.dashboard") {
                var that = this;

                var success = function success(model) {
                    that.stiglo = true;
                    that.model = model.body;
                    that.model.brojZahtjevaPotrebnoUraditi = that.model.brojZahtjevaPotrebnoUraditi.toString();
                    that.model.brojZahtjevaUProgresu = that.model.brojZahtjevaUProgresu.toString();
                    that.model.brojZavrsenihZahtjeva = that.model.brojZavrsenihZahtjeva.toString();
                    that.model.brojProjekata = that.model.brojProjekata.toString();

                    that.model.brojZahtjevaUkupno = that.model.brojZahtjevaUkupno.toString();
                    that.model.brojZahtjevaKojiNisuRijeseni = that.model.brojZahtjevaKojiNisuRijeseni.toString();
                    that.model.brojKomentaraKorisnika = that.model.brojKomentaraKorisnika.toString();
                };
                (0, _resources.DashboardResource)().statistika().then(success);
            }
        },
        ulogaPorvjera: function ulogaPorvjera() {
            var that = this;

            console.log(that.identity.uloga());
            if (that.identity.uloga() == 'Task user') {
                that.$router.push({ name: 'home.zahtjev.list' });
            }
        },
        ucitajBrojZavrsenihZahtjevaPoDanimaProslaSedmica: function ucitajBrojZavrsenihZahtjevaPoDanimaProslaSedmica() {
            var that = this;

            var success = function success(model) {
                that.ucitanBrojZavrsenihZahtjevaPoDanimaProslaSedmica = true;

                that.zavrseniZahtjeviProslaSedmicaChart.data.datasets[0].data = model.body;
            };

            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.DashboardResource)().zavrseniZahtjeviPoDanimaProslaSedmica();
            promise.then(success, error);
        },
        ucitajBrojKreiranihZahtjevaPoDanimaProslaSedmica: function ucitajBrojKreiranihZahtjevaPoDanimaProslaSedmica() {
            var that = this;

            var success = function success(model) {
                that.ucitanBrojKreiranihZahtjevaPoDanimaProslaSedmica = true;
                that.kreiraniZahtjeviProslaSedmicaChart.data.datasets[0].data = model.body;
            };

            (0, _resources.DashboardResource)().kreiraniZahtjeviPoDanimaProslaSedmica().then(success);
        },
        ucitajBrojZahtjevaPoProjektu: function ucitajBrojZahtjevaPoProjektu() {
            var that = this;

            var success = function success(model) {
                that.ucitanBrojZahtjevaPoProjektu = true;

                model.body.forEach(function (element) {
                    if (element.naziv.length > 17) {
                        that.zahtjeviPoProjektimaChart.data.labels.push(element.naziv.slice(0, 14) + "...");
                    } else {
                        that.zahtjeviPoProjektimaChart.data.labels.push(element.naziv);
                    }
                });

                model.body.forEach(function (element) {
                    that.zahtjeviPoProjektimaChart.data.datasets[0].data.push(element.ukupanBrojZahtjeva);
                });
            };

            (0, _resources.DashboardResource)().brojZahtjevaPoProjektu().then(success);
        },
        ucitajZahtjeviNajduzeUPotrebnoUraditi: function ucitajZahtjeviNajduzeUPotrebnoUraditi() {
            var that = this;

            var success = function success(model) {
                that.ucitaniZahtjeviNajduzeUPotrebnoUraditi = true;
                that.zahtjeviNajduzeUPotrebnoUraditi = model.body;
            };

            (0, _resources.DashboardResource)().zahtjeviNajduzeUPotrebnoUraditi().then(success);
        },
        ucitajZahtjeviZadnjiDodatiKojeJePotrebnoUraditi: function ucitajZahtjeviZadnjiDodatiKojeJePotrebnoUraditi() {
            var that = this;

            var success = function success(model) {
                that.ucitaniZahtjeviZadnjiDodatiKojeJePotrebnoUraditi = true;
                that.zahtjeviZadnjiDodatiKojeJePotrebnoUraditi = model.body;
            };

            (0, _resources.DashboardResource)().zahtjeviZadnjiDodatiKojeJePotrebnoUraditi().then(success);
        },
        ucitajSveProjekteKorisnika: function ucitajSveProjekteKorisnika() {
            var that = this;

            var success = function success(model) {
                that.ucitaniSviProjektiKorisnika = true;
            };
            (0, _resources.ProjekatResource)().vratiSveProjekte().then(success);
        },
        ucitajBrojZahtjevaPoDanimaAktivnaGodina: function ucitajBrojZahtjevaPoDanimaAktivnaGodina() {
            var that = this;

            var success = function success(model) {
                that.ucitanBrojZahtjevaPoDanimaAktivnaGodina = true;
                that.zahtjeviPoDanimaAktivnaGodinaChart.data.datasets[0].data = model.body;
            };
            (0, _resources.DashboardResource)().zahtjeviPoDanimaAktivnaGodina().then(success);
        },
        ucitajBrojZahtjevaPoMjesecima: function ucitajBrojZahtjevaPoMjesecima() {
            var that = this;

            var success = function success(model) {
                that.ucitanBrojZahtjevaPoMjesecima = true;
                that.zahtjeviPoMjesecimaChart.data.datasets[0].data = model.body;
            };
            (0, _resources.DashboardResource)().zahtjeviPoMjesecima().then(success);
        },
        ucitajBrojZahtjevaPoSedmicama: function ucitajBrojZahtjevaPoSedmicama() {
            var that = this;

            var success = function success(model) {
                that.ucitanBrojZahtjevaPoSedmicama = true;
                that.zahtjeviPoSedmicamaChart.data.datasets[0].data = model.body;
            };
            (0, _resources.DashboardResource)().zahtjeviPoSedmicama().then(success);
        },
        ucitajZahtjeviZadnjiDodatiNisuRijeseni: function ucitajZahtjeviZadnjiDodatiNisuRijeseni() {
            var that = this;

            var success = function success(model) {
                that.ucitaniZahtjeviZadnjiDodatiNisuRijeseni = true;
                that.zahtjeviZadnjiDodatiNisuRijeseni = model.body;
            };
            (0, _resources.DashboardResource)().zahtjeviZadnjiDodatiNisuRijeseni().then(success);
        },
        ucitajZahtjeviZadnjiRijeseni: function ucitajZahtjeviZadnjiRijeseni() {
            var that = this;

            var success = function success(model) {
                that.ucitaniZahtjeviZadnjiRijeseni = true;
                that.zahtjeviZadnjiRijeseni = model.body;
            };
            (0, _resources.DashboardResource)().zahtjeviZadnjiDodatiRijeseni().then(success);
        },
        handleResize: function handleResize() {
            if (this.$refs.onlinechart != null) {
                this.$refs.onlinechart.drawChart();
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.ulogaPorvjera)?_c('div',[_vm._v("\r\n    "+_vm._s(_vm.$ml.get('sidebar.radna_ploca'))+"\r\n\r\n    "),_c('v-layout',{attrs:{"wrap":""}},[(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_potrebno_uraditi'))?_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"green","icon":"question_answer","title":"Broj zadataka","sub-icon":"mdi-calendar","sub-text":"Zadaci koje je potrebno uraditi"},model:{value:(_vm.model.brojZahtjevaPotrebnoUraditi),callback:function ($$v) {_vm.$set(_vm.model, "brojZahtjevaPotrebnoUraditi", $$v)},expression:"model.brojZahtjevaPotrebnoUraditi"}})],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_u_progresu'))?_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"orange","icon":"filter_none","title":"Broj zadataka","sub-icon":"info","sub-icon-color":"error","sub-text":"Zadaci u progresu","sub-text-color":"text-primary"},model:{value:(_vm.model.brojZahtjevaUProgresu),callback:function ($$v) {_vm.$set(_vm.model, "brojZahtjevaUProgresu", $$v)},expression:"model.brojZahtjevaUProgresu"}})],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_ukupno'))?_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"green","icon":"filter_none","title":"Broj zadataka","sub-icon":"info","sub-text":"Ukupan broj zadataka","sub-text-color":"text-primary"},model:{value:(_vm.model.brojZahtjevaUkupno),callback:function ($$v) {_vm.$set(_vm.model, "brojZahtjevaUkupno", $$v)},expression:"model.brojZahtjevaUkupno"}})],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_nisu_rijeseni'))?_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"orange","icon":"filter_none","title":"Broj zahtjeva","sub-icon":"info","sub-icon-color":"error","sub-text":"Zadaci koji nisu riješeni","sub-text-color":"text-primary"},model:{value:(_vm.model.brojZahtjevaKojiNisuRijeseni),callback:function ($$v) {_vm.$set(_vm.model, "brojZahtjevaKojiNisuRijeseni", $$v)},expression:"model.brojZahtjevaKojiNisuRijeseni"}})],1):_vm._e(),_vm._v(" "),_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"green","icon":"filter_none","title":"Broj zadataka","sub-icon":"mdi-calendar","sub-text":"Završeni zadaci"},model:{value:(_vm.model.brojZavrsenihZahtjeva),callback:function ($$v) {_vm.$set(_vm.model, "brojZavrsenihZahtjeva", $$v)},expression:"model.brojZavrsenihZahtjeva"}})],1),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_projekata'))?_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"green","icon":"view_comfy","title":"Broj projekata","sub-icon":"mdi-calendar","sub-text":"Svi projekti"},model:{value:(_vm.model.brojProjekata),callback:function ($$v) {_vm.$set(_vm.model, "brojProjekata", $$v)},expression:"model.brojProjekata"}})],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_komentara_korisnika_ukupno'))?_c('v-flex',{staticClass:"card-padding",attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"green","icon":"view_comfy","title":"Broj komentara","sub-icon":"mdi-calendar","sub-text":"Svi komentari korisnika"},model:{value:(_vm.model.brojKomentaraKorisnika),callback:function ($$v) {_vm.$set(_vm.model, "brojKomentaraKorisnika", $$v)},expression:"model.brojKomentaraKorisnika"}})],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_zavrseni_zahtjevi_prosla_sedmica'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","sm12":"","lg4":""}},[(_vm.ucitanBrojZavrsenihZahtjevaPoDanimaProslaSedmica)?_c('material-chart-card',{attrs:{"data":_vm.zavrseniZahtjeviProslaSedmicaChart.data,"options":_vm.zavrseniZahtjeviProslaSedmicaChart.options,"color":"green","type":"Line"}},[_c('h4',{staticClass:"title font-weight-light"},[_vm._v("Završeni zadaci")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_c('v-icon',{attrs:{"color":"green","small":""}},[_vm._v("\r\n                        mdi-arrow-up\r\n                    ")]),_vm._v(" "),_vm._v("\r\n                    Ukupan broj završenih zadataka prošle sedmice po danima\r\n                ")],1)]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_po_projektu'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","sm12":"","lg4":""}},[(_vm.ucitanBrojZahtjevaPoProjektu)?_c('material-chart-card',{attrs:{"data":_vm.zahtjeviPoProjektimaChart.data,"options":_vm.zahtjeviPoProjektimaChart.options,"responsive-options":_vm.zahtjeviPoProjektimaChart.responsiveOptions,"color":"red","type":"Bar"}},[_c('h4',{staticClass:"title font-weight-light"},[_vm._v("Zadaci po projektima")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Ukupan broj svih zadataka po projektima")])]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_prijavljeni_zahtjevi_prosle_sedmice'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","sm12":"","lg4":""}},[(_vm.ucitanBrojKreiranihZahtjevaPoDanimaProslaSedmica)?_c('material-chart-card',{attrs:{"data":_vm.kreiraniZahtjeviProslaSedmicaChart.data,"options":_vm.kreiraniZahtjeviProslaSedmicaChart.options,"color":"info","type":"Line"}},[_c('h3',{staticClass:"title font-weight-light"},[_vm._v("Prijavljeni zadaci")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Ukupan broj prijavljenih zadataka prošle sedmice po danima")])]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_po_mjesecima') )?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","sm12":"","lg4":""}},[(_vm.ucitanBrojZahtjevaPoMjesecima)?_c('material-chart-card',{attrs:{"data":_vm.zahtjeviPoMjesecimaChart.data,"options":_vm.zahtjeviPoMjesecimaChart.options,"color":"info","type":"Line"}},[_c('h3',{staticClass:"title font-weight-light"},[_vm._v(" Zadaci")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Ukupan broj zadataka po mjesecima")])]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_po_danima_aktivna_godina'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","sm12":"","lg4":""}},[(_vm.ucitanBrojZahtjevaPoDanimaAktivnaGodina)?_c('material-chart-card',{attrs:{"data":_vm.zahtjeviPoDanimaAktivnaGodinaChart.data,"options":_vm.zahtjeviPoDanimaAktivnaGodinaChart.options,"color":"info","type":"Line"}},[_c('h3',{staticClass:"title font-weight-light"},[_vm._v(" Zadaci")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Ukupan broj kreiranih zadataka po danima, aktivna godina")])]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_rijesenih_zahtjeva_po_sedmicama'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","sm12":"","lg4":""}},[(_vm.ucitanBrojZahtjevaPoSedmicama)?_c('material-chart-card',{attrs:{"data":_vm.zahtjeviPoSedmicamaChart.data,"options":_vm.zahtjeviPoSedmicamaChart.options,"color":"info","type":"Line"}},[_c('h3',{staticClass:"title font-weight-light"},[_vm._v(" Zadaci")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Ukupan broj zadataka po prethodnim sedmicama")])]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_zahtjevi_najduze_u_potrebno_uraditi'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","lg6":""}},[(_vm.ucitaniZahtjeviNajduzeUPotrebnoUraditi)?_c('lista-zahtjeva-projekat',{attrs:{"lista-zahtjeva":_vm.zahtjeviNajduzeUPotrebnoUraditi,"omoguceno-dodavanje-i-filtriranje":false,"naslov":_vm.nazivZahtjeviNajduzeUPotrebnoUraditi,"headersi-za-prikaz":"10101010000","sakrij-prikaz-paginacije":true}}):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_zadnji_dodati_zahtjevi_potrebno_uraditi'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","lg6":""}},[(_vm.ucitaniZahtjeviZadnjiDodatiKojeJePotrebnoUraditi)?_c('lista-zahtjeva-projekat',{attrs:{"lista-zahtjeva":_vm.zahtjeviZadnjiDodatiKojeJePotrebnoUraditi,"omoguceno-dodavanje-i-filtriranje":false,"naslov":_vm.nazivZahtjeviZadnjiDodatiKojeJePotrebnoUraditi,"headersi-za-prikaz":"10101010000","sakrij-prikaz-paginacije":true}}):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_zahtjevi_zadnji_dodati_nisu_rijeseni'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","lg6":""}},[(_vm.ucitaniZahtjeviZadnjiDodatiNisuRijeseni)?_c('lista-zahtjeva-projekat',{attrs:{"lista-zahtjeva":_vm.zahtjeviZadnjiDodatiNisuRijeseni,"omoguceno-dodavanje-i-filtriranje":false,"naslov":'Zahtjevi zadnji dodati koji nisu riješeni',"headersi-za-prikaz":"10101010000","sakrij-prikaz-paginacije":true}}):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_zahtjevi_rijeseni'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","lg6":""}},[(_vm.ucitaniZahtjeviZadnjiRijeseni)?_c('lista-zahtjeva-projekat',{attrs:{"lista-zahtjeva":_vm.zahtjeviZadnjiRijeseni,"omoguceno-dodavanje-i-filtriranje":false,"naslov":'Zahtjevi zadnji koji su riješeni',"headersi-za-prikaz":"10101010000","sakrij-prikaz-paginacije":true}}):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_lista_dodijeljenih_projekata'))?_c('v-flex',{staticClass:"card-padding",attrs:{"md12":"","lg6":""}},[_c('lista-projekata',{attrs:{"omoguceno-dodavanje-i-filtriranje":false}})],1):_vm._e()],1)],1):_vm._e()}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/dashboard3.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  name: "Dashboard",
  data: function data() {
    return {
      dailySalesChart: {
        data: {
          labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
          series: [[12, 17, 7, 17, 23, 18, 38]]
        },
        options: {
          lineSmooth: this.$chartist.Interpolation.cardinal({
            tension: 0
          }),
          low: 0,
          high: 50,
          chartPadding: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
          }
        }
      },
      dataCompletedTasksChart: {
        data: {
          labels: ['12am', '3pm', '6pm', '9pm', '12pm', '3am', '6am', '9am'],
          series: [[230, 750, 450, 300, 280, 240, 200, 190]]
        },
        options: {
          lineSmooth: this.$chartist.Interpolation.cardinal({
            tension: 0
          }),
          low: 0,
          high: 1000,
          chartPadding: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
          }
        }
      },
      emailsSubscriptionChart: {
        data: {
          labels: ['Ja', 'Fe', 'Ma', 'Ap', 'Mai', 'Ju', 'Jul', 'Au', 'Se', 'Oc', 'No', 'De'],
          series: [[542, 443, 320, 780, 553, 453, 326, 434, 568, 610, 756, 895]]
        },
        options: {
          axisX: {
            showGrid: false
          },
          low: 0,
          high: 1000,
          chartPadding: {
            top: 0,
            right: 5,
            bottom: 0,
            left: 0
          }
        },
        responsiveOptions: [['screen and (max-width: 640px)', {
          seriesBarDistance: 5,
          axisX: {
            labelInterpolationFnc: function labelInterpolationFnc(value) {
              return value[0];
            }
          }
        }]]
      },
      headers: [{
        sortable: false,
        text: 'ID',
        value: 'id'
      }, {
        sortable: false,
        text: 'Name',
        value: 'name'
      }, {
        sortable: false,
        text: 'Salary',
        value: 'salary',
        align: 'right'
      }, {
        sortable: false,
        text: 'Country',
        value: 'country',
        align: 'right'
      }, {
        sortable: false,
        text: 'City',
        value: 'city',
        align: 'right'
      }],
      items: [{
        name: 'Dakota Rice',
        country: 'Niger',
        city: 'Oud-Tunrhout',
        salary: '$35,738'
      }, {
        name: 'Minerva Hooper',
        country: 'Curaçao',
        city: 'Sinaai-Waas',
        salary: '$23,738'
      }, {
        name: 'Sage Rodriguez',
        country: 'Netherlands',
        city: 'Overland Park',
        salary: '$56,142'
      }, {
        name: 'Philip Chanley',
        country: 'Korea, South',
        city: 'Gloucester',
        salary: '$38,735'
      }, {
        name: 'Doris Greene',
        country: 'Malawi',
        city: 'Feldkirchen in Kārnten',
        salary: '$63,542'
      }],
      tabs: 0,
      list: {
        0: false,
        1: false,
        2: false
      }
    };
  },

  methods: {
    complete: function complete(index) {
      this.list[index] = !this.list[index];
    }
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-container',{attrs:{"fill-height":"","fluid":"","grid-list-xl":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"md12":"","sm12":"","lg4":""}},[_c('material-chart-card',{attrs:{"data":_vm.dailySalesChart.data,"options":_vm.dailySalesChart.options,"color":"info","type":"Line"}},[_c('h4',{staticClass:"title font-weight-light"},[_vm._v("Daily Sales")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_c('v-icon',{attrs:{"color":"green","small":""}},[_vm._v("\n            mdi-arrow-up\n          ")]),_vm._v(" "),_c('span',{staticClass:"green--text"},[_vm._v("55%")]),_vm._v(" \n          increase in today's sales\n        ")],1),_vm._v(" "),_c('template',{slot:"actions"},[_c('v-icon',{staticClass:"mr-2",attrs:{"small":""}},[_vm._v("\n            mdi-clock-outline\n          ")]),_vm._v(" "),_c('span',{staticClass:"caption grey--text font-weight-light"},[_vm._v("updated 4 minutes ago")])],1)],2)],1),_vm._v(" "),_c('v-flex',{attrs:{"md12":"","sm12":"","lg4":""}},[_c('material-chart-card',{attrs:{"data":_vm.emailsSubscriptionChart.data,"options":_vm.emailsSubscriptionChart.options,"responsive-options":_vm.emailsSubscriptionChart.responsiveOptions,"color":"red","type":"Bar"}},[_c('h4',{staticClass:"title font-weight-light"},[_vm._v("Email Subscription")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Last Campaign Performance")]),_vm._v(" "),_c('template',{slot:"actions"},[_c('v-icon',{staticClass:"mr-2",attrs:{"small":""}},[_vm._v("\n            mdi-clock-outline\n          ")]),_vm._v(" "),_c('span',{staticClass:"caption grey--text font-weight-light"},[_vm._v("updated 10 minutes ago")])],1)],2)],1),_vm._v(" "),_c('v-flex',{attrs:{"md12":"","sm12":"","lg4":""}},[_c('material-chart-card',{attrs:{"data":_vm.dataCompletedTasksChart.data,"options":_vm.dataCompletedTasksChart.options,"color":"green","type":"Line"}},[_c('h3',{staticClass:"title font-weight-light"},[_vm._v("Completed Tasks")]),_vm._v(" "),_c('p',{staticClass:"category d-inline-flex font-weight-light"},[_vm._v("Last Last Campaign Performance")]),_vm._v(" "),_c('template',{slot:"actions"},[_c('v-icon',{staticClass:"mr-2",attrs:{"small":""}},[_vm._v("\n            mdi-clock-outline\n          ")]),_vm._v(" "),_c('span',{staticClass:"caption grey--text font-weight-light"},[_vm._v("campaign sent 26 minutes ago")])],1)],2)],1),_vm._v(" "),_c('v-flex',{attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"green","icon":"mdi-store","title":"Revenue","value":"$34,245","sub-icon":"mdi-calendar","sub-text":"Last 24 Hours"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"orange","icon":"mdi-content-copy","title":"Used Space","value":"49/50","small-value":"GB","sub-icon":"mdi-alert","sub-icon-color":"error","sub-text":"Get More Space...","sub-text-color":"text-primary"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"red","icon":"mdi-information-outline","title":"Fixed Issues","value":"75","sub-icon":"mdi-tag","sub-text":"Tracked from Github"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"sm6":"","xs12":"","md6":"","lg3":""}},[_c('material-stats-card',{attrs:{"color":"info","icon":"mdi-twitter","title":"Followers","value":"+245","sub-icon":"mdi-update","sub-text":"Just Updated"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"md12":"","lg6":""}},[_c('material-card',{attrs:{"color":"orange","title":"Employee Stats","text":"New employees on 15th September, 2016"}},[_c('v-data-table',{attrs:{"headers":_vm.headers,"items":_vm.items,"hide-actions":""},scopedSlots:_vm._u([{key:"headerCell",fn:function(ref){
var header = ref.header;
return [_c('span',{staticClass:"font-weight-light text-warning text--darken-3",domProps:{"textContent":_vm._s(header.text)}})]}},{key:"items",fn:function(ref){
var index = ref.index;
var item = ref.item;
return [_c('td',[_vm._v(_vm._s(index + 1))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(item.name))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_vm._v(_vm._s(item.salary))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_vm._v(_vm._s(item.country))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_vm._v(_vm._s(item.city))])]}}])})],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"md12":"","lg6":""}},[_c('material-card',{staticClass:"card-tabs",attrs:{"color":"green"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-tabs',{attrs:{"color":"transparent","slider-color":"white"},model:{value:(_vm.tabs),callback:function ($$v) {_vm.tabs=$$v},expression:"tabs"}},[_c('span',{staticClass:"subheading font-weight-light mr-3",staticStyle:{"align-self":"center"}},[_vm._v("Tasks:")]),_vm._v(" "),_c('v-tab',{staticClass:"mr-3"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("mdi-bug")]),_vm._v("\n              Bugs\n            ")],1),_vm._v(" "),_c('v-tab',{staticClass:"mr-3"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("mdi-code-tags")]),_vm._v("\n              Website\n            ")],1),_vm._v(" "),_c('v-tab',[_c('v-icon',{staticClass:"mr-2"},[_vm._v("mdi-cloud")]),_vm._v("\n              Server\n            ")],1)],1)],1),_vm._v(" "),_c('v-tabs-items',{model:{value:(_vm.tabs),callback:function ($$v) {_vm.tabs=$$v},expression:"tabs"}},_vm._l((3),function(n){return _c('v-tab-item',{key:n},[_c('v-list',{attrs:{"three-line":""}},[_c('v-list-tile',{on:{"click":function($event){return _vm.complete(0)}}},[_c('v-list-tile-action',[_c('v-checkbox',{attrs:{"value":_vm.list[0],"color":"green"}})],1),_vm._v(" "),_c('v-list-tile-title',[_vm._v("\n                  Sign contract for \"What are conference organized afraid of?\"\n                ")]),_vm._v(" "),_c('div',{staticClass:"d-flex"},[_c('v-tooltip',{attrs:{"top":"","content-class":"top"}},[_c('v-btn',{staticClass:"v-btn--simple",attrs:{"slot":"activator","color":"success","icon":""},slot:"activator"},[_c('v-icon',{attrs:{"color":"primary"}},[_vm._v("mdi-pencil")])],1),_vm._v(" "),_c('span',[_vm._v("Edit")])],1),_vm._v(" "),_c('v-tooltip',{attrs:{"top":"","content-class":"top"}},[_c('v-btn',{staticClass:"v-btn--simple",attrs:{"slot":"activator","color":"danger","icon":""},slot:"activator"},[_c('v-icon',{attrs:{"color":"error"}},[_vm._v("mdi-close")])],1),_vm._v(" "),_c('span',[_vm._v("Close")])],1)],1)],1),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('v-list-tile',{on:{"click":function($event){return _vm.complete(1)}}},[_c('v-list-tile-action',[_c('v-checkbox',{attrs:{"value":_vm.list[1],"color":"success"}})],1),_vm._v(" "),_c('v-list-tile-title',[_vm._v("\n                  Lines From Great Russian Literature? Or E-mails From My Boss?\n                ")]),_vm._v(" "),_c('div',{staticClass:"d-flex"},[_c('v-tooltip',{attrs:{"top":"","content-class":"top"}},[_c('v-btn',{staticClass:"v-btn--simple",attrs:{"slot":"activator","color":"success","icon":""},slot:"activator"},[_c('v-icon',{attrs:{"color":"primary"}},[_vm._v("mdi-pencil")])],1),_vm._v(" "),_c('span',[_vm._v("Edit")])],1),_vm._v(" "),_c('v-tooltip',{attrs:{"top":"","content-class":"top"}},[_c('v-btn',{staticClass:"v-btn--simple",attrs:{"slot":"activator","color":"danger","icon":""},slot:"activator"},[_c('v-icon',{attrs:{"color":"error"}},[_vm._v("mdi-close")])],1),_vm._v(" "),_c('span',[_vm._v("Close")])],1)],1)],1),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('v-list-tile',{on:{"click":function($event){return _vm.complete(2)}}},[_c('v-list-tile-action',[_c('v-checkbox',{attrs:{"value":_vm.list[2],"color":"success"}})],1),_vm._v(" "),_c('v-list-tile-title',[_vm._v("\n                  Flooded: One year later, assessing what was lost and what was found when a ravaging rain swept through metro Detroit\n                ")]),_vm._v(" "),_c('div',{staticClass:"d-flex"},[_c('v-tooltip',{attrs:{"top":"","content-class":"top"}},[_c('v-btn',{staticClass:"v-btn--simple",attrs:{"slot":"activator","color":"success","icon":""},slot:"activator"},[_c('v-icon',{attrs:{"color":"primary"}},[_vm._v("mdi-pencil")])],1),_vm._v(" "),_c('span',[_vm._v("Edit")])],1),_vm._v(" "),_c('v-tooltip',{attrs:{"top":"","content-class":"top"}},[_c('v-btn',{staticClass:"v-btn--simple",attrs:{"slot":"activator","color":"danger","icon":""},slot:"activator"},[_c('v-icon',{attrs:{"color":"error"}},[_vm._v("mdi-close")])],1),_vm._v(" "),_c('span',[_vm._v("Close")])],1)],1)],1)],1)],1)}),1)],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/dokumenti/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _videoUputstvo = require('./video-uputstvo');

var _videoUputstvo2 = _interopRequireDefault(_videoUputstvo);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'VideoUputstvo',

    routes: [{
        path: 'dokumentacija',
        name: 'home.uputstvo.video',
        component: _videoUputstvo2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/dokumenti/video-uputstvo.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    mounted: function mounted() {
        var pocetakNaziva = this.$route.fullPath.indexOf("=");
        var naziv = this.$route.fullPath.substring(pocetakNaziva + 1);
        var video = document.getElementById("video-container");
        video.src = naziv;
        video.play();
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('video',{ref:"videoRef",attrs:{"src":"","id":"video-container","width":"100%","controls":""}})])}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/drawer.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  name: "Drawer",
  data: function data() {
    return {
      logo: './img/vuetifylogo.png',
      links: [{
        to: '/dashboard',
        icon: 'mdi-view-dashboard',
        text: 'Dashboard'
      }, {
        to: '/user-profile',
        icon: 'mdi-account',
        text: 'User Profile'
      }, {
        to: '/table-list',
        icon: 'mdi-clipboard-outline',
        text: 'Table List'
      }, {
        to: '/typography',
        icon: 'mdi-format-font',
        text: 'Typography'
      }, {
        to: '/icons',
        icon: 'mdi-chart-bubble',
        text: 'Icons'
      }, {
        to: '/maps',
        icon: 'mdi-map-marker',
        text: 'Maps'
      }, {
        to: '/notifications',
        icon: 'mdi-bell',
        text: 'Notifications'
      }],
      responsive: false
    };
  },
  computed: {
    inputValue: {
      get: function get() {
        return this.$store.state.app.drawer;
      },
      set: function set(val) {
        this.setDrawer(val);
      }
    },
    items: function items() {
      return this.$t('Layout.View.items');
    },
    sidebarOverlayGradiant: function sidebarOverlayGradiant() {
      return this.$store.state.app.sidebarBackgroundColor + ', ' + this.$store.state.app.sidebarBackgroundColor;
    }
  },
  mounted: function mounted() {
    this.onResponsiveInverted();
    window.addEventListener('resize', this.onResponsiveInverted);
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener('resize', this.onResponsiveInverted);
  },

  methods: {}
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-navigation-drawer',{attrs:{"id":"app-drawer","app":"","dark":"","floating":"","persistent":"","mobile-break-point":"991","width":"260"},model:{value:(_vm.inputValue),callback:function ($$v) {_vm.inputValue=$$v},expression:"inputValue"}},[_c('v-img',{attrs:{"src":_vm.image,"gradient":_vm.sidebarOverlayGradiant,"height":"100%"}},[_c('v-layout',{staticClass:"fill-height",attrs:{"tag":"v-list","column":""}},[_c('v-list-tile',{attrs:{"avatar":""}},[_c('v-list-tile-avatar',{attrs:{"color":"white"}},[_c('v-img',{attrs:{"src":_vm.logo,"height":"34","contain":""}})],1),_vm._v(" "),_c('v-list-tile-title',{staticClass:"title"},[_vm._v("\n          TMS\n        ")])],1),_vm._v(" "),_c('v-divider'),_vm._v(" "),(_vm.responsive)?_c('v-list-tile',[_c('v-text-field',{staticClass:"purple-input search-input",attrs:{"label":"Search...","color":"purple"}})],1):_vm._e(),_vm._v(" "),_vm._l((_vm.links),function(link,i){return _c('v-list-tile',{key:i,staticClass:"v-list-item",attrs:{"to":link.to,"active-class":_vm.color,"avatar":""}},[_c('v-list-tile-action',[_c('v-icon',[_vm._v(_vm._s(link.icon))])],1),_vm._v(" "),_c('v-list-tile-title',{domProps:{"textContent":_vm._s(link.text)}})],1)}),_vm._v(" "),_c('v-list-tile',{staticClass:"v-list-item v-list__tile--buy",attrs:{"disabled":"","active-class":"primary","to":"/upgrade"}},[_c('v-list-tile-action',[_c('v-icon',[_vm._v("mdi-package-up")])],1),_vm._v(" "),_c('v-list-tile-title',{staticClass:"font-weight-light"},[_vm._v("\n          Upgrade To PRO\n        ")])],1)],2)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/footer.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  name: "Footer",
  data: function data() {
    return {
      links: [{ name: 'Home', Link: '/dashboard' }, { name: 'Creative Tim', Link: 'https://www.creative-tim.com' }, { name: 'About Us', Link: 'https://creative-tim.com/presentation' }, { name: 'Blog', Link: 'https://blog.creative-tim.com' }]
    };
  }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_vm._v("\r\n  test\r\n  ")])}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/izvjestaj/list.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _oIframe = require("modules/home/components/o-iframe");

var _oIframe2 = _interopRequireDefault(_oIframe);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "ListaIzvjestaja",
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            resolved: null,
            izvjestaj: null,
            izvjestajUrl: null,
            identity: _identity2.default
        };
    },
    created: function created() {
        var _this = this;

        this.$watch(function () {
            return _this.resolved;
        }, this.ucitajIzvjestaje);
    },

    methods: {
        ocisti: function ocisti() {
            this.izvjestajId = null;
        },
        ucitajIzvjestaje: function ucitajIzvjestaje() {
            if (!this.resolved) return;
            var ukupnoIzvjestaji = this.resolved.izvjestaji;
            this.resolved.izvjestaji = [];

            var lista = ukupnoIzvjestaji.filter(function (item) {
                return item.grupa == 1;
            });
            if (lista.length > 0) {
                this.resolved.izvjestaji.push({
                    header: "Liste"
                });
                this.resolved.izvjestaji = this.resolved.izvjestaji.concat(lista);
            }

            var statisticiPrikaz = ukupnoIzvjestaji.filter(function (item) {
                return item.grupa == 2;
            });
            if (statisticiPrikaz.length > 0) {
                this.resolved.izvjestaji.push({
                    divider: true
                });
                this.resolved.izvjestaji.push({
                    header: "Statistički prikaz"
                });
                this.resolved.izvjestaji = this.resolved.izvjestaji.concat(statisticiPrikaz);
            }
            var grafickiPrikaz = ukupnoIzvjestaji.filter(function (item) {
                return item.grupa == 3;
            });
            if (grafickiPrikaz.length > 0) {
                this.resolved.izvjestaji.push({
                    divider: true
                });
                this.resolved.izvjestaji.push({
                    header: "Grafički prikaz"
                });
                this.resolved.izvjestaji = this.resolved.izvjestaji.concat(grafickiPrikaz);
            }
            var onlineUpis = ukupnoIzvjestaji.filter(function (item) {
                return item.grupa == 5;
            });
            if (onlineUpis.length > 0) {
                this.resolved.izvjestaji.push({
                    divider: true
                });
                this.resolved.izvjestaji.push({
                    header: "Online upis"
                });
                this.resolved.izvjestaji = this.resolved.izvjestaji.concat(onlineUpis);
            }
            var ostali = ukupnoIzvjestaji.filter(function (item) {
                return item.grupa == 4;
            });
            if (ostali.length > 0) {
                this.resolved.izvjestaji.push({
                    divider: true
                });
                this.resolved.izvjestaji.push({
                    header: "Ostali"
                });
                this.resolved.izvjestaji = this.resolved.izvjestaji.concat(ostali);
            }
        },
        onSubmit: function onSubmit() {
            var that = this;
            if (!this.izvjestaj) return;

            var success = function success(model) {
                var url = that.izvjestaj.data + "&ttxid=" + model.body.id;
                that.izvjestajUrl = url;
            };

            (0, _resources.TokenResource)().temp({
                korisnickoIme: _identity2.default.korisnickoIme()
            }, {
                korisnickoIme: _identity2.default.korisnickoIme()
            }).then(success);
        }
    },

    components: {
        oiframe: _oIframe2.default
    },

    resolve: {
        izvjestaji: function izvjestaji() {
            return (0, _resources.SifarnikResource)().get({
                sifarnik: "Izvjestaj"
            });
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?_c('v-card',[_c('v-card-title',{staticClass:"grey lighten-4",attrs:{"primary-title":""}},[_vm._v("\r\n            Izvještaji\r\n            "),_c('v-btn',{staticClass:"glavni-naslov",attrs:{"flat":"","icon":"","color":"secondary"},on:{"click":function () { return this$1.activeHelpTip = true; }}},[_c('v-icon',[_vm._v("help")])],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('div',{staticClass:"lista-izvjestaja"},[_c('v-autocomplete',{staticClass:"required",attrs:{"items":_vm.resolved.izvjestaji,"return-object":"","label":"Odaberite izvještaj","item-text":"naziv","item-value":"id","bottom":"","required":""},model:{value:(_vm.izvjestaj),callback:function ($$v) {_vm.izvjestaj=$$v},expression:"izvjestaj"}})],1),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('v-btn',{on:{"click":_vm.ocisti}},[_vm._v("Očisti")]),_vm._v(" "),_c('v-btn',{attrs:{"secondary":""},on:{"click":_vm.onSubmit}},[_vm._v("Prikaži")])],1)])],1)],1):_vm._e(),_vm._v(" "),_c('br'),_vm._v(" "),_c('v-card',[_c('v-card-text',{attrs:{"id":"iframeHolder"}},[_c('o-iframe',{attrs:{"url":_vm.izvjestajUrl}})],1)],1),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.VratiTitlePoId('izvjestaj-list'),"content":_vm.VratiContentPoId('izvjestaj-list')},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/izvjestaj/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _list = require('./list');

var _list2 = _interopRequireDefault(_list);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Izvjestaj',

    routes: [{
        path: '',
        name: 'home.izvjestaj.home',
        component: _list2.default
    }, {
        path: 'list',
        name: 'home.izvjestaj.list',
        component: _list2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/korisnik/dodavanje.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "DodavanjeKorisnika",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            chips: ['Programming', 'Playing video games', 'Watching movies', 'Sleeping'],
            items: ['Streaming', 'Eating'],
            activeHelpTip: false,
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,
            valid: false,
            identity: _identity2.default,
            rules: {
                uloga: [function (v) {
                    return v && v.length != 0 || "Uloga je obavezna";
                }],
                obavezno: [function (v) {
                    return !!v || "Polje je obavezno";
                }],
                korisnickoIme: [function (v) {
                    return !!v || "Morate da unesete korisničko ime";
                }, function (v) {
                    return v && v.length <= 64 || "Korisničko ime mora biti manje od 64 karaktera";
                }],
                punoIme: [function (v) {
                    return !!v || "Morate da unesete ime i prezime";
                }, function (v) {
                    return v && v.length <= 128 || "Ime i prezime mora biti manje od 128 karaktera";
                }],
                lozinka: [function (v) {
                    return !!v || "Morate da unesete lozinku";
                }, function (v) {
                    return v && v.length <= 128 || "Lozinka mora biti manja od 128 karaktera";
                }, function (v) {
                    return (/^.{6,}$/.test(v) || "Lozinka mora imati najmanje 6 karaktera"
                    );
                }],
                email: [function (v) {
                    return !!v || "Morate da unesete e-mail";
                }, function (v) {
                    return v && v.length <= 256 || "Email mora biti kraći od 256 karaktera";
                }, function (v) {
                    return (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v) || "E-mail mora biti ispravan"
                    );
                }]
            },
            model: {
                korisnickoIme: null,
                email: null,
                punoIme: null,
                lozinka: null,
                uloge: [],
                projekti: [],
                kategorije: []
            },
            projektiKorisnika: [],
            dijeloviProjekta: [],
            kategorijeZahtjeva: [],
            zahtjevModel: {},
            izabranaUlogaSupport: false,
            izabranaUlogaAdministrator: false,

            inputs: {
                sve: true
            },
            porukeGreška: []

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },

    methods: {
        remove: function remove(item) {
            this.model.uloge.splice(this.model.uloge.indexOf(item), 1);
            this.model.uloge = [].concat((0, _toConsumableArray3.default)(this.model.uloge));
        },
        removeProjekat: function removeProjekat(item) {
            this.model.projekti.splice(this.model.projekti.indexOf(item), 1);
            this.model.projekti = [].concat((0, _toConsumableArray3.default)(this.model.projekti));
        },
        removeKategorija: function removeKategorija(item) {
            this.model.kategorije.splice(this.model.kategorije.indexOf(item), 1);
            this.model.kategorije = [].concat((0, _toConsumableArray3.default)(this.model.kategorije));
        },
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        onSubmit: function onSubmit() {
            var _this = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);
            var that = this;
            if (this.valid) {
                var success = function success(model) {
                    that.$toast.success('Uspješno dodan korisnik.');

                    _this.proslijedi = true;
                    that.$router.push({
                        name: "home.korisnik.pregled",
                        params: {
                            korisnickoIme: model.body.korisnickoIme
                        }
                    });
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };
                var ulogeArray = [];
                ulogeArray.push({
                    vrstaUlogeId: this.model.uloge
                });

                var model = {
                    korisnickoIme: this.model.korisnickoIme,
                    email: this.model.email,
                    lozinka: this.model.lozinka,
                    punoIme: this.model.punoIme,
                    uloge: ulogeArray,
                    projekti: this.model.projekti.map(function (p) {
                        return {
                            ProjekatId: p.id
                        };
                    }),
                    kategorije: this.model.kategorije.map(function (k) {
                        return {
                            zahtjevKategorijaId: k.id
                        };
                    })
                };

                var promise = (0, _resources.KorisnikResource)().save(that.$route.params, model);
                promise.then(success, error);
            }
        },
        regexUsername: function regexUsername() {
            var regexp = /^\w+-?\w+(?!-)$/;
            return regexp.test(this.model);
        },
        ucitajDijeloveProjekta: function ucitajDijeloveProjekta(id) {
            var _this2 = this;

            this.dijeloviProjekta = [];
            var success = function success(response) {

                var that = _this2;
                that.dijeloviProjekta = response.body;

                for (var i = 0; i < that.dijeloviProjekta.length; i++) {
                    {
                        that.zahtjevModel.dioProjekta = that.dijeloviProjekta[i].id;
                        break;
                    }
                }
                that.ucitajKategorijeZahtjeva(that.zahtjevModel.dioProjekta);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajKategorijeZahtjeva: function ucitajKategorijeZahtjeva(id) {
            var _this3 = this;

            this.kategorijeZahtjeva = [];
            this.zahtjevModel.kategorija = null;
            var success = function success(response) {

                var that = _this3;
                that.kategorijeZahtjeva = response.body;
                for (var i = 0; i < that.kategorijeZahtjeva.length; i++) {
                    {
                        that.zahtjevModel.kategorija = that.kategorijeZahtjeva[i].id;
                        break;
                    }
                }
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: id
            });

            promise.then(success, error);
        },
        izabranaUloga: function izabranaUloga() {
            this.izabranaUlogaSupport = false;
            this.izabranaUlogaAdministrator = false;
            for (var i = 0; i < this.resolved.dozvoljeneUloge.items.length; i++) {

                if (this.model.uloge == this.resolved.dozvoljeneUloge.items[i].id && this.resolved.dozvoljeneUloge.items[i].uloga == "Support") {
                    this.izabranaUlogaSupport = true;
                    this.izabranaUlogaAdministrator = false;
                    break;
                }
                if (this.model.uloge == this.resolved.dozvoljeneUloge.items[i].id && this.resolved.dozvoljeneUloge.items[i].uloga == "Administrator") {
                    this.izabranaUlogaAdministrator = true;
                    this.izabranaUlogaSupport = false;
                    break;
                }
            }
        }
    },
    resolve: {
        dozvoljeneUloge: function dozvoljeneUloge() {
            return (0, _resources.PravoUpravljanjaKorisnikomResource)().get({
                ulogaId: this.identity.trenutnaUlogaId()
            });
        },
        projekti: function projekti() {
            return (0, _resources.ProjekatResource)().vratiSveProjekte(this.inputs);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?_c('material-card',{attrs:{"title":"Dodaj korisnika","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.korisnickoIme,"autocomplete":"new-username","counter":64,"label":"Korisničko ime","required":""},model:{value:(_vm.model.korisnickoIme),callback:function ($$v) {_vm.$set(_vm.model, "korisnickoIme", $$v)},expression:"model.korisnickoIme"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.punoIme,"counter":128,"label":"Ime i prezime","required":""},model:{value:(_vm.model.punoIme),callback:function ($$v) {_vm.$set(_vm.model, "punoIme", $$v)},expression:"model.punoIme"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.email,"counter":256,"label":"E-mail","type":"email","required":""},model:{value:(_vm.model.email),callback:function ($$v) {_vm.$set(_vm.model, "email", $$v)},expression:"model.email"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.lozinka,"autocomplete":"new-password","counter":128,"label":"Lozinka","type":"password","required":""},model:{value:(_vm.model.lozinka),callback:function ($$v) {_vm.$set(_vm.model, "lozinka", $$v)},expression:"model.lozinka"}}),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","rules":_vm.rules.uloga,"items":_vm.resolved.dozvoljeneUloge.items,"item-text":"uloga","item-value":"id","label":"Uloga","bottom":""},on:{"input":_vm.izabranaUloga},model:{value:(_vm.model.uloge),callback:function ($$v) {_vm.$set(_vm.model, "uloge", $$v)},expression:"model.uloge"}}),_vm._v(" "),(!_vm.izabranaUlogaSupport && !_vm.izabranaUlogaAdministrator)?_c('v-combobox',{attrs:{"items":_vm.resolved.projekti.items,"label":"Projekti","chips":"","clearable":"","multiple":"","item-text":"naziv","item-value":"id"},scopedSlots:_vm._u([{key:"selection",fn:function(data){return [_c('v-chip',{attrs:{"selected":data.selected,"close":""},on:{"input":function($event){return _vm.removeProjekat(data.item)}}},[_c('strong',[_vm._v(_vm._s(data.item.naziv))]),_vm._v(" \r\n                        ")])]}}],null,false,2465953849),model:{value:(_vm.model.projekti),callback:function ($$v) {_vm.$set(_vm.model, "projekti", $$v)},expression:"model.projekti"}}):_vm._e(),_vm._v(" "),(_vm.izabranaUlogaSupport)?_c('v-form',[_c('v-flex',{attrs:{"xs4":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.resolved.projekti.items,"item-text":"naziv","item-value":"id","label":"Projekat","bottom":""},on:{"input":_vm.ucitajDijeloveProjekta},model:{value:(_vm.zahtjevModel.projekat),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "projekat", $$v)},expression:"zahtjevModel.projekat"}})],1),_vm._v(" "),(_vm.dijeloviProjekta.length!=0)?_c('v-flex',{style:({display: _vm.dijeloviProjekta.length>1 ? 'visible' : 'none'}),attrs:{"xs4":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.dijeloviProjekta,"item-text":"naziv","item-value":"id","label":"Podprojekat","bottom":""},on:{"input":_vm.ucitajKategorijeZahtjeva},model:{value:(_vm.zahtjevModel.dioProjekta),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "dioProjekta", $$v)},expression:"zahtjevModel.dioProjekta"}})],1):_vm._e(),_vm._v(" "),_c('v-combobox',{attrs:{"items":_vm.kategorijeZahtjeva,"label":"Kategorije","chips":"","clearable":"","multiple":"","item-text":"naziv","item-value":"id"},scopedSlots:_vm._u([{key:"selection",fn:function(data){return [_c('v-chip',{attrs:{"selected":data.selected,"close":""},on:{"input":function($event){return _vm.removeKategorija(data.item)}}},[_c('strong',[_vm._v(_vm._s(data.item.naziv))]),_vm._v(" \r\n                            ")])]}}],null,false,3243341542),model:{value:(_vm.model.kategorije),callback:function ($$v) {_vm.$set(_vm.model, "kategorije", $$v)},expression:"model.kategorije"}})],1):_vm._e(),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Dodaj")])],1)],1)],1)],1):_vm._e(),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.VratiTitlePoId('korisnik-dodavanje'),"content":_vm.VratiContentPoId('korisnik-dodavanje')},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/korisnik/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _korisnikDodavanje = require("../projekat/korisnik-dodavanje.vue");

var _korisnikDodavanje2 = _interopRequireDefault(_korisnikDodavanje);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditKorisnika",

    components: {
        Upit: _upit2.default,
        DodavanjeKorisnikaProjekat: _korisnikDodavanje2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            ul: [],
            resolved: null,
            identity: _identity2.default,
            dialogDodajKorisnikaNaProjekat: false,
            izabranaUlogaSupport: false,
            izabranaUlogaAdministrator: false,

            valid: false,
            model: {
                lozinka: ""
            },

            inputs: {
                sve: true
            },
            odabranaUloga: {},
            projekti: [],
            ulogaProjekti: [],
            korisnikModel: {},
            kategorije: [],
            dijeloviProjekta: [],
            ucitaneKategorijeKorisnika: false,

            rules: {
                punoIme: [function (v) {
                    return !!v || "Morate da unesete ime i prezime";
                }, function (v) {
                    return v && v.length <= 128 || "Ime i prezime mora biti manje od 128 karaktera";
                }],
                email: [function (v) {
                    return !!v || "Morate da unesete e-mail";
                }, function (v) {
                    return v && v.length <= 256 || "Email mora biti kraći od 256 karaktera";
                }, function (v) {
                    return (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v) || "E-mail mora biti ispravan"
                    );
                }],
                lozinka: [function (v) {
                    return !v || v.length <= 128 || "Lozinka mora biti manja od 128 karaktera";
                }, function (v) {
                    return !v || /^.{6,}$/.test(v) || "Lozinka mora imati najmanje 6 karaktera";
                }]
            }
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    created: function created() {
        this.ucitajModel();
    },

    methods: {
        ucitajProjekteZaKorisnikUlogu: function ucitajProjekteZaKorisnikUlogu(ulogaId) {
            var that = this;

            var success = function success(response) {
                that.ulogaProjekti = response.body;
                that.ucitajProjekte();
            };

            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ProjekatResource)().vratiProjekteZaKorisnikUlogu({
                korisnickoIme: this.korisnikModel.korisnickoIme,
                ulogaId: ulogaId
            });

            promise.then(success, error);
        },
        posaljiUloge: function posaljiUloge() {
            var uloge = this.korisnikModel.uloge;
            this.uloge = uloge;
        },
        zatvoriDialogDodajKorisnikaNaProjekat: function zatvoriDialogDodajKorisnikaNaProjekat(dialogDodajKorisnikaNaProjekat) {
            this.dialogDodajKorisnikaNaProjekat = dialogDodajKorisnikaNaProjekat;
        },
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        onSubmit: function onSubmit() {
            var _this = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (this.valid) {

                var that = this;
                var success = function success() {
                    _this.proslijedi = true;
                    that.$router.push({
                        name: "home.korisnik.pregled",
                        params: {
                            korisnickoIme: that.korisnikModel.korisnickoIme
                        }
                    });
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };
                var modelSaLozinkom = this.korisnikModel;
                modelSaLozinkom.projekti = this.ulogaProjekti;
                modelSaLozinkom.lozinka = this.model.lozinka;


                var promise = (0, _resources.KorisnikResource)().update(that.$route.params, modelSaLozinkom);
                promise.then(success, error);
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        ucitajProjekte: function ucitajProjekte() {
            var that = this;

            var success = function success(response) {
                that.projekti = response.body;
            };

            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(that.inputs);

            promise.then(success, error);
        },
        ucitajModel: function ucitajModel() {
            var that = this;

            var success = function success(response) {
                that.korisnikModel = response.body;
                that.odabranaUloga = that.korisnikModel.uloge[0];

                if (that.odabranaUloga.vrstaUloge.uloga == 'Support') {
                    that.izabranaUlogaSupport = true;
                    that.izabranaUlogaAdministrator = false;
                } else if (that.odabranaUloga.vrstaUloge.uloga == 'Administrator') {
                    that.izabranaUlogaSupport = false;
                    that.izabranaUlogaAdministrator = true;
                }
                that.ucitajProjekteZaKorisnikUlogu(that.odabranaUloga.vrstaUloge.id);
                that.ucitajKategorijeKorisnika();
            };

            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.KorisnikResource)().get(this.$route.params);

            promise.then(success, error);
        },
        ucitajDijeloveProjekta: function ucitajDijeloveProjekta(id) {
            var _this2 = this;

            this.dijeloviProjekta = [];
            var success = function success(response) {

                var that = _this2;
                that.dijeloviProjekta = response.body;

                for (var i = 0; i < that.dijeloviProjekta.length; i++) {
                    {
                        that.korisnikModel.dioProjekta = that.dijeloviProjekta[i].id;
                        break;
                    }
                }
                that.ucitajKategorije(that.korisnikModel.dioProjekta);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajKategorije: function ucitajKategorije(id) {
            this.kategorije = [];

            var that = this;

            var success = function success(response) {
                that.kategorije = response.body;
                console.log("kategorije", that.kategorije);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: id
            });

            promise.then(success, error);
        },
        ucitajKategorijeKorisnika: function ucitajKategorijeKorisnika() {
            var _this3 = this;

            var success = function success(response) {
                var that = _this3;

                that.kategorije = response.body;
                that.korisnikModel.kategorije = that.kategorije;
                that.ucitaneKategorijeKorisnika = true;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };
            var promise = (0, _resources.KorisnikResource)().vratiKategorijeKorisnika({
                korisnickoIme: this.$route.params.korisnickoIme
            });
            promise.then(success, error);
        },
        removeProjekat: function removeProjekat(item) {
            this.ulogaProjekti.splice(this.ulogaProjekti.indexOf(item), 1);
            this.ulogaProjekti = [].concat((0, _toConsumableArray3.default)(this.ulogaProjekti));
        },
        removeKategorija: function removeKategorija(item) {
            this.korisnikModel.kategorije.splice(this.korisnikModel.kategorije.indexOf(item), 1);
            this.korisnikModel.kategorije = [].concat((0, _toConsumableArray3.default)(this.korisnikModel.kategorije));
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"title":"Izmijeni korisnika","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.punoIme,"counter":128,"label":"Ime i prezime","required":""},model:{value:(_vm.korisnikModel.punoIme),callback:function ($$v) {_vm.$set(_vm.korisnikModel, "punoIme", $$v)},expression:"korisnikModel.punoIme"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.email,"counter":256,"label":"E-mail","type":"email","required":""},model:{value:(_vm.korisnikModel.email),callback:function ($$v) {_vm.$set(_vm.korisnikModel, "email", $$v)},expression:"korisnikModel.email"}}),_vm._v(" "),_c('v-text-field',{attrs:{"rules":_vm.rules.lozinka,"counter":128,"label":"Lozinka","type":"password"},model:{value:(_vm.model.lozinka),callback:function ($$v) {_vm.$set(_vm.model, "lozinka", $$v)},expression:"model.lozinka"}}),_vm._v(" "),_c('v-flex',[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.korisnikModel.uloge,"label":"Uloga","item-text":"vrstaUloge.uloga","item-value":"vrstaUloge.id","bottom":""},on:{"input":_vm.ucitajProjekteZaKorisnikUlogu},model:{value:(_vm.odabranaUloga),callback:function ($$v) {_vm.odabranaUloga=$$v},expression:"odabranaUloga"}})],1),_vm._v(" "),(!_vm.izabranaUlogaSupport && !_vm.izabranaUlogaAdministrator)?_c('v-combobox',{attrs:{"eager":"","items":_vm.projekti.items,"label":"Projekti","chips":"","clearable":"","multiple":"","item-text":"naziv","item-value":"id"},scopedSlots:_vm._u([{key:"selection",fn:function(data){return [_c('v-chip',{attrs:{"active":"","selected":data.selected,"close":""},on:{"input":function($event){return _vm.removeProjekat(data.item)}}},[_c('strong',[_vm._v(_vm._s(data.item.naziv))]),_vm._v(" \r\n                        ")])]}}],null,false,2805907267),model:{value:(_vm.ulogaProjekti),callback:function ($$v) {_vm.ulogaProjekti=$$v},expression:"ulogaProjekti"}}):_vm._e(),_vm._v(" "),(_vm.izabranaUlogaSupport)?_c('v-form',[_c('v-flex',{attrs:{"xs4":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.projekti.items,"item-text":"naziv","item-value":"id","label":"Projekat","bottom":""},on:{"input":_vm.ucitajDijeloveProjekta},model:{value:(_vm.korisnikModel.projekat),callback:function ($$v) {_vm.$set(_vm.korisnikModel, "projekat", $$v)},expression:"korisnikModel.projekat"}})],1),_vm._v(" "),(_vm.dijeloviProjekta.length!=0)?_c('v-flex',{style:({display: _vm.dijeloviProjekta.length>1 ? 'visible' : 'none'}),attrs:{"xs4":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.dijeloviProjekta,"item-text":"naziv","item-value":"id","label":"Podprojekat","bottom":""},on:{"input":_vm.ucitajKategorije},model:{value:(_vm.korisnikModel.dioProjekta),callback:function ($$v) {_vm.$set(_vm.korisnikModel, "dioProjekta", $$v)},expression:"korisnikModel.dioProjekta"}})],1):_vm._e(),_vm._v(" "),(_vm.ucitaneKategorijeKorisnika)?_c('v-combobox',{attrs:{"eager":"","items":_vm.kategorije,"label":"Kategorije","chips":"","clearable":"","multiple":"","item-text":"naziv","item-value":"id"},scopedSlots:_vm._u([{key:"selection",fn:function(data){return [_c('v-chip',{attrs:{"active":"","selected":data.selected,"close":""},on:{"input":function($event){return _vm.removeKategorija(data.item)}}},[_c('strong',[_vm._v(_vm._s(data.item.detaljanNaziv))]),_vm._v(" \r\n                            ")])]}}],null,false,1286551041),model:{value:(_vm.korisnikModel.kategorije),callback:function ($$v) {_vm.$set(_vm.korisnikModel, "kategorije", $$v)},expression:"korisnikModel.kategorije"}}):_vm._e()],1):_vm._e(),_vm._v(" "),_c('br'),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Snimi")])],1)],1)],1)],1),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.VratiTitlePoId('korisnik-edit'),"content":_vm.VratiContentPoId('korisnik-edit')},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/korisnik/list.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _lodash = require('lodash.debounce');

var _lodash2 = _interopRequireDefault(_lodash);

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _paginationMixin = require('helpers/pagination-mixin');

var _paginationMixin2 = _interopRequireDefault(_paginationMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaKorisnika',
    mixins: [_paginationMixin2.default, _helpTipDialogMixin2.default],
    components: {
        debounce: _lodash2.default
    },
    props: ['listaKorisnika', 'omogucenHeader', 'projekatId'],

    data: function data() {
        return {
            activeHelpTip: false,
            model: {
                items: []
            },
            childOmogucenHeader: this.omogucenHeader,
            totalItems: 0,
            filterMenu: false,
            filtrirano: false,
            loading: false,
            headers: [{
                text: 'Korisničko ime',
                align: 'left',
                sortable: false,
                value: 'korisnickoIme'
            }, {
                text: 'Ime i prezime',
                align: 'left',
                sortable: false,
                value: 'punoIme'
            }, {
                text: 'Uloga',
                align: 'left',
                sortable: false,
                value: 'uloga'
            }, {
                text: 'Aktivan',
                align: 'left',
                sortable: false,
                value: 'onemogucen'
            }, {
                text: '',
                align: 'left',
                sortable: false,
                value: ''
            }],
            inputs: {
                filter: null,
                page: 1,
                count: 30,
                projekatId: this.projekatId
            },
            identity: _identity2.default
        };
    },
    created: function created() {
        this.inputs = this.mergeQueryToInput(this.$route.query, this.inputs);

        if (this.omogucenHeader == null) this.childOmogucenHeader = true;
    },
    mounted: function mounted() {
        if (this.inputs.page) {
            this.pagination.page = this.inputs.page;
        }
        if (this.inputs.count) {
            this.pagination.count = this.inputs.count;
        }
    },


    methods: {
        filtriraj: function filtriraj() {
            if (this.inputs.filter) {
                this.filtrirano = true;
            } else {
                this.filtrirano = false;
            }
            this.filterMenu = false;
            this.resetujPaginaciju();
        },
        ponistiFilter: function ponistiFilter() {
            this.inputs.filter = "";
            this.filterMenu = false;
            this.filtrirano = false;
            this.resetujPaginaciju();
        },
        updateData: function updateData() {
            var that = this;

            if (that.listaKorisnika == null) {

                this.osvjeziQuery(this.inputs);

                this.loading = true;
                var success = function success(model) {
                    that.model = model.body;
                    that.totalItems = model.body.total;
                    that.loading = false;
                };

                var error = function error() {
                    that.$toast.error("Filtriranje nije uspješno");
                };

                (0, _resources.KorisnikResource)().get(that.inputs).then(success, error);
            } else {

                that.model = that.listaKorisnika;
                that.totalItems = that.listaKorisnika.total;

                that.loading = false;
            }
        },
        otvoriPregledKorisnika: function otvoriPregledKorisnika(korisnickoIme) {
            this.$router.push({
                name: 'home.korisnik.pregled',
                params: {
                    korisnickoIme: korisnickoIme
                }
            });
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"color":"primary"}},[(_vm.childOmogucenHeader)?_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Korisnici ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":"","to":{ name: 'home.korisnik.dodavanje' }}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                        DODAJ\r\n                    ")],1),_vm._v(" "),_c('v-menu',{attrs:{"close-on-content-click":false,"content-class":"dropdown-menu","bottom":"","left":"","offset-y":"","transition":"slide-y-transition"},model:{value:(_vm.filterMenu),callback:function ($$v) {_vm.filterMenu=$$v},expression:"filterMenu"}},[_c('v-btn',{staticClass:"toolbar-btn",attrs:{"slot":"activator","flat":""},slot:"activator"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("filter_list")]),_vm._v("Filtriraj\r\n                        ")],1),_vm._v(" "),_c('v-card',[_c('v-card-title',[_c('div',{staticClass:"filter-title"},[_vm._v("\r\n                                    Filtriraj po\r\n                                ")])]),_vm._v(" "),_c('v-form',{staticClass:"filter",on:{"submit":_vm.filtriraj}},[_c('v-card-text',{staticClass:"pt-0"},[_c('v-text-field',{attrs:{"label":"Ime i prezime","hide-details":""},model:{value:(_vm.inputs.filter),callback:function ($$v) {_vm.$set(_vm.inputs, "filter", $$v)},expression:"inputs.filter"}})],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary"},on:{"click":_vm.ponistiFilter}},[_vm._v("Poništi")]),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary","type":"submit"}},[_vm._v("Filtriraj")])],1)],1)],1)],1)],1)],1)],1):_vm._e(),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headers,"items":_vm.model.items,"pagination":_vm.pagination,"total-items":_vm.totalItems,"no-data-text":"Nema korisnika za prikaz.","loading":_vm.loading,"rows-per-page-items":_vm.rowsPerPageItems},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('tr',{on:{"click":function($event){return _vm.otvoriPregledKorisnika(props.item.korisnickoIme)}}},[_c('td',[_vm._v(_vm._s(props.item.korisnickoIme))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.punoIme))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.uloga))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.onemogucen ? 'Nije aktivan':'Aktivan'))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_c('v-menu',{staticClass:"toolbar-menu",attrs:{"open-on-hover":"","offset-y":"","bottom":"","left":"","content-class":"dropdown-menu","transition":"slide-y-transition"}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("settings")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.korisnik.pregled', params: { korisnickoIme: props.item.korisnickoIme } }}},[_c('v-list-tile-title',[_vm._v("Pregled korisnika")])],1),_vm._v(" "),_c('v-list-tile',{attrs:{"to":{ name: 'home.korisnik.edit', params: { korisnickoIme: props.item.korisnickoIme } }}},[_c('v-list-tile-title',[_vm._v("Izmijeni korisnika")])],1)],1)],1)],1)])]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\r\n                    Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\r\n                ")]}}])})],1)],1),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.VratiTitlePoId('korisnik-list'),"content":_vm.VratiContentPoId('korisnik-list')},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/korisnik/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _list = require('./list');

var _list2 = _interopRequireDefault(_list);

var _dodavanje = require('./dodavanje');

var _dodavanje2 = _interopRequireDefault(_dodavanje);

var _pregled = require('./pregled');

var _pregled2 = _interopRequireDefault(_pregled);

var _edit = require('./edit');

var _edit2 = _interopRequireDefault(_edit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Korisnik',

    routes: [{
        path: '',
        name: 'home.korisnik.list',
        component: _list2.default
    }, {
        path: 'dodavanje',
        name: 'home.korisnik.dodavanje',
        component: _dodavanje2.default
    }, {
        path: 'edit/:korisnickoIme',
        name: 'home.korisnik.edit',
        component: _edit2.default
    }, {
        path: 'pregled/:korisnickoIme',
        name: 'home.korisnik.pregled',
        component: _pregled2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/korisnik/pregled.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'PregledKorisnik',
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            helpTipDialogTitle: "Pregled korisnika",
            helpTipDialogContent: 'Pregled podataka o korisniku.',
            resolved: null,
            identity: _identity2.default,
            odabranaUloga: {},
            korisnikModel: {},
            ucitanKorisnik: false,
            ulogaProjekti: [],
            kategorijeKorisnika: [],
            izabranaUlogaSupport: false,
            izabranaUlogaAdministrator: false
        };
    },
    created: function created() {
        this.ucitajKorisnika();
    },


    methods: {
        aktivirajKorisnika: function aktivirajKorisnika() {
            var that = this;

            var success = function success() {
                that.korisnikModel.onemogucen = false;
                that.$toast.info("Korisnik aktiviran");
            };

            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.KorisnikResource)().onemogucen(that.$route.params, {
                onemogucen: false
            });

            promise.then(success, error);
        },
        deAktivirajKorisnika: function deAktivirajKorisnika() {
            var that = this;

            var success = function success() {
                that.korisnikModel.onemogucen = true;
                that.$toast.info("Korisnik deaktiviran");
            };

            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.KorisnikResource)().onemogucen(that.$route.params, {
                onemogucen: true
            });

            promise.then(success, error);
        },
        ucitajKorisnika: function ucitajKorisnika() {
            var that = this;

            var success = function success(response) {
                that.korisnikModel = response.body;
                that.odabranaUloga = that.korisnikModel.uloge[0];
                if (that.odabranaUloga.vrstaUloge.uloga == 'Support') {
                    that.izabranaUlogaSupport = true;
                    that.izabranaUlogaAdministrator = false;
                } else if (that.odabranaUloga.vrstaUloge.uloga == 'Administrator') {
                    that.izabranaUlogaAdministrator = true;
                    that.izabranaUlogaSupport = false;
                }
                that.ucitajProjekteZaKorisnikUlogu(that.odabranaUloga.vrstaUloge.id);
                that.ucitajKategorijeKorisnika();
                that.ucitanKorisnik = true;
            };

            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.KorisnikResource)().get(this.$route.params);

            promise.then(success, error);
        },
        ucitajProjekteZaKorisnikUlogu: function ucitajProjekteZaKorisnikUlogu(ulogaId) {
            var that = this;

            var success = function success(response) {
                that.ulogaProjekti = response.body;
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.ProjekatResource)().vratiProjekteZaKorisnikUlogu({
                korisnickoIme: this.korisnikModel.korisnickoIme,
                ulogaId: ulogaId
            });

            promise.then(success, error);
        },
        ucitajKategorijeKorisnika: function ucitajKategorijeKorisnika() {
            var _this = this;

            var success = function success(response) {
                var that = _this;
                that.kategorijeKorisnika = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };
            var promise = (0, _resources.KorisnikResource)().vratiKategorijeKorisnika({
                korisnickoIme: this.$route.params.korisnickoIme
            });
            promise.then(success, error);
        }
    },
    resolve: {}
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitanKorisnik)?[_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Pregled korisnika ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-menu',{staticClass:"toolbar-menu",attrs:{"open-on-hover":"","offset-y":"","bottom":"","left":"","content-class":"dropdown-menu","transition":"slide-y-transition"}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("more_vert")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.korisnik.edit'}}},[_c('v-list-tile-title',[_vm._v("Izmijeni korisnika")])],1),_vm._v(" "),(_vm.korisnikModel.onemogucen)?_c('v-list-tile',{attrs:{"href":""},on:{"click":_vm.aktivirajKorisnika}},[_c('v-list-tile-title',[_vm._v("Aktiviraj korisnika")])],1):_vm._e(),_vm._v(" "),(!_vm.korisnikModel.onemogucen && _vm.imaPravo('korisnik_korisnik_aktivacija'))?_c('v-list-tile',{attrs:{"href":""},on:{"click":_vm.deAktivirajKorisnika}},[_c('v-list-tile-title',[_vm._v("Deaktiviraj korisnika")])],1):_vm._e()],1)],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('h4',[_vm._v("\r\n                    "+_vm._s(_vm.korisnikModel.punoIme)+"\r\n                ")]),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('table',{staticClass:"v-table"},[_c('tbody',[_c('tr',[_c('td',[_vm._v("Korisničko ime")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.korisnikModel.korisnickoIme))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Ime i prezime")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.korisnikModel.punoIme))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("E-mail")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.korisnikModel.email))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Datum nastanka")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.korisnikModel.datumKreiranja.substring(8,10) + '. ' + _vm.korisnikModel.datumKreiranja.substring(5,7)+ '. '+_vm.korisnikModel.datumKreiranja.substring(0,4) + '.'))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Status")]),_vm._v(" "),(!_vm.korisnikModel.onemogucen)?_c('td',[_vm._v("Aktivan")]):_vm._e(),_vm._v(" "),(_vm.korisnikModel.onemogucen)?_c('td',[_vm._v("Nije aktivan")]):_vm._e()]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Uloga korisnika")]),_vm._v(" "),_c('td',_vm._l((_vm.korisnikModel.uloge),function(uloga){return _c('v-chip',{key:uloga.id},[_c('strong',[_vm._v(_vm._s(uloga.vrstaUloge.uloga))])])}),1)]),_vm._v(" "),(!_vm.izabranaUlogaAdministrator)?_c('tr',[_c('td',[_vm._v("Projekti")]),_vm._v(" "),_c('td',_vm._l((_vm.ulogaProjekti),function(projekat){return _c('v-chip',{key:projekat.id},[_c('strong',[_vm._v(_vm._s(projekat.naziv))])])}),1)]):_vm._e(),_vm._v(" "),(_vm.izabranaUlogaSupport)?_c('tr',[_c('td',[_vm._v("Kategorije")]),_vm._v(" "),_c('td',_vm._l((_vm.kategorijeKorisnika),function(kategorija){return _c('v-chip',{key:kategorija.id},[_c('strong',[_vm._v(_vm._s(kategorija.detaljanNaziv))])])}),1)]):_vm._e()])])],1)],1)]:_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.helpTipDialogTitle,"content":_vm.helpTipDialogContent},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/module.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _auth = require("auth");

var _auth2 = _interopRequireDefault(_auth);

var _dashboard = require("./dashboard");

var _dashboard2 = _interopRequireDefault(_dashboard);

var _toolbar = require("./toolbar");

var _toolbar2 = _interopRequireDefault(_toolbar);

var _module = require("./racun/module");

var _module2 = _interopRequireDefault(_module);

var _module3 = require("./postavke/module");

var _module4 = _interopRequireDefault(_module3);

var _module5 = require("./korisnik/module");

var _module6 = _interopRequireDefault(_module5);

var _module7 = require("./uloge/module");

var _module8 = _interopRequireDefault(_module7);

var _module9 = require("./sifarnik/module");

var _module10 = _interopRequireDefault(_module9);

var _sidebar = require("./sidebar");

var _sidebar2 = _interopRequireDefault(_sidebar);

var _module11 = require("./izvjestaj/module");

var _module12 = _interopRequireDefault(_module11);

var _module13 = require("./dokumenti/module");

var _module14 = _interopRequireDefault(_module13);

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _module15 = require("./projekat/module");

var _module16 = _interopRequireDefault(_module15);

var _module17 = require("./zahtjev/module");

var _module18 = _interopRequireDefault(_module17);

var _resources = require("api/resources");

var _config = require("config");

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "Home",

    data: function data() {
        return {
            identity: _identity2.default,
            toggleState: {
                mini: false,
                drawer: true
            },
            toolbarTitle: window.document.title

        };
    },
    created: function created() {
        this.$vuetify.lang.locales.en = {
            dataIterator: {
                rowsPerPageText: 'Broj redova po stranici:',
                rowsPerPageAll: 'Sve',
                pageText: '{0}-{1} od {2}',
                noResultsText: 'Nema rezultata',
                nextPage: 'Sljedeća stranica',
                prevPage: 'Prethodna stranica'
            },
            dataTable: {
                rowsPerPageText: 'Broj redova po stranici:'
            },
            noDataText: 'Nema podataka'
        };
    },

    methods: {
        signOut: function signOut() {
            _auth2.default.signOut();

            this.$router.push({
                name: "auth.prijava"
            });
        },
        toggleSidebar: function toggleSidebar() {
            this.sidebarToggled = !this.sidebarToggled;
        }
    },
    watch: {
        $route: function $route() {
            this.toolbarTitle = window.document.title;
        }
    },
    components: {
        Toolbar: _toolbar2.default,
        sidebar: _sidebar2.default
    },

    routes: [{
        path: "",
        redirect: "dashboard"
    }, {
        path: "dashboard",
        name: "home.dashboard",
        component: _dashboard2.default
    }, {
        path: "racun/:korisnickoIme",
        name: "home.racun",
        component: _module2.default,
        children: _module2.default.routes
    }, {
        path: "korisnik",
        component: _module6.default,
        children: _module6.default.routes
    }, {
        path: "uloga",
        component: _module8.default,
        children: _module8.default.routes
    }, {
        path: "izvjestaj",
        component: _module12.default,
        children: _module12.default.routes
    }, {
        path: "postavke",
        component: _module4.default,
        children: _module4.default.routes
    }, {
        path: "sifarnik",
        component: _module10.default,
        children: _module10.default.routes
    }, {
        path: "dokumenti",
        component: _module14.default,
        children: _module14.default.routes
    }, {
        path: "projekat",
        component: _module16.default,
        children: _module16.default.routes
    }, {
        path: "zahtjev",
        component: _module18.default,
        children: _module18.default.routes
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-app',[_c('div',[_c('sidebar',{attrs:{"toggleState":_vm.toggleState,"app":""},on:{"sign-out":_vm.signOut}}),_vm._v(" "),_c('toolbar')],1),_vm._v(" "),_c('v-content',[_c('v-container',{attrs:{"fluid":"","id":"core-view"}},[_c('div',[_c('router-view')],1)]),_vm._v(" "),_c('v-footer',{attrs:{"id":"core-footer","absolute":"","height":"42"}},[_c('v-spacer'),_vm._v(" "),_c('span',{staticClass:"font-weight-light copyright"},[_vm._v("\r\n                ©\r\n                "+_vm._s((new Date()).getFullYear())+" DRAOS2\r\n            ")])],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/postavke/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _postavkeSistema = require('./postavke-sistema');

var _postavkeSistema2 = _interopRequireDefault(_postavkeSistema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Postavke',

    routes: [{
        path: 'postavke-sistema',
        name: 'home.postavke.postavke-sistema',
        component: _postavkeSistema2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/postavke/postavke-sistema.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _postavke = require('postavke/postavke');

var _postavke2 = _interopRequireDefault(_postavke);

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'PostavkeSistema',

    data: function data() {
        return {
            resolved: null,
            rules: {
                obavezno: [function (v) {
                    return !!v || 'Polje je obavezno';
                }],
                obavezno32: [function (v) {
                    return !!v || 'Polje je obavezno';
                }, function (v) {
                    return !!v && v.length <= 32 || 'Polje mora biti manje od 32 karaktera';
                }],
                obavezno64: [function (v) {
                    return !!v || 'Polje je obavezno';
                }, function (v) {
                    return !!v && v.length <= 64 || 'Polje mora biti manje od 64 karaktera';
                }],
                obavezno128: [function (v) {
                    return !!v || 'Polje je obavezno';
                }, function (v) {
                    return !!v && v.length <= 128 || 'Polje mora biti manje od 64 karaktera';
                }],
                obavezno256: [function (v) {
                    return !!v || 'Polje je obavezno';
                }, function (v) {
                    return !!v && v.length <= 256 || 'Polje mora biti manje od 64 karaktera';
                }]
            },
            identity: _identity2.default
        };
    },


    methods: {
        onSubmit: function onSubmit() {
            var that = this;

            var success = function success(response) {
                _postavke2.default.setPostavke(response.body);
                that.$toast.success('Uspješno ažuriranje postavki.');
            };
            var error = function error() {
                that.$toast.error('Ažuriranje postavki nije uspjelo.');
            };

            var promise = (0, _resources.PostavkeResource)().update(that.$route.params, that.resolved.postavke);

            promise.then(success, error);
        }
    },

    resolve: {
        postavke: function postavke() {
            return (0, _resources.PostavkeResource)().get();
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?_c('material-card',{attrs:{"title":"Postavke sistema","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno64,"counter":64,"label":"Glavni naslov sistema","required":""},model:{value:(_vm.resolved.postavke.naslovSistema),callback:function ($$v) {_vm.$set(_vm.resolved.postavke, "naslovSistema", $$v)},expression:"resolved.postavke.naslovSistema"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"type":_vm.number,"min":"0","max":"10","label":"Vrijeme trajanja sesije (u danima)","required":""},model:{value:(_vm.resolved.postavke.trajanjeSesije),callback:function ($$v) {_vm.$set(_vm.resolved.postavke, "trajanjeSesije", $$v)},expression:"resolved.postavke.trajanjeSesije"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno128,"counter":128,"label":"URL Karte","required":""},model:{value:(_vm.resolved.postavke.urlKarte),callback:function ($$v) {_vm.$set(_vm.resolved.postavke, "urlKarte", $$v)},expression:"resolved.postavke.urlKarte"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno256,"counter":256,"label":"Autorska prava karte","required":""},model:{value:(_vm.resolved.postavke.autorskaPravaKarte),callback:function ($$v) {_vm.$set(_vm.resolved.postavke, "autorskaPravaKarte", $$v)},expression:"resolved.postavke.autorskaPravaKarte"}})],_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Spasi")])],1)],2)],1)],1):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/dio-projekta/list.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "ListDioProjekta",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,
            validDioProjekta: false,
            validKategorija: false,
            model: {},
            projekatModel: {},

            dioProjektaModel: {},
            dijeloviProjektaModel: [],
            rules: {
                nazivDioProjekta: [function (v) {
                    return !!v || "Morate da unesete naziv";
                }, function (v) {
                    return v && v.length <= 32 || "Naziv ne može biti veći od 32 karaktera";
                }],

                nazivKategorija: [function (v) {
                    return !!v || "Morate da unesete naziv";
                }, function (v) {
                    return v && v.length <= 128 || "Naziv ne može biti veći od 128 karaktera";
                }]
            },
            headersDijeloviProjekta: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }],
            headersZahtjevKategorije: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }],

            ucitaniDijeloviProjekta: false,
            dialogDijeloviProjekta: false,
            dialogZahtjevKategorije: false,
            zahtjevKategorijeDijelaProjekta: [],
            kategorijaZahtjevaModel: {},
            dioProjektaId: null

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajDijeloveProjekta();
    },
    created: function created() {},

    methods: {
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        ucitajDijeloveProjekta: function ucitajDijeloveProjekta() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.dijeloviProjektaModel = response.body;
                that.ucitaniDijeloviProjekta = true;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        dodajNoviDioProjekta: function dodajNoviDioProjekta() {
            var _this2 = this;

            this.validDioProjekta = this.$refs.formDioProjekta.validate();
            this.focusInvalidInput(this.$refs.formDioProjekta);

            if (!this.validDioProjekta) return;else {
                var that = this;

                var success = function success() {
                    _this2.$toast.success("Uspješno dodano.");
                    that.$router.push({
                        name: 'home.projekat.pregled'
                    });
                    that.dialogDijeloviProjekta = false;
                    _this2.ucitajDijeloveProjekta();
                };
                var error = function error() {
                    _this2.$toast.error('Promjena podataka nije uspjela.');
                };

                var promise = (0, _resources.ProjekatResource)().dodajNoviDioProjekta(that.$route.params, this.dioProjektaModel);
                promise.then(success, error);
            }
        },
        dodajZahtjevKategoriju: function dodajZahtjevKategoriju(id) {
            var _this3 = this;

            this.validKategorija = this.$refs.formKategorija.validate();
            this.focusInvalidInput(this.$refs.formKategorija);

            if (!this.validKategorija) return;else {
                var that = this;

                var success = function success() {
                    _this3.$toast.success("Uspješno dodano.");
                    that.$router.push({
                        name: 'home.projekat.pregled'
                    });
                    that.dialogZahtjevKategorije = false;
                    _this3.ucitajKategorijeZahtjeva(id);
                };
                var error = function error() {
                    _this3.$toast.error('Promjena podataka nije uspjela.');
                };

                var promise = (0, _resources.ProjekatResource)().dodajNovuZahtjevKategoriju({
                    dioProjektaId: id
                }, this.kategorijaZahtjevaModel);
                promise.then(success, error);
            }
        },
        ucitajKategorijeZahtjeva: function ucitajKategorijeZahtjeva(id) {
            var _this4 = this;

            var success = function success(response) {

                var that = _this4;
                that.zahtjevKategorijeDijelaProjekta = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: id
            });

            promise.then(success, error);
        },
        otvoriKategorijeZahtjeva: function otvoriKategorijeZahtjeva(id) {
            this.dialogZahtjevKategorije = true;
            this.dioProjektaId = id;
            this.ucitajKategorijeZahtjeva(id);
        }
    },
    resolve: {
        model: function model() {
            return (0, _resources.ProjekatResource)().vratiProjekat({
                projekatId: this.$route.params.projekatId
            });
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaniDijeloviProjekta)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogDijeloviProjekta=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                DODAJ\r\n            ")],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Dijelovi projekta ")])])],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"hide-actions":true,"headers":_vm.headersDijeloviProjekta,"items":_vm.dijeloviProjektaModel,"no-data-text":"Nema dijelova projekta."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_c('v-menu',{staticClass:"toolbar-menu",attrs:{"open-on-hover":"","offset-y":"","bottom":"","left":"","content-class":"dropdown-menu","transition":"slide-y-transition"}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("settings")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{on:{"click":function($event){return _vm.otvoriKategorijeZahtjeva(props.item.id)}}},[_c('v-list-tile-title',[_vm._v("Kategorije zahtjeva")])],1)],1)],1)],1)]}}],null,false,3828547369)})],1)]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogDijeloviProjekta),callback:function ($$v) {_vm.dialogDijeloviProjekta=$$v},expression:"dialogDijeloviProjekta"}},[_c('v-form',{ref:"formDioProjekta",model:{value:(_vm.validDioProjekta),callback:function ($$v) {_vm.validDioProjekta=$$v},expression:"validDioProjekta"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje novog dijela projekta")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"rules":_vm.rules.nazivDioProjekta,"label":"Naziv","required":""},model:{value:(_vm.dioProjektaModel.naziv),callback:function ($$v) {_vm.$set(_vm.dioProjektaModel, "naziv", $$v)},expression:"dioProjektaModel.naziv"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogDijeloviProjekta = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviDioProjekta()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)],1)],_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogZahtjevKategorije),callback:function ($$v) {_vm.dialogZahtjevKategorije=$$v},expression:"dialogZahtjevKategorije"}},[_c('v-form',{ref:"formKategorija",model:{value:(_vm.validKategorija),callback:function ($$v) {_vm.validKategorija=$$v},expression:"validKategorija"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodaj kategoriju zahtjeva za dio projekta")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"rules":_vm.rules.nazivKategorija,"label":"Naziv","required":""},model:{value:(_vm.kategorijaZahtjevaModel.naziv),callback:function ($$v) {_vm.$set(_vm.kategorijaZahtjevaModel, "naziv", $$v)},expression:"kategorijaZahtjevaModel.naziv"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headersZahtjevKategorije,"items":_vm.zahtjevKategorijeDijelaProjekta,"no-data-text":"Nema kategorija zahtjeva."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))])]}}])}),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogZahtjevKategorije = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajZahtjevKategoriju(_vm.dioProjektaId)}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/dio-projekta/pregled.vue", function(exports, require, module) {
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)

});

;require.register("modules/home/projekat/dodavanje.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "DodavanjeProjekta",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,
            valid: false,
            identity: _identity2.default,

            rules: {
                nazivProjekta: [function (v) {
                    return !!v || "Morate da unesete naziv projekta";
                }, function (v) {
                    return v && v.length <= 128 || "Naziv projekta mora biti manji od 128 karaktera";
                }]
            },
            model: {
                naziv: null,
                opis: null
            },

            uloge: []
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    created: function created() {},

    methods: {
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        onSubmit: function onSubmit() {
            var _this = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);
            var that = this;
            if (that.valid) {
                var success = function success(model) {
                    _this.proslijedi = true;
                    that.$router.push({
                        name: "home.projekat.pregled",
                        params: {
                            projekatId: model.body.id
                        }
                    });
                    that.$toast.success("Uspješno kreiran novi projekat.");
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };

                var promise = (0, _resources.ProjekatResource)().save(that.$route.params, that.model);
                promise.then(success, error);
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"title":"Dodaj projekat","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.nazivProjekta,"counter":128,"label":"Naziv projekta","required":""},model:{value:(_vm.model.naziv),callback:function ($$v) {_vm.$set(_vm.model, "naziv", $$v)},expression:"model.naziv"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"counter":128,"label":"Opis","required":""},model:{value:(_vm.model.opis),callback:function ($$v) {_vm.$set(_vm.model, "opis", $$v)},expression:"model.opis"}}),_vm._v(" "),_c('br'),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Dodaj")])],1)],1)],1)],1),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _list = require("./dio-projekta/list.vue");

var _list2 = _interopRequireDefault(_list);

var _edit = require("./konfiguracija-projekta/edit.vue");

var _edit2 = _interopRequireDefault(_edit);

var _edit3 = require("./zahtjev-prioritet/edit.vue");

var _edit4 = _interopRequireDefault(_edit3);

var _edit5 = require("./zahtjev-status/edit.vue");

var _edit6 = _interopRequireDefault(_edit5);

var _edit7 = require("./zahtjev-tip/edit.vue");

var _edit8 = _interopRequireDefault(_edit7);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditProjekta",

    components: {
        Upit: _upit2.default,
        ListDioProjekta: _list2.default,
        EditKonfiguracijeProjekta: _edit2.default,
        EditZahtjevPrioriteta: _edit4.default,
        EditZahtjevStatusa: _edit6.default,
        EditZahtjevTipova: _edit8.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            editProjekta: false,
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            ucitanProjekat: false,
            identity: _identity2.default,
            valid: false,
            model: {},
            projekatModel: {},
            sati: [],
            minute: [],
            rules: {
                punoIme: [function (v) {
                    return !!v || "Morate da unesete naziv";
                }, function (v) {
                    return v && v.length <= 128 || "Naziv mora biti manji od 128 karaktera";
                }]
            }

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajProjekat();
    },
    created: function created() {},

    methods: {
        Odustani: function Odustani() {
            this.edit = true;
            this.$emit('onemogucenEdit');
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        onSubmit: function onSubmit() {
            var _this = this;

            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);
            console.log("valid", this.valid);
            if (this.valid) {
                var that = this;

                var success = function success(model) {
                    _this.$toast.success("Uspješno ažuriran projekat.");
                    _this.$emit('onemogucenEdit');
                };
                var error = function error() {
                    that.$toast.error('Promjena podataka nije uspjela.');
                };

                var promise = (0, _resources.ProjekatResource)().azurirajProjekat(that.$route.params, that.projekatModel);

                promise.then(success, error);
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        ucitajProjekat: function ucitajProjekat() {
            var _this2 = this;

            var success = function success(response) {

                var that = _this2;
                that.projekatModel = response.body;

                that.ucitanProjekat = true;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        }
    },
    resolve: {
        model: function model() {
            return (0, _resources.ProjekatResource)().vratiProjekat({
                projekatId: this.$route.params.projekatId
            });
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.punoIme,"counter":128,"label":"Naziv","required":""},model:{value:(_vm.projekatModel.naziv),callback:function ($$v) {_vm.$set(_vm.projekatModel, "naziv", $$v)},expression:"projekatModel.naziv"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"counter":256,"label":"Opis","required":""},model:{value:(_vm.projekatModel.opis),callback:function ($$v) {_vm.$set(_vm.projekatModel, "opis", $$v)},expression:"projekatModel.opis"}}),_vm._v(" "),_c('br'),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('v-btn',{attrs:{"color":"tertiary"},on:{"click":_vm.Odustani}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Snimi")])],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/konfiguracija-projekta/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _timePickerModal = require("./time-picker-modal.vue");

var _timePickerModal2 = _interopRequireDefault(_timePickerModal);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditKonfiguracijeProjekta",

    components: {
        Upit: _upit2.default,
        TimePickerModal: _timePickerModal2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,
            valid: false,
            model: {},
            projekatModel: {},
            sati: [],
            minute: [],

            rules: {},

            konfiguracijaProjekta: null,
            ucitanaKonfiguracijaProjekta: false,

            radniDani: [],

            sviDani: ["Ponedjeljak", "Utorak", "Srijeda", "Četvrtak", "Petak", "Subota", "Nedjelja"]
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajKonfiguracijuProjekta();
    },
    created: function created() {},

    methods: {
        konvertujStringURadneDane: function konvertujStringURadneDane() {
            var nizDani = this.konfiguracijaProjekta.radniDani.split("");

            for (var i = 0; i < nizDani.length; i++) {
                if (nizDani[i] == "1") {
                    switch (i) {
                        case 0:
                            this.radniDani.push("Ponedjeljak");
                            break;
                        case 1:
                            this.radniDani.push("Utorak");
                            break;
                        case 2:
                            this.radniDani.push("Srijeda");
                            break;
                        case 3:
                            this.radniDani.push("Četvrtak");
                            break;
                        case 4:
                            this.radniDani.push("Petak");
                            break;
                        case 5:
                            this.radniDani.push("Subota");
                            break;
                        case 6:
                            this.radniDani.push("Nedjelja");
                            break;
                    }
                }
            }
        },
        ucitajKonfiguracijuProjekta: function ucitajKonfiguracijuProjekta() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.konfiguracijaProjekta = response.body;

                that.ucitanaKonfiguracijaProjekta = true;
                _this.konvertujStringURadneDane();
            };
            var error = function error(poruka) {
                console.log("nije uspjelo");

                _this.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ProjekatResource)().vratiKonfiguracijuProjekta({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        snimiKonfiguracijuProjekta: function snimiKonfiguracijuProjekta() {
            var _this2 = this;

            var dani = "0000000";
            var nizDani = dani.split("");

            for (var i = 0; i < this.radniDani.length; i++) {

                switch (this.radniDani[i].toString()) {
                    case "Ponedjeljak":
                        nizDani[0] = "1";
                        break;
                    case "Utorak":
                        nizDani[1] = "1";
                        break;
                    case "Srijeda":
                        nizDani[2] = "1";
                        break;
                    case "Četvrtak":
                        nizDani[3] = "1";
                        break;
                    case "Petak":
                        nizDani[4] = "1";
                        break;
                    case "Subota":
                        nizDani[5] = "1";
                        break;
                    case "Nedjelja":
                        nizDani[6] = "1";
                        break;
                }
            }

            dani = nizDani.join("");
            this.konfiguracijaProjekta.radniDani = dani;

            var that = this;

            var success = function success() {
                _this2.$toast.success("Uspješno ažurirana konfiguracija.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
            };
            var error = function error(poruka) {
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ProjekatResource)().snimiKonfiguracijuProjekta(that.$route.params, this.konfiguracijaProjekta);

            promise.then(success, error);
        },
        ispisiRadnoVrijeme: function ispisiRadnoVrijeme(vrijemeOd, vrijemeDo) {
            if (vrijemeOd >= vrijemeDo) this.$toast.error('Početak radnog vremena mora biti prije kraja radnog vremena.');else {
                this.konfiguracijaProjekta.radnoVrijemeOd = vrijemeOd;
                this.konfiguracijaProjekta.radnoVrijemeDo = vrijemeDo;
                this.snimiKonfiguracijuProjekta();
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitanaKonfiguracijaProjekta)?[_c('table',{staticClass:"v-table"},[_c('tbody',[_c('tr',[_c('td',[_vm._v("Radno vrijeme od: ")]),_vm._v(" "),_c('td',{staticStyle:{"float":"left"}},[_vm._v(_vm._s(_vm.konfiguracijaProjekta.radnoVrijemeOd))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Radno vrijeme do: ")]),_vm._v(" "),_c('td',{staticStyle:{"float":"left"}},[_vm._v(_vm._s(_vm.konfiguracijaProjekta.radnoVrijemeDo))])]),_vm._v(" "),_c('tr',[_c('td'),_vm._v(" "),_c('td',[_c('time-picker-modal',{staticStyle:{"float":"left"},attrs:{"pocetnoVrijeme":_vm.konfiguracijaProjekta.radnoVrijemeOd,"krajnjeVrijeme":_vm.konfiguracijaProjekta.radnoVrijemeDo},on:{"potvrda":_vm.ispisiRadnoVrijeme}},[_c('v-btn',{staticClass:"potvrdiBtn",attrs:{"slot":"activator","color":"primary"},slot:"activator"},[_c('v-icon',[_vm._v("add")]),_vm._v(" Izmjena radnog vremena\r\n                            ")],1)],1)],1)]),_vm._v(" "),_c('tr'),_vm._v(" "),_c('tr',[_c('v-select',{staticClass:"required",attrs:{"multiple":true,"required":"","items":_vm.sviDani,"item-text":"naziv","label":"Radni dani","bottom":""},model:{value:(_vm.radniDani),callback:function ($$v) {_vm.radniDani=$$v},expression:"radniDani"}})],1)])]),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.snimiKonfiguracijuProjekta()}}},[_vm._v("Snimi")])]:_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/konfiguracija-projekta/pregled.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "PregledKonfiguracijeProjekta",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,
            boje: ["secondary", "secondary", "cyan", "teal", "secondary-grey", "green"],
            valid: false,
            model: {},
            projekatModel: {},
            sati: [],
            minute: [],

            rules: {
                punoIme: [function (v) {
                    return !!v || "Morate da unesete ime i prezime";
                }, function (v) {
                    return v && v.length <= 128 || "Ime i prezime mora biti manje od 128 karaktera";
                }]
            },

            konfiguracijaProjekta: null,
            ucitanaKonfiguracijaProjekta: false,

            radniDani: [],

            sviDani: ["Ponedjeljak", "Utorak", "Srijeda", "Četvrtak", "Petak", "Subota", "Nedjelja"]
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajKonfiguracijuProjekta();
    },
    created: function created() {},

    methods: {
        konvertujStringURadneDane: function konvertujStringURadneDane() {
            var nizDani = this.konfiguracijaProjekta.radniDani.split("");

            for (var i = 0; i < nizDani.length; i++) {
                if (nizDani[i] == "1") {
                    switch (i) {
                        case 0:
                            this.radniDani.push("Ponedjeljak");
                            break;
                        case 1:
                            this.radniDani.push("Utorak");
                            break;
                        case 2:
                            this.radniDani.push("Srijeda");
                            break;
                        case 3:
                            this.radniDani.push("Četvrtak");
                            break;
                        case 4:
                            this.radniDani.push("Petak");
                            break;
                        case 5:
                            this.radniDani.push("Subota");
                            break;
                        case 6:
                            this.radniDani.push("Nedjelja");
                            break;
                    }
                }
            }
        },
        ucitajKonfiguracijuProjekta: function ucitajKonfiguracijuProjekta() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.konfiguracijaProjekta = response.body;

                that.ucitanaKonfiguracijaProjekta = true;
                _this.konvertujStringURadneDane();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiKonfiguracijuProjekta({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        snimiKonfiguracijuProjekta: function snimiKonfiguracijuProjekta() {
            var _this2 = this;

            var dani = "0000000";
            var nizDani = dani.split("");

            for (var i = 0; i < this.radniDani.length; i++) {

                switch (this.radniDani[i].toString()) {
                    case "Ponedjeljak":
                        nizDani[0] = "1";
                        break;
                    case "Utorak":
                        nizDani[1] = "1";
                        break;
                    case "Srijeda":
                        nizDani[2] = "1";
                        break;
                    case "Četvrtak":
                        nizDani[3] = "1";
                        break;
                    case "Petak":
                        nizDani[4] = "1";
                        break;
                    case "Subota":
                        nizDani[5] = "1";
                        break;
                    case "Nedjelja":
                        nizDani[6] = "1";
                        break;
                }
            }

            dani = nizDani.join("");
            this.konfiguracijaProjekta.radniDani = dani;

            var that = this;

            var success = function success() {
                _this2.$toast.success("Uspješno ažurirana konfiguracija.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
            };
            var error = function error() {};

            var promise = (0, _resources.ProjekatResource)().snimiKonfiguracijuProjekta(that.$route.params, this.konfiguracijaProjekta);

            promise.then(success, error);
        },
        ispisiRadnoVrijeme: function ispisiRadnoVrijeme(vrijemeOd, vrijemeDo) {
            this.konfiguracijaProjekta.radnoVrijemeOd = vrijemeOd;
            this.konfiguracijaProjekta.radnoVrijemeDo = vrijemeDo;
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitanaKonfiguracijaProjekta)?[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Konfiguracija projekta ")])])],1)],1),_vm._v(" "),_c('table',{staticClass:"v-table"},[_c('time-picker-modal',{staticStyle:{"float":"right"},attrs:{"pocetnoVrijeme":_vm.konfiguracijaProjekta.radnoVrijemeOd,"krajnjeVrijeme":_vm.konfiguracijaProjekta.radnoVrijemeDo},on:{"potvrda":_vm.ispisiRadnoVrijeme}},[_c('v-btn',{staticClass:"potvrdiBtn",attrs:{"slot":"activator","color":"primary"},slot:"activator"},[_c('v-icon',[_vm._v("edit")]),_vm._v("Edit\r\n                    ")],1)],1),_vm._v(" "),_c('tbody',[_c('tr',[_c('td',[_vm._v("Radno vrijeme od: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.konfiguracijaProjekta.radnoVrijemeOd))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Radno vrijeme do: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.konfiguracijaProjekta.radnoVrijemeDo))])]),_vm._v(" "),_c('tr',[_c('v-select',{staticClass:"required",attrs:{"multiple":true,"disabled":true,"required":"","items":_vm.sviDani,"item-text":"naziv","label":"Radni dani","bottom":""},model:{value:(_vm.radniDani),callback:function ($$v) {_vm.radniDani=$$v},expression:"radniDani"}})],1)])],1)]:_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/konfiguracija-projekta/time-picker-modal.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _moment = require("moment");

var _moment2 = _interopRequireDefault(_moment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "TimePickerModal",
    props: {

        pocetnoVrijeme: {
            default: null
        },
        krajnjeVrijeme: {
            default: null
        },
        value: {
            default: null
        },
        mask: {
            default: "##. ##. ####."
        },
        dateFormat: {
            default: "DDMMYYYY"
        },
        inputClass: {
            type: String
        },
        allowedDates: {
            default: function _default() {
                return function () {
                    return true;
                };
            }
        },
        potvrdiTekst: {
            type: String,
            default: "Potvrdi"
        },
        odustaniTekst: {
            type: String,
            default: "Poništi"
        },
        trajan: {
            type: Boolean,
            default: true
        },
        width: {
            type: Number,
            default: 430
        }
    },
    data: function data() {
        return {
            date: new Date().toISOString().substr(0, 10),
            menu: false,
            dateTimeValueInput: "",
            dateTimeValuePicker: null,
            rules: [],
            valid: true,
            dialog: false,
            sati: [],
            minute: [],
            radnoVrijemeOd: null,
            radnoVrijemeDo: null,
            model: {
                datumVrijemeOdrzavanja: null,
                satOd: null,
                minutaOd: null,
                satDo: null,
                minutaDo: null
            }
        };
    },

    computed: {
        dateTimeValue: function dateTimeValue() {
            return this.value;
        }
    },
    created: function created() {
        this.sati = this.dajSate();
        this.minute = this.dajMinute();
        this.model.satOd = this.pocetnoVrijeme.slice(0, 2);
        this.model.minutaOd = this.pocetnoVrijeme.slice(3, 5);

        this.model.satDo = this.krajnjeVrijeme.slice(0, 2);
        this.model.minutaDo = this.krajnjeVrijeme.slice(3, 5);
        this.update(this.value);
    },


    watch: {
        value: function value(newValue, oldValue) {
            if (newValue !== oldValue) {
                var datum = _moment2.default.utc(newValue);
                if (newValue != null && this.ispravanDatum(datum)) {
                    this.dateTimeValueInput = _moment2.default.utc(newValue).format(this.dateFormat);
                    this.dateTimeValuePicker = _moment2.default.utc(newValue).format("YYYY-MM-DD");
                } else {
                    this.dateTimeValueInput = "";

                    this.dateTimeValuePicker = _moment2.default.utc().format();
                }
            }
        }
    },

    methods: {
        update: function update(value) {
            var datum = _moment2.default.utc(value);
            if (this.ispravanDatum(datum)) {
                this.dateTimeValuePicker = _moment2.default.utc(value).format("YYYY-MM-DD");
                this.dateTimeValueInput = _moment2.default.utc(value).format(this.dateFormat);
                this.emit();
            }
        },
        dodajMinute: function dodajMinute() {
            if (this.model.satOd != null && this.model.minutaOd != null) {}
        },
        closeMenu: function closeMenu() {
            this.$refs.menu.save(this.dateTimeValuePicker);

            var datum = _moment2.default.utc(this.dateTimeValuePicker);
            if (!this.ispravanDatum(datum)) {
                this.dateTimeValuePicker = "";
            }
            this.emit();
        },
        ispravanDatum: function ispravanDatum(datum) {
            return datum.isValid() && this.allowedDates(datum.toDate());
        },
        updateDatepicker: function updateDatepicker() {
            var datum = _moment2.default.utc(this.dateTimeValueInput, this.dateFormat, true);
            if (this.ispravanDatum(datum)) {
                this.dateTimeValuePicker = datum.format("YYYY-MM-DD");
            } else {
                this.dateTimeValuePicker = "";
            }
            this.emit();
        },
        emit: function emit() {
            var datum = _moment2.default.utc(this.dateTimeValuePicker);

            if (this.ispravanDatum(datum)) {
                this.$emit("input", _moment2.default.utc(this.dateTimeValuePicker).toDate());
            } else {
                this.$emit("input", null);
            }
        },
        getStringDate: function getStringDate() {
            return this.dateTimeValueInput;
        },
        odgovor: function odgovor(val) {
            if (val == false) {
                this.dialog = false;
                return;
            }
            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);
            if (!this.valid) return;
            this.dialog = false;
            var vrijemeOd = (this.model.satOd.length == 1 ? '0' + this.model.satOd : this.model.satOd) + ":" + this.model.minutaOd;
            var vrijemeDo = (this.model.satDo.length == 1 ? '0' + this.model.satDo : this.model.satDo) + ":" + this.model.minutaDo;

            this.$emit("potvrda", vrijemeOd, vrijemeDo);
        },
        dajSate: function dajSate() {
            var sati = [];
            for (var index = 0; index < 24; index++) {
                if (index < 10) {
                    sati.push('0' + index.toString());
                } else {
                    sati.push(index.toString());
                }
            }
            return sati;
        },
        dajMinute: function dajMinute() {
            var minute = [];
            for (var index = 0; index < 60; index += 5) {
                var naziv = index == 0 || index == 5 ? '0' + index.toString() : index.toString();
                minute.push(naziv);
            }
            return minute;
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-dialog',{attrs:{"persistent":_vm.trajan,"width":_vm.width},model:{value:(_vm.dialog),callback:function ($$v) {_vm.dialog=$$v},expression:"dialog"}},[_c('div',{attrs:{"slot":"activator"},slot:"activator"},[_vm._t("activator")],2),_vm._v(" "),_c('v-card',[_c('v-card-title',{staticStyle:{"padding":"0px"}},[_c('h3',{staticClass:"naslov"},[_vm._v("Izmjena radnog vremena")])]),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_vm._t("kartica"),_vm._v(" "),_c('v-layout',{attrs:{"row":"","wrap":""}},[_c('v-flex',{attrs:{"xs6":"","md6":"","lg6":""}},[_c('div',{staticStyle:{"margin-top":"15px"}},[_vm._v("Vrijeme od")]),_vm._v(" "),_c('div',{staticStyle:{"display":"inline-block"}},[_c('v-autocomplete',{staticStyle:{"width":"70px","display":"inline-block"},attrs:{"rules":_vm.rules.obaveznoVrijeme,"flat":"","solo":"","small":"","append-icon":"unfold_more","items":_vm.sati,"item-text":"naziv","item-value":"id","persistent-hint":""},on:{"change":_vm.dodajMinute},model:{value:(_vm.model.satOd),callback:function ($$v) {_vm.$set(_vm.model, "satOd", $$v)},expression:"model.satOd"}}),_vm._v(" "),_c('v-autocomplete',{staticStyle:{"width":"70px","display":"inline-block"},attrs:{"rules":_vm.rules.obaveznoVrijeme,"flat":"","solo":"","small":"","append-icon":"unfold_more","items":_vm.minute,"item-text":"naziv","item-value":"id","persistent-hint":""},on:{"change":_vm.dodajMinute},model:{value:(_vm.model.minutaOd),callback:function ($$v) {_vm.$set(_vm.model, "minutaOd", $$v)},expression:"model.minutaOd"}})],1)]),_vm._v(" "),_c('v-flex',{attrs:{"xs6":"","md6":"","lg6":""}},[_c('div',{staticStyle:{"float":"right"}},[_c('div',{staticStyle:{"margin-top":"15px"}},[_vm._v("Vrijeme do")]),_vm._v(" "),_c('div',{staticStyle:{"display":"inline-block"}},[_c('v-autocomplete',{staticStyle:{"width":"70px","display":"inline-block"},attrs:{"rules":_vm.rules.obaveznoVrijeme,"flat":"","solo":"","small":"","append-icon":"unfold_more","items":_vm.sati,"item-text":"naziv","item-value":"id","persistent-hint":""},model:{value:(_vm.model.satDo),callback:function ($$v) {_vm.$set(_vm.model, "satDo", $$v)},expression:"model.satDo"}}),_vm._v(" "),_c('v-autocomplete',{staticStyle:{"width":"70px","display":"inline-block"},attrs:{"rules":_vm.rules.obaveznoVrijeme,"flat":"","solo":"","small":"","append-icon":"unfold_more","items":_vm.minute,"item-text":"naziv","item-value":"id","persistent-hint":""},model:{value:(_vm.model.minutaDo),callback:function ($$v) {_vm.$set(_vm.model, "minutaDo", $$v)},expression:"model.minutaDo"}})],1)])])],1)],2)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{staticClass:"odustani",attrs:{"flat":""},on:{"click":function($event){$event.stopPropagation();return _vm.odgovor(false)}}},[_vm._v(_vm._s(_vm.odustaniTekst))]),_vm._v(" "),_c('v-btn',{staticClass:"btn-snimi",attrs:{"flat":""},on:{"click":function($event){$event.stopPropagation();return _vm.odgovor(true)}}},[_c('v-icon',{attrs:{"color":"white"}},[_vm._v("add")]),_vm._v(_vm._s(_vm.potvrdiTekst)+"\r\n            ")],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []
__vue__options__._scopeId = "data-v-275fab22"

});

;require.register("modules/home/projekat/korisnik-dodavanje.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "DodavanjeKorisnikaProjekat",

    components: {
        Upit: _upit2.default
    },
    props: ['ul', 'korisnickoIme'],
    mixins: [_helpTipDialogMixin2.default],
    created: function created() {
        console.log(this.korisnickoIme);
        this.odabranaUloga = this.ul[0].vrstaUloge.id;
        this.korisnikModel.uloge = this.ul;
        console.log(this.odabranaUloga);
        this.ucitajProjekteZaKorisnikUlogu(this.odabranaUloga);
        this.ucitajSveProjekte();
        console.log("tessssssst");
        console.log(this.ul);
    },
    data: function data() {
        return {
            activeHelpTip: false,
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,
            valid: false,
            identity: _identity2.default,
            boje: ["indigo", "blue", "cyan", "teal", "blue-grey", "green"],

            model: {
                korisnickoIme: null,
                email: null,
                punoIme: null,
                lozinka: null,
                projekti: []
            },
            korisnikModel: {},
            odabranaUloga: {},
            ucitaniProjekti: false,
            projektiKorisnika: [],
            ulogaProjekti: [],

            inputs: {
                sve: true
            },
            dialogDodajKorisnikaNaProjekat: true,
            porukeGreška: []

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },

    methods: {
        ucitajSveProjekte: function ucitajSveProjekte() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.projekti = response.body;
                _this.ucitaniProjekti = true;
                console.log(that.projekti);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(this.inputs);
            promise.then(success, error);
        },
        ucitajProjekteZaKorisnikUlogu: function ucitajProjekteZaKorisnikUlogu(ulogaId) {
            var that = this;

            var success = function success(response) {
                that.ulogaProjekti = response.body;
                console.log("uloga projekti");
                console.log(that.ulogaProjekti);
                that.ucitajProjekte();
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.ProjekatResource)().vratiProjekteZaKorisnikUlogu({
                korisnickoIme: this.korisnickoIme,
                ulogaId: ulogaId
            });

            promise.then(success, error);
        },
        ucitajProjekte: function ucitajProjekte() {
            var that = this;

            var success = function success(response) {
                that.projekti = response.body;
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(that.inputs);

            promise.then(success, error);
        },
        remove: function remove(item) {
            this.model.uloge.splice(this.model.uloge.indexOf(item), 1);
            this.model.uloge = [].concat((0, _toConsumableArray3.default)(this.model.uloge));
        },
        removeProjekat: function removeProjekat(item) {
            this.model.projekti.splice(this.model.projekti.indexOf(item), 1);
            this.model.projekti = [].concat((0, _toConsumableArray3.default)(this.model.projekti));
        },
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        ucitajUloge: function ucitajUloge(ul) {
            console.log("tessssst");
            console.log(this.ul);
            this.model.uloge = ul;
            console.log(this.model.uloge);
        },
        onSubmit: function onSubmit() {
            var _this2 = this;

            console.log(this.odabranaUloga);
            console.log(this.ulogaProjekti);
            console.log(this.korisnickoIme);

            var model = {
                ulogaId: this.odabranaUloga,
                projekti: []
            };

            for (var index = 0; index < this.ulogaProjekti.length; index++) {
                model.projekti.push(this.ulogaProjekti[index].id);
            }
            console.log(model);
            var that = this;
            var success = function success(model) {
                _this2.proslijedi = true;
                that.$router.push({
                    name: "home.korisnik.edit",
                    params: {
                        korisnickoIme: model.body.korisnickoIme
                    }
                });
            };
            var error = function error(poruka) {
                if (poruka.body.Email != undefined) _this2.porukeGreška.push(poruka.body.Email[0]);
                console.log(_this2.porukeGreška[0]);
                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.KorisnikResource)().azurirajProjekteKorisnika({
                korisnickoIme: that.korisnickoIme
            }, model);
            promise.then(success, error);
        }
    },
    resolve: {
        model: function model() {

            return (0, _resources.KorisnikResource)().get(this.$route.params);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.ucitaniProjekti)?_c('page',[_c('v-dialog',{attrs:{"max-width":"600px"},model:{value:(_vm.dialogDodajKorisnikaNaProjekat),callback:function ($$v) {_vm.dialogDodajKorisnikaNaProjekat=$$v},expression:"dialogDodajKorisnikaNaProjekat"}},[_c('v-card-text',[_c('v-form',{ref:"form"},[_c('v-flex',[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.korisnikModel.uloge,"item-text":"vrstaUloge.uloga","item-value":"vrstaUloge.id","bottom":""},on:{"input":_vm.ucitajProjekteZaKorisnikUlogu},model:{value:(_vm.odabranaUloga),callback:function ($$v) {_vm.odabranaUloga=$$v},expression:"odabranaUloga"}})],1),_vm._v(" "),_c('v-combobox',{attrs:{"items":_vm.projekti.items,"label":"Projekti za odabranu ulogu","chips":"","clearable":"","multiple":"","item-text":"naziv","item-value":"id"},scopedSlots:_vm._u([{key:"selection",fn:function(data){return [_c('v-chip',{attrs:{"selected":data.selected,"close":""},on:{"input":function($event){return _vm.removeProjekat(data.item)}}},[_c('strong',[_vm._v(_vm._s(data.item.naziv))]),_vm._v(" \r\n                        ")])]}}],null,false,2465953849),model:{value:(_vm.ulogaProjekti),callback:function ($$v) {_vm.ulogaProjekti=$$v},expression:"ulogaProjekti"}}),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Sačuvaj")])],1)],1)],1)],1),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.VratiTitlePoId('korisnik-dodavanje'),"content":_vm.VratiContentPoId('korisnik-dodavanje')},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],1):_vm._e()}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/list-korisnici.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _lodash = require('lodash.debounce');

var _lodash2 = _interopRequireDefault(_lodash);

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _paginationMixin = require('helpers/pagination-mixin');

var _paginationMixin2 = _interopRequireDefault(_paginationMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaKorisnikaProjekta',
    mixins: [_paginationMixin2.default, _helpTipDialogMixin2.default],
    components: {
        debounce: _lodash2.default
    },

    data: function data() {
        return {
            activeHelpTip: false,
            model: {
                items: []
            },
            totalItems: 0,
            filterMenu: false,
            filtrirano: false,
            loading: false,
            headers: [{
                text: 'Korisničko ime',
                align: 'left',
                sortable: false,
                value: 'korisnickoIme'
            }, {
                text: 'Ime i prezime',
                align: 'left',
                sortable: false,
                value: 'punoIme'
            }, {
                text: 'Uloga',
                align: 'left',
                sortable: false,
                value: 'uloga'
            }, {
                text: 'Aktivan',
                align: 'left',
                sortable: false,
                value: 'onemogucen'
            }, {
                text: '',
                align: 'left',
                sortable: false,
                value: ''
            }],
            inputs: {
                filter: null,
                page: 1,
                count: 10
            },
            inputsKorisnici: {
                filter: null,
                page: 1,
                count: 30
            },
            identity: _identity2.default
        };
    },
    created: function created() {
        this.inputs = this.mergeQueryToInput(this.$route.query, this.inputs);
    },
    mounted: function mounted() {
        if (this.inputs.page) {
            this.pagination.page = this.inputs.page;
        }
        if (this.inputs.count) {
            this.pagination.count = this.inputs.count;
        }
    },


    methods: {
        filtriraj: function filtriraj() {
            if (this.inputs.filter) {
                this.filtrirano = true;
            } else {
                this.filtrirano = false;
            }
            this.filterMenu = false;
            this.resetujPaginaciju();
        },
        ponistiFilter: function ponistiFilter() {
            this.inputs.filter = "";
            this.filterMenu = false;
            this.filtrirano = false;
            this.resetujPaginaciju();
        },
        updateData: function updateData() {
            var that = this;
            this.osvjeziQuery(this.inputsKorisnici);

            this.loading = true;
            var success = function success(model) {
                that.model = model.body;
                that.totalItems = model.body.total;
                that.loading = false;
            };

            var error = function error() {
                that.$toast.error("Filtriranje nije uspješno");
            };
            var promise = (0, _resources.ProjekatResource)().vratiKorisnikeProjekta({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Korisnici ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":"","to":{ name: 'home.korisnik.dodavanje' }}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                        DODAJ\r\n                    ")],1),_vm._v(" "),_c('v-menu',{attrs:{"close-on-content-click":false,"content-class":"dropdown-menu","bottom":"","left":"","offset-y":"","transition":"slide-y-transition"},model:{value:(_vm.filterMenu),callback:function ($$v) {_vm.filterMenu=$$v},expression:"filterMenu"}},[_c('v-btn',{staticClass:"toolbar-btn",attrs:{"slot":"activator","flat":""},slot:"activator"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("filter_list")]),_vm._v("Filtriraj")],1),_vm._v(" "),_c('v-card',[_c('v-card-title',[_c('div',{staticClass:"filter-title"},[_vm._v("\r\n                                    Filtriraj po\r\n                                ")])]),_vm._v(" "),_c('v-form',{staticClass:"filter",on:{"submit":_vm.filtriraj}},[_c('v-card-text',{staticClass:"pt-0"},[_c('v-text-field',{attrs:{"label":"Ime i prezime","hide-details":""},model:{value:(_vm.inputs.filter),callback:function ($$v) {_vm.$set(_vm.inputs, "filter", $$v)},expression:"inputs.filter"}})],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary"},on:{"click":_vm.ponistiFilter}},[_vm._v("Poništi")]),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary","type":"submit"}},[_vm._v("Filtriraj")])],1)],1)],1)],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headers,"items":_vm.model.items,"pagination":_vm.pagination,"total-items":_vm.totalItems,"no-data-text":"Nema korisnika za prikaz.","loading":_vm.loading,"rows-per-page-items":_vm.rowsPerPageItems},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.korisnickoIme))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.punoIme))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.uloga))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.onemogucen ? 'Nije aktivan':'Aktivan'))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"})]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\r\n                    Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\r\n                ")]}}])})],1),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.VratiTitlePoId('korisnik-list'),"content":_vm.VratiContentPoId('korisnik-list')},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/list.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _lodash = require('lodash.debounce');

var _lodash2 = _interopRequireDefault(_lodash);

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _paginationMixin = require('helpers/pagination-mixin');

var _paginationMixin2 = _interopRequireDefault(_paginationMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaProjekata',
    mixins: [_paginationMixin2.default, _helpTipDialogMixin2.default],
    components: {
        debounce: _lodash2.default
    },
    props: ['omogucenoDodavanjeIFiltriranje'],

    data: function data() {
        return {
            childOmogucenoDodavanjeIFiltriranje: this.omogucenoDodavanjeIFiltriranje,
            activeHelpTip: false,
            model: {
                items: []
            },
            totalItems: 0,
            filterMenu: false,
            filtrirano: false,
            loading: false,
            headers: [{
                text: 'Naziv projekta',
                align: 'left',
                sortable: false,
                value: 'naziv'
            }, {
                text: 'Opis',
                align: 'left',
                sortable: false,
                value: 'opis'
            }, {
                text: '',
                align: 'left',
                sortable: false,
                value: ''
            }],
            inputs: {
                filter: null,
                page: 1,
                count: 10
            },
            identity: _identity2.default
        };
    },
    created: function created() {

        if (this.omogucenoDodavanjeIFiltriranje == null) this.childOmogucenoDodavanjeIFiltriranje = true;

        this.pagination.rowsPerPage = 10;
    },
    mounted: function mounted() {

        if (this.inputs.page) {
            this.pagination.page = this.inputs.page;
        }
        if (this.inputs.count) {
            this.pagination.count = this.inputs.count;
        }
    },


    methods: {
        filtriraj: function filtriraj() {
            if (this.inputs.filter) {
                this.filtrirano = true;
            } else {
                this.filtrirano = false;
            }
            this.filterMenu = false;
            this.resetujPaginaciju();
        },
        ponistiFilter: function ponistiFilter() {
            this.inputs.filter = "";
            this.filterMenu = false;
            this.filtrirano = false;
            this.resetujPaginaciju();
        },
        ucitajProjekte: function ucitajProjekte() {
            var _this = this;

            var that = this;
            that.loading = true;
            var success = function success(response) {
                that.model = response.body;
                that.totalItems = response.body.total;

                that.loading = false;
            };
            var error = function error() {
                _this.$toast.error('Nisu ucitani projekti.');
            };

            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(that.inputs);
            promise.then(success, error);
        },
        updateData: function updateData() {
            var that = this;
            this.osvjeziQuery(this.inputs);

            this.loading = true;
            var success = function success(model) {
                that.model = model.body;
                that.totalItems = model.body.total;
                that.loading = false;
            };

            var error = function error() {
                that.$toast.error("Filtriranje nije uspješno");
            };
            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(that.inputs);
            promise.then(success, error);
        },
        otvoriProjekat: function otvoriProjekat(id) {
            this.$router.push({
                name: 'home.projekat.pregled',
                params: {
                    projekatId: id
                }
            });
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Projekti ")])]),_vm._v(" "),(_vm.childOmogucenoDodavanjeIFiltriranje)?_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":"","to":{ name: 'home.projekat.dodavanje' }}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                        DODAJ\r\n                    ")],1)],1):_vm._e()],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headers,"items":_vm.model.items,"pagination":_vm.pagination,"total-items":_vm.totalItems,"no-data-text":"Nema projekata za prikaz.","loading":_vm.loading,"rows-per-page-items":_vm.rowsPerPageItems},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"items",fn:function(props){return [(_vm.imaPravo('projekat_projekat_pregled'))?_c('tr',{attrs:{"to":{ name: 'home.projekat.pregled', params: {projekatId: props.item.id }}},on:{"click":function($event){return _vm.otvoriProjekat(props.item.id)}}},[_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.opis))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_c('v-menu',{attrs:{"open-on-hover":"","offset-y":""}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("settings")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.projekat.pregled', params: {projekatId: props.item.id }}}},[_c('v-list-tile-title',[_vm._v("Pregled projekta")])],1)],1)],1)],1)]):_vm._e(),_vm._v(" "),(!_vm.imaPravo('projekat_projekat_pregled'))?_c('tr',[_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.opis))])]):_vm._e()]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\r\n                    Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\r\n                ")]}}])})],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _list = require('./list');

var _list2 = _interopRequireDefault(_list);

var _dodavanje = require('./dodavanje');

var _dodavanje2 = _interopRequireDefault(_dodavanje);

var _pregled = require('./pregled');

var _pregled2 = _interopRequireDefault(_pregled);

var _edit = require('./edit');

var _edit2 = _interopRequireDefault(_edit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Projekat',

    routes: [{
        path: '',
        name: 'home.projekat.list',
        component: _list2.default
    }, {
        path: 'dodavanje',
        name: 'home.projekat.dodavanje',
        component: _dodavanje2.default
    }, {
        path: 'edit/:projekatId',
        name: 'home.projekat.edit',
        component: _edit2.default
    }, {
        path: ':projekatId',
        name: 'home.projekat.pregled',
        component: _pregled2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/pregled.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _list = require('./dio-projekta/list.vue');

var _list2 = _interopRequireDefault(_list);

var _edit = require('./konfiguracija-projekta/edit.vue');

var _edit2 = _interopRequireDefault(_edit);

var _edit3 = require('./edit.vue');

var _edit4 = _interopRequireDefault(_edit3);

var _edit5 = require('./zahtjev-prioritet/edit.vue');

var _edit6 = _interopRequireDefault(_edit5);

var _edit7 = require('./zahtjev-status/edit.vue');

var _edit8 = _interopRequireDefault(_edit7);

var _edit9 = require('./zahtjev-tip/edit.vue');

var _edit10 = _interopRequireDefault(_edit9);

var _list3 = require('../zahtjev/list.vue');

var _list4 = _interopRequireDefault(_list3);

var _list5 = require('../korisnik/list.vue');

var _list6 = _interopRequireDefault(_list5);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'PregledProjekat',
    components: {
        EditProjekta: _edit4.default,
        ListDioProjekta: _list2.default,

        EditKonfiguracijeProjekta: _edit2.default,
        EditZahtjevPrioriteta: _edit6.default,

        EditZahtjevStatusa: _edit8.default,

        EditZahtjevTipova: _edit10.default,

        ListaZahtjevaProjekat: _list4.default,
        ListaKorisnika: _list6.default

    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            nazivProjekta: null,
            opisProjekta: null,
            ucitanProjekat: false,
            activeHelpTip: false,
            helpTipDialogTitle: "Pregled projekta",
            helpTipDialogContent: 'Pregled podataka o projektu.',
            resolved: null,
            identity: _identity2.default,
            tabs: 0,
            editProjekta: false,
            korisniciProjekta: [],
            ucitaniKorisniciProjekta: false,

            opcijeKonfiguracija: [{
                id: 0,
                naziv: "Konfiguracija projekta"
            }, {
                id: 1,
                naziv: "Prioriteti zahtjeva"
            }, {
                id: 2,
                naziv: "Statusi zahtjeva"
            }, {
                id: 3,
                naziv: "Tipovi zahtjeva"
            }, {
                id: 4,
                naziv: "Dijelovi projekta"
            }],
            odabranaOpcijaKonfiguracije: 0

        };
    },
    mounted: function mounted() {
        this.vratiProjekat();
    },
    created: function created() {},


    methods: {
        omoguciEditovanjeProjekta: function omoguciEditovanjeProjekta() {
            this.editProjekta = true;
        },
        onemoguciEditProjekta: function onemoguciEditProjekta() {
            this.editProjekta = false;
            this.vratiProjekat();
        },
        vratiProjekat: function vratiProjekat() {
            var that = this;

            that.ucitanProjekat = false;

            var success = function success(response) {

                that.projekatModel = response.body;
                that.ucitanProjekat = true;
            };
            var error = function error(poruka) {
                console.log("nije uspjelo");

                that.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ProjekatResource)().vratiProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.imaPravo('projekat_projekat_pregled'))?[_c('material-card',{staticClass:"card-tabs",attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-tabs',{attrs:{"color":"transparent","slider-color":"white"},model:{value:(_vm.tabs),callback:function ($$v) {_vm.tabs=$$v},expression:"tabs"}},[_c('span',{staticClass:"subheading font-weight-light mr-3",staticStyle:{"align-self":"center"}},[_vm._v("Projekat")]),_vm._v(" "),_c('v-tab',{staticClass:"mr-3"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("subject")]),_vm._v("\r\n                        Pregled\r\n                    ")],1),_vm._v(" "),_c('v-tab',{staticClass:"mr-3"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("people")]),_vm._v("\r\n                        Korisnici\r\n                    ")],1),_vm._v(" "),_c('v-tab',[_c('v-icon',{staticClass:"mr-2"},[_vm._v("settings_applications")]),_vm._v("\r\n                        Konfiguracija\r\n                    ")],1)],1)],1),_vm._v(" "),_c('v-tabs-items',{staticClass:"tabovi",model:{value:(_vm.tabs),callback:function ($$v) {_vm.tabs=$$v},expression:"tabs"}},[_c('v-tab-item',[(_vm.ucitanProjekat && _vm.editProjekta==false)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":_vm.omoguciEditovanjeProjekta}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("edit")]),_vm._v("\r\n                                Edit\r\n                            ")],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Pregled projekta ")])])],1)],1),_vm._v(" "),_c('v-card-text',[_c('table',{staticClass:"v-table"},[_c('tbody',[_c('tr',[_c('td',[_vm._v("Naziv projekta: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.projekatModel.naziv))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Opis: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.projekatModel.opis))])])])])])]:_vm._e(),_vm._v(" "),(_vm.editProjekta)?_c('edit-projekta',{on:{"onemogucenEdit":_vm.onemoguciEditProjekta}}):_vm._e()],2),_vm._v(" "),_c('v-tab-item',[_c('lista-korisnika',{attrs:{"projekat-id":_vm.$route.params.projekatId,"omogucen-header":false}})],1),_vm._v(" "),_c('v-tab-item',[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.opcijeKonfiguracija,"item-text":"naziv","item-value":"id","label":"Opcije","bottom":""},model:{value:(_vm.odabranaOpcijaKonfiguracije),callback:function ($$v) {_vm.odabranaOpcijaKonfiguracije=$$v},expression:"odabranaOpcijaKonfiguracije"}}),_vm._v(" "),(_vm.odabranaOpcijaKonfiguracije==0)?_c('edit-konfiguracije-projekta'):_vm._e(),_vm._v(" "),(_vm.odabranaOpcijaKonfiguracije==1)?_c('edit-zahtjev-prioriteta'):_vm._e(),_vm._v(" "),(_vm.odabranaOpcijaKonfiguracije==2)?_c('edit-zahtjev-statusa'):_vm._e(),_vm._v(" "),(_vm.odabranaOpcijaKonfiguracije==3)?_c('edit-zahtjev-tipova'):_vm._e(),_vm._v(" "),(_vm.odabranaOpcijaKonfiguracije==4)?_c('list-dio-projekta'):_vm._e()],1)],1)],1)]:_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.helpTipDialogTitle,"content":_vm.helpTipDialogContent},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/zahtjev-kategorija/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditZahtjevKategorija",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            defaultnaKategorija: null,
            zahtjevKategorije: {},
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,

            boje: ["secondary", "secondary", "cyan", "teal", "secondary-grey", "green"],
            valid: false,
            model: {},
            projekatModel: {},

            rules: {
                punoIme: [function (v) {
                    return !!v || "Morate da unesete ime i prezime";
                }, function (v) {
                    return v && v.length <= 128 || "Ime i prezime mora biti manje od 128 karaktera";
                }]
            },

            headersPrioriteti: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }],
            ucitaneZahtjevKategorije: false,
            dialogPrioritetiZahtjeva: false

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajZahtjevPrioritete();
    },
    created: function created() {},

    methods: {
        ucitajKategorijeZahtjeva: function ucitajKategorijeZahtjeva() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.dijeloviProjektaModel = response.body;
                that.ucitaniDijeloviProjekta = true;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        dodajZahtjevKategoriju: function dodajZahtjevKategoriju() {
            var _this2 = this;

            var that = this;

            var success = function success() {
                _this2.$toast.success("Uspješno dodano.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                that.dialogZahtjevKategorija = false;
                _this2.ucitajKategorijeZahtjeva();
            };
            var error = function error() {
                _this2.$toast.error('Promjena podataka nije uspjela.');
            };

            var promise = (0, _resources.ProjekatResource)().dodajNovuZahtjevKategoriju(that.$route.params, this.dioProjektaModel);
            promise.then(success, error);
        },
        odrediDefaultnuKategoriju: function odrediDefaultnuKategoriju() {

            for (var i = 0; i < this.zahtjevKategorije.length; i++) {

                if (this.zahtjevKategorije[i].default == true) {
                    this.defaultniPrioritet = this.zahtjevKategorije[i];
                    break;
                }
            }
        },
        azurirajDefaultnuZahtjevKategorijuDijelaProjekta: function azurirajDefaultnuZahtjevKategorijuDijelaProjekta() {
            var _this3 = this;

            var that = this;

            var success = function success() {
                _this3.$toast.success("Uspješno promijenjeno.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                _this3.ucitajKategorijeZahtjeva();
            };
            var error = function error() {};
            var promise = (0, _resources.ProjekatResource)().azurirajDefaultnuZahtjevKategorijuDijelaProjekta(that.$route.params, { Id: this.defaultniPrioritet });
            promise.then(success, error);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaneZahtjevKategorije)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogPrioritetiZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                            DODAJ\r\n                        ")],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Prioriteti zahtjeva ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogPrioritetiZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                            DODAJ\r\n                        ")],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headersPrioriteti,"items":_vm.zahtjevKategorije,"no-data-text":"Nema kategorija zahtjeva."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"})]}}],null,false,3285086135)})],1),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.zahtjevKategorije,"item-text":"naziv","item-value":"id","label":"Defaultni prioritet","bottom":""},model:{value:(_vm.defaultniPrioritet),callback:function ($$v) {_vm.defaultniPrioritet=$$v},expression:"defaultniPrioritet"}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.azurirajDefaultniZahtjevPrioritetProjekta()}}},[_vm._v("Snimi")])]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogDodajKategoriju),callback:function ($$v) {_vm.dialogDodajKategoriju=$$v},expression:"dialogDodajKategoriju"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje nove kategorije zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"label":"Naziv","required":""},model:{value:(_vm.zahtjevPrioritetModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevPrioritetModel, "naziv", $$v)},expression:"zahtjevPrioritetModel.naziv"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogDodajKategoriju = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajZahtjevKategoriju()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/zahtjev-prioritet/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditZahtjevPrioriteta",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            defaultniPrioritet: null,
            zahtjevPrioritetModel: {},
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,

            valid: false,
            model: {},
            projekatModel: {},

            rules: {
                nazivPrioriteta: [function (v) {
                    return !!v || "Morate da unesete naziv";
                }, function (v) {
                    return v && v.length <= 20 || "Naziv ne može biti veći od 20 karaktera.";
                }]
            },

            headersPrioriteti: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }, {
                text: "Poredak",
                align: 'left',
                sortable: false
            }],
            zahtjevPrioriteti: null,
            ucitaniZahtjevPrioriteti: false,
            dialogPrioritetiZahtjeva: false

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajZahtjevPrioritete();
    },
    created: function created() {},

    methods: {
        ucitajZahtjevPrioritete: function ucitajZahtjevPrioritete() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.zahtjevPrioriteti = response.body;
                that.ucitaniZahtjevPrioriteti = true;
                _this.odrediDefaultniPrioritet();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevPrioriteteZaProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        dodajNoviPrioritetZahtjeva: function dodajNoviPrioritetZahtjeva() {
            var _this2 = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (!this.valid) return;else {
                var that = this;

                var success = function success() {
                    _this2.$toast.success("Uspješno dodano.");
                    that.$router.push({
                        name: 'home.projekat.pregled'
                    });
                    that.dialogPrioritetiZahtjeva = false;
                    _this2.ucitajZahtjevPrioritete();
                };
                var error = function error() {};

                var promise = (0, _resources.ProjekatResource)().dodajNoviPrioritetZahtjevaZaProjekat(that.$route.params, this.zahtjevPrioritetModel);
                promise.then(success, error);
            }
        },
        odrediDefaultniPrioritet: function odrediDefaultniPrioritet() {

            for (var i = 0; i < this.zahtjevPrioriteti.length; i++) {

                if (this.zahtjevPrioriteti[i].default == true) {
                    this.defaultniPrioritet = this.zahtjevPrioriteti[i];
                    break;
                }
            }
        },
        azurirajDefaultniZahtjevPrioritetProjekta: function azurirajDefaultniZahtjevPrioritetProjekta() {
            var _this3 = this;

            var that = this;

            var success = function success() {
                _this3.$toast.success("Uspješno promijenjeno.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                _this3.ucitajZahtjevPrioritete();
            };
            var error = function error() {};
            var promise = (0, _resources.ProjekatResource)().azurirajDefaultniZahtjevPrioritetProjekta(that.$route.params, {
                Id: this.defaultniPrioritet
            });
            promise.then(success, error);
        },
        otvoriDialogPrioritetiZahtjeva: function otvoriDialogPrioritetiZahtjeva() {

            this.dialogPrioritetiZahtjeva = true;
            this.zahtjevPrioritetModel = {};

            this.zahtjevPrioritetModel.poredak = this.zahtjevPrioriteti.length;
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaniZahtjevPrioriteti)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){return _vm.otvoriDialogPrioritetiZahtjeva()}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                DODAJ\r\n            ")],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"hide-actions":true,"headers":_vm.headersPrioriteti,"items":_vm.zahtjevPrioriteti,"no-data-text":"Nema prioriteta zahtjeva."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.poredak))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"})]}}],null,false,921211968)})],1),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.zahtjevPrioriteti,"item-text":"naziv","item-value":"id","label":"Defaultni prioritet","bottom":""},model:{value:(_vm.defaultniPrioritet),callback:function ($$v) {_vm.defaultniPrioritet=$$v},expression:"defaultniPrioritet"}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.azurirajDefaultniZahtjevPrioritetProjekta()}}},[_vm._v("Snimi")])]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogPrioritetiZahtjeva),callback:function ($$v) {_vm.dialogPrioritetiZahtjeva=$$v},expression:"dialogPrioritetiZahtjeva"}},[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje nove vrste prioriteta zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"rules":_vm.rules.nazivPrioriteta,"required":"","label":"Naziv"},model:{value:(_vm.zahtjevPrioritetModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevPrioritetModel, "naziv", $$v)},expression:"zahtjevPrioritetModel.naziv"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.zahtjevPrioriteti,"item-text":"naziv","item-value":"poredak","label":"Prioritet iznad kojeg je novi zahtjev","bottom":""},model:{value:(_vm.zahtjevPrioritetModel.poredak),callback:function ($$v) {_vm.$set(_vm.zahtjevPrioritetModel, "poredak", $$v)},expression:"zahtjevPrioritetModel.poredak"}}),_vm._v(" "),_c('small',[_vm._v("*Najmanji prioritet će imati, ako je ovo polje prazno")])],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogPrioritetiZahtjeva = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviPrioritetZahtjeva()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/zahtjev-prioritet/pregled.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "PregledZahtjevPrioriteta",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            defaultniPrioritet: null,
            zahtjevPrioritetModel: {},
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,

            valid: false,
            model: {},
            projekatModel: {},

            rules: {
                punoIme: [function (v) {
                    return !!v || "Morate da unesete ime i prezime";
                }, function (v) {
                    return v && v.length <= 128 || "Ime i prezime mora biti manje od 128 karaktera";
                }]
            },

            headersPrioriteti: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }, {
                text: "Poredak",
                align: 'left',
                sortable: false
            }],
            zahtjevPrioriteti: null,
            ucitaniZahtjevPrioriteti: false,
            dialogPrioritetiZahtjeva: false

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajZahtjevPrioritete();
    },
    created: function created() {},

    methods: {
        ucitajZahtjevPrioritete: function ucitajZahtjevPrioritete() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.zahtjevPrioriteti = response.body;
                that.ucitaniZahtjevPrioriteti = true;
                _this.odrediDefaultniPrioritet();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevPrioriteteZaProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        odrediDefaultniPrioritet: function odrediDefaultniPrioritet() {

            for (var i = 0; i < this.zahtjevPrioriteti.length; i++) {

                if (this.zahtjevPrioriteti[i].default == true) {
                    this.defaultniPrioritet = this.zahtjevPrioriteti[i];
                    break;
                }
            }
        },
        dodajNoviPrioritetZahtjeva: function dodajNoviPrioritetZahtjeva() {
            var _this2 = this;

            var that = this;

            var success = function success() {
                _this2.$toast.success("Uspješno dodano.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                that.dialogPrioritetiZahtjeva = false;
                _this2.ucitajZahtjevPrioritete();
            };
            var error = function error() {};

            var promise = (0, _resources.ProjekatResource)().dodajNoviPrioritetZahtjevaZaProjekat(that.$route.params, this.zahtjevPrioritetModel);
            promise.then(success, error);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaniZahtjevPrioriteti)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){return _vm.otvoriDialogPrioritetiZahtjeva()}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                DODAJ\r\n            ")],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headersPrioriteti,"items":_vm.zahtjevPrioriteti,"no-data-text":"Nema prioriteta zahtjeva."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.poredak))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"})]}}],null,false,921211968)})],1),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","disabled":true,"items":_vm.zahtjevPrioriteti,"item-text":"naziv","item-value":"id","label":"Defaultni prioritet","bottom":""},model:{value:(_vm.defaultniPrioritet),callback:function ($$v) {_vm.defaultniPrioritet=$$v},expression:"defaultniPrioritet"}})]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogPrioritetiZahtjeva),callback:function ($$v) {_vm.dialogPrioritetiZahtjeva=$$v},expression:"dialogPrioritetiZahtjeva"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje nove vrste prioriteta zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"label":"Naziv","required":""},model:{value:(_vm.zahtjevPrioritetModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevPrioritetModel, "naziv", $$v)},expression:"zahtjevPrioritetModel.naziv"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"label":"Poredak","required":""},model:{value:(_vm.zahtjevPrioritetModel.poredak),callback:function ($$v) {_vm.$set(_vm.zahtjevPrioritetModel, "poredak", $$v)},expression:"zahtjevPrioritetModel.poredak"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogPrioritetiZahtjeva = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviPrioritetZahtjeva()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/zahtjev-status/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditZahtjevStatusa",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            defaultniStatus: null,

            odabranaOznakaStatusa: null,
            oznakeStatusa: [{
                id: 0,
                naziv: 'Potrebno uraditi'
            }, {
                id: 1,
                naziv: 'Radi se'
            }, {
                id: 2,
                naziv: 'Završeno'
            }],
            zahtjevStatusModel: {},
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,

            poredakZahtjevaId: [],
            valid: false,
            model: {},
            projekatModel: {},

            rules: {
                nazivStatusZahtjeva: [function (v) {
                    return !!v || "Morate da unesete naziv";
                }, function (v) {
                    return v && v.length <= 20 || "Naziv ne može biti veći 20 karaktera";
                }],
                oznakaStatusa: [function (v) {
                    return v != null || "Morate da unesete oznaku";
                }]
            },

            headersStatusi: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }, {
                text: "Oznaka",
                align: 'left',
                sortable: false
            }],

            zahtjevStatusi: null,
            ucitaniZahtjevStatusi: false,
            dialogStatusiZahtjeva: false

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajZahtjevStatuse();
    },
    created: function created() {},

    methods: {
        ucitajZahtjevStatuse: function ucitajZahtjevStatuse() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.zahtjevStatusi = response.body;
                console.log(that.zahtjevStatusi);
                that.ucitaniZahtjevStatusi = true;
                _this.odrediDefaultniStatus();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiStatuseZahtjevaZaProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        dodajNoviStatusZahtjeva: function dodajNoviStatusZahtjeva() {
            var _this2 = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (!this.valid) return;else {

                var that = this;

                var success = function success() {
                    _this2.$toast.success("Uspješno dodano.");
                    that.$router.push({
                        name: 'home.projekat.pregled'
                    });
                    that.dialogStatusiZahtjeva = false;
                    _this2.ucitajZahtjevStatuse();
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };

                var promise = (0, _resources.ProjekatResource)().dodajNoviStatusZahtjevaZaProjekat(that.$route.params, this.zahtjevStatusModel);
                promise.then(success, error);
            }
        },
        odrediDefaultniStatus: function odrediDefaultniStatus() {

            for (var i = 0; i < this.zahtjevStatusi.length; i++) {

                if (this.zahtjevStatusi[i].default == true) {
                    this.defaultniStatus = this.zahtjevStatusi[i];
                    break;
                }
            }
        },
        azurirajDefaultniZahtjevStatusProjekta: function azurirajDefaultniZahtjevStatusProjekta() {
            var _this3 = this;

            var that = this;

            var success = function success() {
                _this3.$toast.success("Uspješno promijenjeno.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                _this3.ucitajZahtjevStatuse();
            };
            var error = function error() {};
            var promise = (0, _resources.ProjekatResource)().azurirajDefaultniZahtjevStatusProjekta(that.$route.params, {
                Id: this.defaultniStatus
            });
            promise.then(success, error);
        },
        azurirajPoredakZahtjevStatusa: function azurirajPoredakZahtjevStatusa() {
            var _this4 = this;

            var that = this;
            console.log("statusi", that.zahtjevStatusi);
            var success = function success() {
                _this4.$toast.success("Uspješno promijenjeno.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                that.poredakZahtjevaId = [];
            };
            var error = function error() {};

            that.zahtjevStatusi.forEach(function (element) {
                that.poredakZahtjevaId.push(element.id);
            });
            var promise = (0, _resources.ProjekatResource)().azurirajPoredakStatusa(that.$route.params, {
                zahtjeviId: that.poredakZahtjevaId
            });
            promise.then(success, error);
        },
        dodajNazivOznakeStatusa: function dodajNazivOznakeStatusa() {
            for (var i = 0; i < this.zahtjevStatusi.length; i++) {
                if (this.zahtjevStatusi[i].oznaka == 0) {
                    this.zahtjevStatusi[i].naziv += "  (Oznaka statusa: Potrebno uraditi)";
                } else if (this.zahtjevStatusi[i].oznaka == 1) {
                    this.zahtjevStatusi[i].naziv += "  (Oznaka statusa: Radi se)";
                } else if (this.zahtjevStatusi[i].oznaka == 2) {
                    this.zahtjevStatusi[i].naziv += "  (Oznaka statusa: Završeno)";
                }
            }
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaniZahtjevStatusi)?[_c('v-flex',{staticClass:"text-xs-left toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogStatusiZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                DODAJ\r\n            ")],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Statusi zahtjeva ")])])],1)],1),_vm._v(" "),_c('br'),_vm._v(" "),_c('v-flex',[_vm._v("Poredak statusa zahtjeva: ")]),_vm._v(" "),_c('br'),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","md4":"","lg4":"","justify-right":""}},[(_vm.ucitaniZahtjevStatusi)?_c('draggable',{staticClass:"dragArea",attrs:{"ghost-class":"ghost","list":_vm.zahtjevStatusi}},_vm._l((_vm.zahtjevStatusi),function(element){return _c('v-card-text',{key:element.id,staticStyle:{"border":"1px solid grey"}},[(element.oznaka=='0')?_c('span',[_vm._v(_vm._s(element.naziv)+" (Oznaka statusa: "),_c('span',{staticClass:"status-to-do"},[_vm._v("Potrebno uraditi")]),_vm._v(")")]):_vm._e(),_vm._v(" "),(element.oznaka=='1')?_c('span',[_vm._v(" "+_vm._s(element.naziv)+" (Oznaka statusa: "),_c('span',{staticClass:"status-in-progress"},[_vm._v("Radi se")]),_vm._v(")")]):_vm._e(),_vm._v(" "),(element.oznaka=='2')?_c('span',[_vm._v(" "+_vm._s(element.naziv)+" (Oznaka statusa: "),_c('span',{staticClass:"status-done"},[_vm._v("Završeno")]),_vm._v(")")]):_vm._e()])}),1):_vm._e()],1),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.azurirajPoredakZahtjevStatusa()}}},[_vm._v("Snimi poredak")]),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.zahtjevStatusi,"item-text":"naziv","item-value":"id","label":"Defaultni status","bottom":""},model:{value:(_vm.defaultniStatus),callback:function ($$v) {_vm.defaultniStatus=$$v},expression:"defaultniStatus"}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.azurirajDefaultniZahtjevStatusProjekta()}}},[_vm._v("Snimi")])]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogStatusiZahtjeva),callback:function ($$v) {_vm.dialogStatusiZahtjeva=$$v},expression:"dialogStatusiZahtjeva"}},[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje nove vrste statusa zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"rules":_vm.rules.nazivStatusZahtjeva,"label":"Novi status zahtjeva","required":""},model:{value:(_vm.zahtjevStatusModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevStatusModel, "naziv", $$v)},expression:"zahtjevStatusModel.naziv"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-select',{staticClass:"required",attrs:{"rules":_vm.rules.oznakaStatusa,"required":"","items":_vm.oznakeStatusa,"item-text":"naziv","item-value":"id","label":"Oznaka statusa","bottom":""},model:{value:(_vm.zahtjevStatusModel.oznaka),callback:function ($$v) {_vm.$set(_vm.zahtjevStatusModel, "oznaka", $$v)},expression:"zahtjevStatusModel.oznaka"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogStatusiZahtjeva = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviStatusZahtjeva()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/zahtjev-status/pregled.vue", function(exports, require, module) {
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)

});

;require.register("modules/home/projekat/zahtjev-tip/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "EditZahtjevTipova",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            defaultniTip: null,
            zahtjevTipModel: {},

            headersTipovi: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }],
            zahtjevTipovi: null,
            ucitaniZahtjevTipovi: false,
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,

            valid: false,
            model: {},
            projekatModel: {},

            rules: {
                naziv: [function (v) {
                    return !!v || "Morate da unesete naziv";
                }, function (v) {
                    return v && v.length <= 20 || "Naziv ne može biti veći 20 karaktera";
                }]
            },
            dialogTipoviZahtjeva: false

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajZahtjevTipove();
    },
    created: function created() {},

    methods: {
        ucitajZahtjevTipove: function ucitajZahtjevTipove() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.zahtjevTipovi = response.body;
                that.ucitaniZahtjevTipovi = true;
                _this.odrediDefaultniTip();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiTipoveZahtjevaZaProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        dodajNoviTipZahtjeva: function dodajNoviTipZahtjeva() {
            var _this2 = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (!this.valid) return;else {
                var that = this;

                var success = function success() {
                    _this2.$toast.success("Uspješno dodano.");
                    that.$router.push({
                        name: 'home.projekat.pregled'
                    });
                    that.dialogTipoviZahtjeva = false;
                    _this2.ucitajZahtjevTipove();
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };

                var promise = (0, _resources.ProjekatResource)().dodajNoviTipZahtjevaZaProjekat(that.$route.params, this.zahtjevTipModel);
                promise.then(success, error);
            }
        },
        odrediDefaultniTip: function odrediDefaultniTip() {

            for (var i = 0; i < this.zahtjevTipovi.length; i++) {

                if (this.zahtjevTipovi[i].default == true) {
                    this.defaultniTip = this.zahtjevTipovi[i];
                    break;
                }
            }
        },
        azurirajDefaultniZahtjevTipProjekta: function azurirajDefaultniZahtjevTipProjekta() {
            var _this3 = this;

            var that = this;

            var success = function success() {
                _this3.$toast.success("Uspješno promijenjeno.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                _this3.ucitajZahtjevTipove();
            };
            var error = function error() {};
            var promise = (0, _resources.ProjekatResource)().azurirajDefaultniZahtjevTipProjekta(that.$route.params, {
                Id: this.defaultniTip
            });
            promise.then(success, error);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaniZahtjevTipovi)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogTipoviZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                DODAJ\r\n            ")],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Tipovi zahtjeva ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogTipoviZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                        DODAJ\r\n                    ")],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"hide-actions":true,"headers":_vm.headersTipovi,"items":_vm.zahtjevTipovi,"no-data-text":"Nema tipova zahtjeva."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"})]}}],null,false,3285086135)})],1),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.zahtjevTipovi,"item-text":"naziv","item-value":"id","label":"Defaultni tip","bottom":""},model:{value:(_vm.defaultniTip),callback:function ($$v) {_vm.defaultniTip=$$v},expression:"defaultniTip"}}),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":function($event){return _vm.azurirajDefaultniZahtjevTipProjekta()}}},[_vm._v("Snimi")])]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogTipoviZahtjeva),callback:function ($$v) {_vm.dialogTipoviZahtjeva=$$v},expression:"dialogTipoviZahtjeva"}},[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje novog tipa zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"rules":_vm.rules.naziv,"label":"Naziv","required":""},model:{value:(_vm.zahtjevTipModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevTipModel, "naziv", $$v)},expression:"zahtjevTipModel.naziv"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogTipoviZahtjeva = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviTipZahtjeva()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/projekat/zahtjev-tip/pregled.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "PregledZahtjevTipova",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            defaultniTip: null,
            zahtjevTipModel: {},

            headersTipovi: [{
                text: "Naziv",
                align: 'left',
                sortable: false
            }],
            zahtjevTipovi: null,
            ucitaniZahtjevTipovi: false,
            activeHelpTip: false,
            activeUpozorenje: false,
            resolved: null,
            identity: _identity2.default,

            boje: ["secondary", "secondary", "cyan", "teal", "secondary-grey", "green"],
            valid: false,
            model: {},
            projekatModel: {},

            rules: {
                punoIme: [function (v) {
                    return !!v || "Morate da unesete ime i prezime";
                }, function (v) {
                    return v && v.length <= 128 || "Ime i prezime mora biti manje od 128 karaktera";
                }]
            },
            dialogTipoviZahtjeva: false

        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    mounted: function mounted() {
        this.ucitajZahtjevTipove();
    },
    created: function created() {},

    methods: {
        ucitajZahtjevTipove: function ucitajZahtjevTipove() {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.zahtjevTipovi = response.body;
                that.ucitaniZahtjevTipovi = true;
                _this.odrediDefaultniTip();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiTipoveZahtjevaZaProjekat({
                projekatId: this.$route.params.projekatId
            });

            promise.then(success, error);
        },
        odrediDefaultniTip: function odrediDefaultniTip() {

            for (var i = 0; i < this.zahtjevTipovi.length; i++) {

                if (this.zahtjevTipovi[i].default == true) {
                    this.defaultniTip = this.zahtjevTipovi[i];
                    break;
                }
            }
        },
        dodajNoviTipZahtjeva: function dodajNoviTipZahtjeva() {
            var _this2 = this;

            var that = this;

            var success = function success() {
                _this2.$toast.success("Uspješno dodano.");
                that.$router.push({
                    name: 'home.projekat.pregled'
                });
                that.dialogTipoviZahtjeva = false;
                _this2.ucitajZahtjevTipove();
            };
            var error = function error() {};

            var promise = (0, _resources.ProjekatResource)().dodajNoviTipZahtjevaZaProjekat(that.$route.params, this.zahtjevTipModel);
            promise.then(success, error);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaniZahtjevTipovi)?[_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogTipoviZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                            DODAJ\r\n                        ")],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Tipovi zahtjeva ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{on:{"click":function($event){_vm.dialogTipoviZahtjeva=true}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                            DODAJ\r\n                        ")],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headersTipovi,"items":_vm.zahtjevTipovi,"no-data-text":"Nema tipova zahtjeva."},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"})]}}],null,false,3285086135)})],1),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"required":"","disabled":true,"items":_vm.zahtjevTipovi,"item-text":"naziv","item-value":"id","label":"Defaultni tip","bottom":""},model:{value:(_vm.defaultniTip),callback:function ($$v) {_vm.defaultniTip=$$v},expression:"defaultniTip"}})]:_vm._e(),_vm._v(" "),[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"persistent":"","max-width":"600px"},model:{value:(_vm.dialogTipoviZahtjeva),callback:function ($$v) {_vm.dialogTipoviZahtjeva=$$v},expression:"dialogTipoviZahtjeva"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje novog tipa zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-text-field',{attrs:{"label":"Naziv","required":""},model:{value:(_vm.zahtjevTipModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevTipModel, "naziv", $$v)},expression:"zahtjevTipModel.naziv"}})],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){_vm.dialogTipoviZahtjeva = false}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviTipZahtjeva()}}},[_vm._v("Sačuvaj")])],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/racun/licni-detalji.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _resources = require('api/resources');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'LicniDetalji',

    data: function data() {
        return {
            identity: _identity2.default,
            resolved: null,
            valid: false,
            rules: {
                obavezno: [function (v) {
                    return !!v || 'Polje je obavezno';
                }],
                email: [function (v) {
                    return !!v || 'Polje je obavezno';
                }, function (v) {
                    return !!v || /\S+@\S+\.\S+/.test(v) || 'E-mail nije ispravan';
                }]
            }
        };
    },


    methods: {
        onSubmit: function onSubmit() {
            var _this = this;

            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (this.valid) {
                var that = this;

                var success = function success() {
                    if (_identity2.default.korisnickoIme() === that.$route.params.korisnickoIme) _identity2.default.getToken().vlasnik.punoIme = that.resolved.korisnik.punoIme;
                    _this.$toast.success("Uspješno ažurirani lični detalji.");
                    that.$router.push({
                        name: 'home.dashboard'
                    });
                };
                var error = function error() {
                    that.$toast.error('Promjena podataka nije uspjela.');
                };

                var promise = (0, _resources.KorisnikResource)().azurirajLicneDetalje(that.$route.params, that.resolved.korisnik);

                promise.then(success, error);
            }
        }
    },
    resolve: {
        korisnik: function korisnik() {
            return (0, _resources.KorisnikResource)().get(this.$route.params);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?_c('material-card',{attrs:{"title":"Lični podaci","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",attrs:{"lazy-validation":true},model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"label":"Puno ime","rules":_vm.rules.obavezno,"counter":128,"required":""},model:{value:(_vm.resolved.korisnik.punoIme),callback:function ($$v) {_vm.$set(_vm.resolved.korisnik, "punoIme", $$v)},expression:"resolved.korisnik.punoIme"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"label":"E-mail","rules":_vm.rules.email,"counter":256,"required":""},model:{value:(_vm.resolved.korisnik.email),callback:function ($$v) {_vm.$set(_vm.resolved.korisnik, "email", $$v)},expression:"resolved.korisnik.email"}}),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Spasi")])],1)],1)],1)],1):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/racun/lozinka.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _page = require('../components/page');

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Lozinka',

    data: function data() {
        return {
            lozinka: '',
            novaLozinka: '',
            ponovljenaLozinka: '',
            valid: false,
            rules: {
                obavezno: [function (v) {
                    return !!v || 'Polje je obavezno';
                }],
                lozinka: [function (v) {
                    return !!v || 'Polje je obavezno';
                }, function (v) {
                    return !!v && /^.{6,}$/.test(v) || 'Lozinka mora imati najmanje 6 karaktera';
                }]
            }
        };
    },


    components: {
        Page: _page2.default
    },

    methods: {
        onSubmit: function onSubmit() {
            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (this.valid) {
                var that = this;

                if (that.novaLozinka !== that.ponovljenaLozinka) {
                    that.$toast.error("Lozinka i ponovljena lozinka se ne poklapaju");
                    return;
                }

                var success = function success() {
                    that.$toast.success('Lozinka promijenjena.');
                    that.$router.push({
                        name: 'home.dashboard'
                    });
                };
                var error = function error() {
                    that.$toast.error('Promjena lozinke nije uspjela. Provjerite unesene podatke.');
                };

                var promise = (0, _resources.KorisnikResource)().promijeniLozinku(that.$route.params, {
                    lozinka: that.lozinka,
                    novaLozinka: that.novaLozinka
                });

                promise.then(success, error);
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"title":"Promjena lozinke","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",attrs:{"lazy-validation":true},model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"label":"Trenutna lozinka","type":"password","rules":_vm.rules.obavezno,"required":""},model:{value:(_vm.lozinka),callback:function ($$v) {_vm.lozinka=$$v},expression:"lozinka"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"label":"Nova lozinka","type":"password","rules":_vm.rules.lozinka,"required":""},model:{value:(_vm.novaLozinka),callback:function ($$v) {_vm.novaLozinka=$$v},expression:"novaLozinka"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"label":"Nova ponovljena lozinka","type":"password","rules":_vm.rules.lozinka,"required":""},model:{value:(_vm.ponovljenaLozinka),callback:function ($$v) {_vm.ponovljenaLozinka=$$v},expression:"ponovljenaLozinka"}}),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Promijeni")])],1)],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/racun/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _licniDetalji = require('./licni-detalji');

var _licniDetalji2 = _interopRequireDefault(_licniDetalji);

var _lozinka = require('./lozinka');

var _lozinka2 = _interopRequireDefault(_lozinka);

var _sesije = require('./sesije');

var _sesije2 = _interopRequireDefault(_sesije);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Racun',

    routes: [{
        path: 'licni-detalji',
        name: 'home.racun.licni-detalji',
        component: _licniDetalji2.default
    }, {
        path: 'lozinka',
        name: 'home.racun.lozinka',
        component: _lozinka2.default
    }, {
        path: 'sesije',
        name: 'home.racun.sesije',
        component: _sesije2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/racun/sesije.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _resources = require('api/resources');

var _page = require('../components/page');

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Sesije',

    data: function data() {
        return {
            model: {
                items: []
            },
            pagination: {
                page: 1,
                rowsPerPage: 30
            },
            totalItems: 0,
            rowsPerPageItems: [10, 20, 30, 50],
            fields: [{
                text: 'Vrijeme prijave',
                align: 'left',
                sortable: false,
                value: 'datumKreiranja'
            }, {
                text: 'Vrijeme zadnje akcije',
                align: 'left',
                sortable: false,
                value: 'datumPosljednjeAkcije'
            }, {
                text: 'Poslijednja IP adresa',
                align: 'left',
                sortable: false,
                value: 'posljednjiIp'
            }, {
                text: 'Poslijednji klijent',
                align: 'left',
                sortable: false,
                value: 'posljednjiKlijent'
            }, {
                text: 'Akcije',
                align: 'center',
                sortable: false,
                value: 'akcije'
            }],

            inputs: {
                korisnickoIme: this.$route.params.korisnickoIme,
                page: 1,
                count: 30
            }
        };
    },


    methods: {
        endSession: function endSession(token) {
            var that = this;

            var success = function success() {
                var items = that.model.items;
                var index = items.indexOf(token);
                items.splice(index, 1);
            };
            var error = function error() {
                that.$toast.error('Prekidanje izabrane sesije nije uspjelo.');
            };

            var tokenResource = new _resources.TokenResource();
            var promise = tokenResource.remove({
                korisnickoIme: that.$route.params.korisnickoIme,
                tokenId: token.id
            });

            promise.then(success, error);
        },
        updateData: function updateData() {
            var that = this;

            var success = function success(model) {
                that.model.items = model.body.items;
                that.totalItems = model.body.total;
            };
            var a = this.inputs;
            console.log(a);
            (0, _resources.TokenResource)().get(this.inputs).then(success);
        },
        geoUrl: function geoUrl(ip) {
            return 'http://ip-api.com/#' + ip;
        },
        isCurrent: function isCurrent(token) {
            return _identity2.default.id() === token.id;
        }
    },

    watch: {
        pagination: {
            handler: function handler(value) {
                this.inputs.page = value.page;
                this.inputs.count = value.rowsPerPage;
                this.updateData();
            },

            deep: true
        }
    },

    components: {
        Page: _page2.default
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"title":"Pregled prijava u sistem","color":"primary"}},[_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.fields,"items":_vm.model.items,"pagination":_vm.pagination,"total-items":_vm.totalItems,"rows-per-page-items":_vm.rowsPerPageItems},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('td',[_c('date-format',{attrs:{"vrijednost":props.item.datumKreiranja}})],1),_vm._v(" "),_c('td',[_c('date-format',{attrs:{"vrijednost":props.item.datumPosljednjeAkcije}})],1),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.posljednjiIp))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.posljednjiKlijent))]),_vm._v(" "),_c('td',{staticClass:"text-xs-center"},[(_vm.isCurrent(props.item))?_c('span',[_vm._v("\r\n                    Trenutna sesija "),_c('v-icon',[_vm._v("warning")])],1):_c('v-btn',{staticClass:"ma-0",attrs:{"error":""},on:{"click":function($event){return _vm.endSession(props.item)}}},[_vm._v("\r\n                            Prekini sesiju\r\n                        ")])],1)]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\r\n                    Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\r\n                ")]}}])})],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/sidebar.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _eventBus = require("../event-bus");

var _eventBus2 = _interopRequireDefault(_eventBus);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "Sidebar",

    props: ["toggleState"],

    data: function data() {
        return {
            color: 'primary',
            image: 'https://demos.creative-tim.com/vue-material-dashboard/img/sidebar-2.32103624.jpg',
            sidebarBackgroundColor: 'rgba(27, 27, 27, 0.54)',
            logo: './vuetifylogo.png',
            responsive: false,
            identity: _identity2.default,
            showNav: true,
            aktivanKonkursniRok: false,
            router: this.$router
        };
    },

    computed: {
        inputValue: {
            get: function get() {
                return this.$store.getters['home/drawer'];
            },
            set: function set(val) {
                this.$store.commit('home/setDrawer', val);
            }
        }
    },

    methods: {
        sidebarOverlayGradiant: function sidebarOverlayGradiant() {
            return this.sidebarBackgroundColor + ", " + this.sidebarBackgroundColor;
        },
        signOut: function signOut() {
            this.$emit("sign-out");
        },
        handleClick: function handleClick(e) {
            console.log("CLICK", e);
            e.preventDefault();
            e.target.parentElement.classList.toggle("open");
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-navigation-drawer',{attrs:{"id":"app-drawer","app":"","dark":"","floating":"","persistent":"","mobile-break-point":"991","width":"260"},model:{value:(_vm.inputValue),callback:function ($$v) {_vm.inputValue=$$v},expression:"inputValue"}},[_c('v-img',{attrs:{"src":_vm.image,"gradient":"rgba(27, 27, 27, 0.54), rgba(27, 27, 27, 0.54)","height":"100%"}},[_c('v-layout',{staticClass:"fill-height",attrs:{"tag":"v-list","column":""}},[_c('div',{staticClass:"logo"},[_c('v-img',{attrs:{"src":_vm.logo,"height":"95","contain":""}})],1),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('v-list-tile',{staticClass:"v-list-item",attrs:{"to":{name: 'home.dashboard'},"active-class":_vm.color}},[_c('v-list-tile-action',[_c('v-icon',[_vm._v("dashboard")])],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',{attrs:{"color":"white"}},[_vm._v("Dashboard")])],1)],1),_vm._v(" "),_c('v-list-group',{staticClass:"sidebar-list v-list-item",attrs:{"no-action":""}},[_c('v-list-tile',{staticClass:"sidebar-list-title",attrs:{"slot":"activator","avatar":""},slot:"activator"},[_c('v-list-tile-action',[_c('v-icon',[_vm._v("question_answer")])],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',[_vm._v("Zadaci")])],1)],1),_vm._v(" "),_c('v-list-tile',{staticClass:"v-list-item",attrs:{"to":{name: 'home.zahtjev.list'},"active-class":_vm.color}},[_c('v-list-tile-content',[_c('v-list-tile-title',{attrs:{"color":"white"}},[_vm._v("Svi zadaci")])],1)],1),_vm._v(" "),(_vm.imaPravo('osnovno_dashboard_broj_zahtjeva_po_projektu'))?_c('v-list-tile',{staticClass:"v-list-item",attrs:{"to":{name: 'home.zahtjev.list-draggable'},"active-class":_vm.color}},[_c('v-list-tile-content',[_c('v-list-tile-title',{attrs:{"color":"white"}},[_vm._v("Zadaci po projektima")])],1)],1):_vm._e()],1),_vm._v(" "),(_vm.imaPravo('glavni_meni_osnovno_sidebar_projekti'))?_c('v-list-group',{staticClass:"sidebar-list v-list-item",attrs:{"no-action":"","active-class":_vm.color}},[_c('v-list-tile',{staticClass:"sidebar-list-title",attrs:{"slot":"activator","to":{name: 'home.projekat.list'},"avatar":""},slot:"activator"},[_c('v-list-tile-action',[_c('v-icon',[_vm._v("library_books")])],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',[_vm._v("Projekti")])],1)],1),_vm._v(" "),_c('v-list-tile',{staticClass:"v-list-item",attrs:{"active-class":_vm.color}},[_c('v-list-tile-content',[_c('v-list-tile-title',{attrs:{"color":"white"}},[_vm._v("Tok izrade")])],1)],1)],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('glavni_meni_osnovno_sidebar_korisnici'))?_c('v-list-tile',{staticClass:"v-list-item",attrs:{"to":{name: 'home.korisnik.list'},"active-class":_vm.color}},[_c('v-list-tile-action',[_c('v-icon',[_vm._v("people")])],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',{attrs:{"color":"white"}},[_vm._v("Korisnici")])],1)],1):_vm._e(),_vm._v(" "),(_vm.imaPravo('glavni_meni_osnovno_sidebar_uloge'))?_c('v-list-tile',{staticClass:"v-list-item",attrs:{"to":{name: 'home.uloga.list'},"active-class":_vm.color}},[_c('v-list-tile-action',[_c('v-icon',[_vm._v("portrait")])],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',{attrs:{"color":"white"}},[_vm._v("Uloge")])],1)],1):_vm._e()],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/sifarnik/dodavanje-sifarnik.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _page = require('../components/page');

var _page2 = _interopRequireDefault(_page);

var _upit = require('../components/upit');

var _upit2 = _interopRequireDefault(_upit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'DodavanjeSifarnik',

    data: function data() {
        return {
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,
            valid: false,
            vrijednosti: {},
            rules: {
                obavezno: [function (v) {
                    return !!v || v === false || 'Polje je obavezno';
                }],
                obaveznoBroj: [function (v) {
                    return (!!v || v == 0) && /^[0-9]*$/.test(v) || 'Polje je obavezno i mora biti validan broj';
                }]
            }
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },


    methods: {
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        onSubmit: function onSubmit() {
            var _this = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (this.valid) {
                var that = this;
                var success = function success() {
                    _this.proslijedi = true;
                    that.$router.push({
                        name: 'home.sifarnik',
                        params: that.$route.params
                    });
                };
                var error = function error() {
                    that.$toast.error('Dodavanje šifarnika nije uspjelo. Provjerite unesene podatke.');
                };

                var promise = (0, _resources.SifarnikResource)().save({
                    tipSifarnika: that.$route.params.tipSifarnika
                }, {
                    sifarnik: that.vrijednosti
                });

                promise.then(success, error);
            }
        }
    },

    resolve: {
        polja: function polja() {
            return (0, _resources.SifarnikResource)().polja(this.$route.params);
        }
    },

    watch: {
        resolved: function resolved(_resolved) {
            var _this2 = this;

            if (_resolved) {
                this.resolved.polja.forEach(function (field) {
                    return _this2.$set(_this2.vrijednosti, field.poljeUTabeli, null);
                });
            }
        }
    },

    components: {
        Page: _page2.default,
        Upit: _upit2.default
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved,"title":_vm.tipSifarnika}},[(_vm.resolved)?_c('material-card',{attrs:{"title":"Dodavanje","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_vm._l((_vm.resolved.polja),function(polje){return [(_vm.prikaziPolje('dodavanje', polje.vidljivosti))?[(_vm.getTipPolja(polje.tip) == 'select')?_c('v-autocomplete',{class:{'required': polje.required},attrs:{"required":polje.required,"item-text":"naziv","item-value":"id","rules":polje.required ? _vm.rules.obavezno : _vm.rules.nijeObavezno,"label":polje.naziv,"items":polje.opcije,"bottom":""},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}}):(_vm.getTipPolja(polje.tip) == 'checkbox')?_c('v-checkbox',{attrs:{"rules":polje.required ? _vm.rules.obavezno : _vm.rules.nijeObavezno,"label":polje.naziv,"light":""},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}}):(_vm.getTipPolja(polje.tip) == 'number')?_c('v-text-field',{class:{'required': polje.required},attrs:{"type":"text","pattern":"[0-9]*","required":polje.required,"rules":polje.required ? _vm.rules.obaveznoBroj : _vm.rules.nijeObavezno,"label":polje.naziv},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}}):_c('v-text-field',{class:{'required': polje.required},attrs:{"required":polje.required,"rules":polje.required ? _vm.rules.obavezno : _vm.rules.nijeObavezno,"label":polje.naziv},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}})]:_vm._e()]}),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"secondary":""},on:{"click":_vm.onSubmit}},[_vm._v("Dodaj")])],1)],2)],1)],1):_vm._e(),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/sifarnik/edit-sifarnik.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _page = require('../components/page');

var _page2 = _interopRequireDefault(_page);

var _upit = require('../components/upit');

var _upit2 = _interopRequireDefault(_upit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'EditSifarnik',

    data: function data() {
        return {
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,

            valid: false,
            vrijednosti: {},
            rules: {
                obavezno: [function (v) {
                    return !!v || v === false || 'Polje je obavezno';
                }],
                obaveznoBroj: [function (v) {
                    return (!!v || v == 0) && /^[0-9]*$/.test(v) || 'Polje je obavezno i mora biti validan broj';
                }],
                nijeObavezno: [function () {
                    return true;
                }]
            }
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },


    methods: {
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        onSubmit: function onSubmit() {
            var _this = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (this.valid) {
                var that = this;
                var success = function success() {
                    _this.proslijedi = true;
                    that.$router.push({
                        name: 'home.sifarnik',
                        params: that.$route.params
                    });
                };
                var error = function error() {
                    that.$toast.error('Dodavanje šifarnika nije uspjelo. Provjerite unesene podatke.');
                };

                (0, _resources.SifarnikResource)().update(that.$route.params, {
                    sifarnik: that.vrijednosti,
                    id: that.$route.params.id
                }).then(success, error);
            }
        },
        updateVrijednosti: function updateVrijednosti(naziv, vrijednost) {
            this.vrijednosti[naziv] = vrijednost;
        },
        lowercaseFirstLetter: function lowercaseFirstLetter(string) {
            return string.charAt(0).toLowerCase() + string.slice(1);
        }
    },

    resolve: {
        polja: function polja() {
            return (0, _resources.SifarnikResource)().polja(this.$route.params);
        },
        vrijednosti: function vrijednosti() {
            return (0, _resources.SifarnikResource)().get(this.$route.params);
        }
    },

    watch: {
        resolved: function resolved(_resolved) {
            var _this2 = this;

            if (_resolved) {
                this.resolved.polja.forEach(function (field) {
                    return _this2.$set(_this2.vrijednosti, field.poljeUTabeli, _resolved.vrijednosti[field.poljeUTabeli]);
                });
            }
        }
    },

    components: {
        Page: _page2.default,
        Upit: _upit2.default
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?_c('v-card',[_c('v-card-title',{staticClass:"grey lighten-4",attrs:{"primary-title":""}},[_vm._v("\r\n            Izmjena\r\n        ")]),_vm._v(" "),_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_vm._l((_vm.resolved.polja),function(polje){return [(_vm.prikaziPolje('edit', polje.vidljivosti))?[(_vm.getTipPolja(polje.tip) == 'select')?_c('v-autocomplete',{class:{'required': polje.required},attrs:{"required":polje.required,"item-text":"naziv","item-value":"id","rules":polje.required ? _vm.rules.obavezno : _vm.rules.nijeObavezno,"label":polje.naziv,"items":polje.opcije,"bottom":""},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}}):(_vm.getTipPolja(polje.tip) == 'checkbox')?_c('v-checkbox',{attrs:{"label":polje.naziv,"light":""},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}}):(_vm.getTipPolja(polje.tip) == 'number')?_c('v-text-field',{class:{'required': polje.required},attrs:{"type":"tel","pattern":"[0-9]*","required":polje.required,"rules":polje.required ? _vm.rules.obaveznoBroj : _vm.rules.nijeObavezno,"label":polje.naziv},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}}):_c('v-text-field',{class:{'required': polje.required},attrs:{"required":polje.required,"rules":polje.required ? _vm.rules.obavezno : _vm.rules.nijeObavezno,"label":polje.naziv},model:{value:(_vm.vrijednosti[polje.poljeUTabeli]),callback:function ($$v) {_vm.$set(_vm.vrijednosti, polje.poljeUTabeli, $$v)},expression:"vrijednosti[polje.poljeUTabeli]"}})]:_vm._e()]}),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"secondary":""},on:{"click":_vm.onSubmit}},[_vm._v("Spasi")])],1)],2)],1)],1):_vm._e(),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/sifarnik/lista-sifarnik.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _paginationMixin = require('helpers/pagination-mixin');

var _paginationMixin2 = _interopRequireDefault(_paginationMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaSifarnik',
    mixins: [_paginationMixin2.default],
    data: function data() {
        return {
            model: {
                fields: [],
                items: []
            },
            lista: null,
            showModal: false,
            idBrisanje: null,
            filterMenu: false,
            filtrirano: false,
            inputs: {
                filter: null,
                page: 1,
                count: 30,
                sifarnik: this.$route.params.tipSifarnika
            },
            loading: true,
            identity: _identity2.default
        };
    },


    computed: {
        headers: function headers() {
            return this.model.fields.filter(function (polje) {
                return !(polje.class == "hidden");
            });
        }
    },

    created: function created() {
        var _this = this;

        this.$watch(function () {
            return _this.$route.params.tipSifarnika;
        }, function (tip) {
            this.inputs.sifarnik = tip;
            this.updateData();
        });
        this.inputs = this.mergeQueryToInput(this.$route.query, this.inputs);
    },
    mounted: function mounted() {
        if (this.inputs.page) {
            this.pagination.page = this.inputs.page;
        }
        if (this.inputs.count) {
            this.pagination.count = this.inputs.count;
        }
    },


    methods: {
        filtriraj: function filtriraj() {
            if (this.inputs.filter) {
                this.filtrirano = true;
            } else {
                this.filtrirano = false;
            }
            this.filterMenu = false;
            this.resetujPaginaciju();
        },
        ponistiFilter: function ponistiFilter() {
            this.inputs.filter = "";
            this.filterMenu = false;
            this.filtrirano = false;
            this.resetujPaginaciju();
        },
        updateData: function updateData() {
            var that = this;
            this.osvjeziQuery(this.inputs);

            var success = function success(lista) {
                that.model = lista.body;
                that.totalItems = lista.body.total;
                that.loading = false;
            };

            var error = function error() {
                that.$toast.error("Filtriranje nije uspješno");
            };

            (0, _resources.SifarnikResource)().nekesirano(this.inputs).then(success, error);
        },
        prikaziModal: function prikaziModal(id) {
            this.idBrisanje = id;
            this.showModal = true;
        },
        closeModal: function closeModal(event) {
            var _this2 = this;

            if (event.obrisi) {
                var parametri = {
                    tipSifarnika: this.$route.params.tipSifarnika,
                    id: event.id
                };
                var success = function success() {
                    _this2.updateData();
                };

                (0, _resources.SifarnikResource)().update(parametri, {
                    sifarnik: {
                        isDeleted: true,
                        onemogucena: true
                    },
                    id: event.id
                }).then(success);
            }
            this.showModal = false;
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.model)?_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v(_vm._s(_vm.$route.params.tipSifarnika))])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":"","to":{ name: 'home.sifarnik.dodavanje', params: { tipSifarnika: _vm.inputs.sifarnik, nazivSifarnika: _vm.$route.params.nazivSifarnika }}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\n                            DODAJ\n                        ")],1),_vm._v(" "),_c('v-menu',{attrs:{"close-on-content-click":false,"content-class":"dropdown-menu","bottom":"","left":"","offset-y":"","transition":"slide-y-transition"},model:{value:(_vm.filterMenu),callback:function ($$v) {_vm.filterMenu=$$v},expression:"filterMenu"}},[_c('v-btn',{staticClass:"toolbar-btn",attrs:{"slot":"activator","flat":""},slot:"activator"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("filter_list")]),_vm._v("Filtriraj")],1),_vm._v(" "),_c('v-card',[_c('v-card-title',[_c('div',{staticClass:"filter-title"},[_vm._v("\n                                    Filtriraj po\n                                ")])]),_vm._v(" "),_c('v-form',{staticClass:"filter",on:{"submit":_vm.filtriraj}},[_c('v-card-text',{staticClass:"pt-0"},[_c('v-text-field',{attrs:{"label":"Naziv","hide-details":""},model:{value:(_vm.inputs.filter),callback:function ($$v) {_vm.$set(_vm.inputs, "filter", $$v)},expression:"inputs.filter"}})],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary"},on:{"click":_vm.ponistiFilter}},[_vm._v("Poništi")]),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary","type":"submit"}},[_vm._v("Filtriraj")])],1)],1)],1)],1)],1)],1)],1),_vm._v(" "),_c('obrisi-modal',{attrs:{"aktivan":_vm.showModal,"item":_vm.idBrisanje,"header":"Brisanje šifarnika","body":"Jeste li sigurni da želite obrisati šifarnik?"},on:{"close":function($event){return _vm.closeModal($event)}}}),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"no-data-text":"Nema šifarnika za prikaz.","items":_vm.model.items,"pagination":_vm.pagination,"total-items":_vm.model.total,"loading":_vm.loading,"rows-per-page-items":_vm.rowsPerPageItems},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"headers",fn:function(props){return [_c('tr',[_vm._l((_vm.headers),function(header){return _c('th',{staticClass:"text-xs-left"},[_vm._v(_vm._s(header.text))])}),_vm._v(" "),_c('th')],2)]}},{key:"items",fn:function(props){return [_vm._l((_vm.headers),function(header){return _c('td',[_vm._v("\n                        "+_vm._s(props.item[header.value])+"\n                    ")])}),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_c('v-menu',{attrs:{"open-on-hover":"","offset-y":"","left":""}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("settings")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.sifarnik.edit', params: { tipSifarnika: _vm.inputs.sifarnik, id: props.item.id, nazivSifarnika: _vm.$route.params.nazivSifarnika} }}},[_c('v-list-tile-title',[_vm._v("Izmijeni")])],1),_vm._v(" "),(_vm.inputs.sifarnik != 'VrstaPohvale')?_c('v-list-tile',{attrs:{"id":"show-modal"},on:{"click":function($event){return _vm.prikaziModal(props.item.id)}}},[_c('v-list-tile-title',[_vm._v("Obriši")])],1):_vm._e()],1)],1)],1)]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\n                    Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\n                ")]}}],null,false,644049243)})],1)],1):_vm._e()}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/sifarnik/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _listaSifarnik = require('./lista-sifarnik');

var _listaSifarnik2 = _interopRequireDefault(_listaSifarnik);

var _dodavanjeSifarnik = require('./dodavanje-sifarnik');

var _dodavanjeSifarnik2 = _interopRequireDefault(_dodavanjeSifarnik);

var _editSifarnik = require('./edit-sifarnik');

var _editSifarnik2 = _interopRequireDefault(_editSifarnik);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Sifarnik',
    routes: [{
        path: ':tipSifarnika',
        name: 'home.sifarnik',
        component: _listaSifarnik2.default
    }, {
        path: ':tipSifarnika/dodavanje',
        name: 'home.sifarnik.dodavanje',
        component: _dodavanjeSifarnik2.default
    }, {
        path: ':tipSifarnika/edit/:id',
        name: 'home.sifarnik.edit',
        component: _editSifarnik2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/store.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// import * as types from './mutation-types'
// initial state
var state = {
  naslovSistema: null,
  odabraniJezik: null,
  navigationbarComponent: null,
  drawer: null
};

// getters
var getters = {
  naslovSistema: function naslovSistema(state) {
    return state.naslovSistema;
  },
  odabraniJezik: function odabraniJezik(state) {
    return state.odabraniJezik;
  },
  navigationbarComponent: function navigationbarComponent(state) {
    return state.navigationbarComponent;
  },
  drawer: function drawer(state) {
    return state.drawer;
  }
};

// mutations
var mutations = {
  setNaslovSistema: function setNaslovSistema(state, naslovSistema) {
    state.naslovSistema = naslovSistema;
  },
  setOdabraniJezik: function setOdabraniJezik(state, odabraniJezik) {
    state.odabraniJezik = odabraniJezik;
  },
  setNavigationbarComponent: function setNavigationbarComponent(state, component) {
    console.log(state, component, 'component');
    state.navigationbarComponent = component;
  },
  setDrawer: function setDrawer(state, drawer) {
    state.drawer = drawer;
  }
};

exports.default = {
  namespaced: true,
  state: state,
  getters: getters,
  mutations: mutations
};

});

require.register("modules/home/toolbar.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _auth = require("auth");

var _auth2 = _interopRequireDefault(_auth);

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _pregled = require("./zahtjev/pregled.vue");

var _pregled2 = _interopRequireDefault(_pregled);

var _resources = require("api/resources");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "Toolbar",
    components: {
        PregledZahtjev: _pregled2.default
    },
    data: function data() {
        return {
            identity: _identity2.default,
            notifications: [],
            title: 'Project Management System',
            responsive: false,
            ucitaneNotifikacije: false
        };
    },

    watch: {
        '$route': function $route(val) {
            this.title = window.document.title;
        }
    },

    mounted: function mounted() {
        this.onResponsiveInverted();
        window.addEventListener('resize', this.onResponsiveInverted);
        this.vratiNotifikacije();
    },
    beforeDestroy: function beforeDestroy() {
        window.removeEventListener('resize', this.onResponsiveInverted);
    },


    methods: {
        otvoriZahtjev: function otvoriZahtjev(id) {
            this.$route.params.zahtjevId = id;
            this.ucitaneNotifikacije = true;
        },
        onClickBtn: function onClickBtn() {
            this.$store.commit('home/setDrawer', !this.$store.getters['home/drawer']);
        },
        onClick: function onClick(notification) {
            var that = this;
            var success = function success(response) {
                that.otvoriZahtjev(notification.zahtjevId);
                that.vratiNotifikacije();
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.NotifikacijeResource)().otvori({
                notifikacijaId: notification.id
            });

            promise.then(success, error);
        },
        signOut: function signOut() {
            _auth2.default.signOut();

            this.$router.push({
                name: "auth.prijava"
            });
        },
        onResponsiveInverted: function onResponsiveInverted() {
            if (window.innerWidth < 991) {
                this.responsive = true;
            } else {
                this.responsive = false;
            }
        },
        vratiNotifikacije: function vratiNotifikacije() {
            var that = this;
            that.ucitaneNotifikacije = false;


            var success = function success(response) {
                that.notifications = response.body;
                that.ucitaneNotifikacije = true;
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.NotifikacijeResource)().vratiNotifikacije();

            promise.then(success, error);
        },
        azuriranjeZahtjeva: function azuriranjeZahtjeva(zahtjev, azuriran) {

            this.ucitaneNotifikacije = true;

            if (azuriran) {
                this.updateData;
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-toolbar',{staticStyle:{"background":"#eee"},attrs:{"id":"core-toolbar","flat":"","prominent":""}},[_c('div',{staticClass:"v-toolbar-title"},[_c('v-toolbar-title',{staticClass:"tertiary--text font-weight-light"},[(_vm.responsive)?_c('v-btn',{staticClass:"default v-btn--simple",attrs:{"icon":"","color":"tertiary"},on:{"click":function($event){$event.stopPropagation();return _vm.onClickBtn($event)}}},[_c('v-icon',{attrs:{"color":"tertiary"}},[_vm._v("menu")])],1):_vm._e(),_vm._v("\r\n            "+_vm._s(_vm.title)+"\r\n        ")],1)],1),_vm._v(" "),_c('v-spacer'),_vm._v(" "),_c('v-toolbar-items',[_c('v-flex',{attrs:{"align-center":"","layout":"","py-2":""}},[_c('v-menu',{attrs:{"bottom":"","left":"","content-class":"dropdown-menu","offset-y":"","transition":"slide-y-transition"}},[_c('router-link',{directives:[{name:"ripple",rawName:"v-ripple"}],staticClass:"toolbar-items",attrs:{"slot":"activator","to":""},nativeOn:{"click":function($event){return _vm.vratiNotifikacije($event)}},slot:"activator"},[_c('v-badge',{attrs:{"color":"error","overlap":""}},[(_vm.ucitaneNotifikacije)?_c('template',{slot:"badge"},[_vm._v("\r\n                            "+_vm._s(_vm.notifications.length)+"\r\n                        ")]):_vm._e(),_vm._v(" "),_c('v-icon',{attrs:{"color":"tertiary"}},[_vm._v("notifications")])],2)],1),_vm._v(" "),_c('v-card',[_c('v-list',{attrs:{"three-line":""}},_vm._l((_vm.notifications),function(notification){return _c('v-list-tile',{key:notification.id,class:{'nova-notifikacija': false},on:{"click":function($event){return _vm.onClick(notification)}}},[_c('v-list-tile-content',[_c('v-list-tile-title',{domProps:{"textContent":_vm._s(notification.naslov)}}),_vm._v(" "),_c('v-list-tile-sub-title',{domProps:{"textContent":_vm._s(notification.poruka)}}),_vm._v(" "),_c('v-list-tile-action-text',{staticClass:"text-xs-right"},[_c('date-format',{attrs:{"vrijednost":notification.datumKreiranja,"format":'DD.MM.YYYY. hh:mm'}})],1)],1)],1)}),1)],1)],1),_vm._v(" "),_c('v-menu',{staticClass:"toolbar-menu",attrs:{"offset-y":"","bottom":"","left":"","content-class":"dropdown-menu","transition":"slide-y-transition"}},[_c('v-btn',{directives:[{name:"ripple",rawName:"v-ripple",value:({ class: 'primary--text' }),expression:"{ class: 'primary--text' }"}],staticClass:"toolbar-menu-btn",attrs:{"slot":"activator","flat":"","right":"","color":"tertiary"},slot:"activator"},[_c('v-icon',{staticClass:"pr-2"},[_vm._v("person")]),_vm._v(" "),(_vm.identity.punoIme().length>30)?_c('div',[_vm._v(_vm._s(_vm.identity.punoIme().slice(0,27)+"..."))]):_c('div',[_vm._v(_vm._s(_vm.identity.punoIme()))])],1),_vm._v(" "),_c('v-list',{attrs:{"id":"lista-akcija"}},[_c('v-list-tile',{attrs:{"to":{ name: 'home.racun.licni-detalji', params: { korisnickoIme: _vm.identity.korisnickoIme() } }}},[_c('v-list-tile-title',[_c('v-icon',{staticClass:"pr-2"},[_vm._v("settings")]),_vm._v("Lični detalji\r\n                        ")],1)],1),_vm._v(" "),_c('v-list-tile',{attrs:{"to":{ name: 'home.racun.lozinka', params: { korisnickoIme: _vm.identity.korisnickoIme() } }}},[_c('v-list-tile-title',[_c('v-icon',{staticClass:"pr-2"},[_vm._v("vpn_key")]),_vm._v("Promjena lozinke\r\n                        ")],1)],1),_vm._v(" "),_c('v-list-tile',{attrs:{"to":{ name: 'home.racun.sesije', params: { korisnickoIme: _vm.identity.korisnickoIme() } }}},[_c('v-list-tile-title',[_c('v-icon',{staticClass:"pr-2"},[_vm._v("lock_open")]),_vm._v("Pregled prijava\r\n                        ")],1)],1),_vm._v(" "),_c('v-list-tile',{attrs:{"href":"#"},nativeOn:{"click":function($event){return _vm.signOut($event)}}},[_c('v-list-tile-title',[_c('v-icon',{staticClass:"pr-2"},[_vm._v("exit_to_app")]),_vm._v("Odjava\r\n                        ")],1)],1)],1)],1)],1)],1),_vm._v(" "),(_vm.ucitaneNotifikacije)?_c('pregled-zahtjev',{attrs:{"zahtjevId":_vm.id},on:{"azuriraniZahtjev":_vm.azuriranjeZahtjeva}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/uloge/dodavanje.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "DodavanjeUloga",

    components: {
        Upit: _upit2.default
    },
    data: function data() {
        return {
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,
            valid: true,
            uloga: {
                naziv: null,
                sifra: null
            },
            rules: {
                obavezno: [function (v) {
                    return !!v || "Polje je obavezno";
                }],
                obavezno100: [function (v) {
                    return !!v || "Polje je obavezno";
                }, function (v) {
                    return !!v && v.length <= 100 || "Polje mora biti manje od 100 karaktera";
                }]
            }
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },

    methods: {
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        onSubmit: function onSubmit() {
            var _this = this;

            var that = this;

            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (!this.valid) return;

            var success = function success(model) {
                _this.proslijedi = true;
                that.$router.push({
                    name: "home.prava.uloga.edit",
                    params: {
                        id: model.body.id
                    },
                    query: {
                        naziv: model.body.naziv
                    }
                });
            };
            var error = function error() {
                that.$toast.error("Dodavanje uloge uspjelo. Provjerite unesene podatke.");
            };

            var promise = (0, _resources.UlogaResource)().save(that.$route.params, that.uloga);

            promise.then(success, error);
        }
    },
    resolve: {
        frontendModuli: function frontendModuli() {
            return (0, _resources.SifarnikResource)().get({
                sifarnik: 'FrontendModul'
            });
        },
        uloge: function uloge() {
            return (0, _resources.UlogaResource)().get();
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?_c('material-card',{attrs:{"title":"Dodaj ulogu","color":"primary"}},[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno100,"counter":100,"label":"Naziv","required":""},model:{value:(_vm.uloga.naziv),callback:function ($$v) {_vm.$set(_vm.uloga, "naziv", $$v)},expression:"uloga.naziv"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno100,"counter":100,"label":"Šifra","required":""},model:{value:(_vm.uloga.sifra),callback:function ($$v) {_vm.$set(_vm.uloga, "sifra", $$v)},expression:"uloga.sifra"}}),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('odustani-btn',{on:{"odustani":_vm.Odustani}}),_vm._v(" "),_c('v-btn',{attrs:{"secondary":""},on:{"click":_vm.onSubmit}},[_vm._v("Dodaj")])],1)],1)],1):_vm._e(),_vm._v(" "),(_vm.activeUpozorenje)?_c('Upit',{on:{"odgovor":_vm.Odgovor}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/uloge/edit.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

exports.default = {
    name: "EditUloga",
    data: function data() {
        return {
            odabranaGrupa: null,
            naziv: this.$route.query.naziv,
            ulogaId: this.$route.params.ulogaId,
            resolved: null,
            validOsnovno: true,
            dodatneInformacije: [{
                odabrano: false,
                naziv: "SkolaId",
                opis: "Ovo se odnosi na uloge kao npr. Uprava škole"
            }, {
                odabrano: false,
                naziv: "OsobaId",
                opis: "Ovo se odnosi na uloge kao npr. Nastavnik"
            }, {
                odabrano: false,
                naziv: "UcenikId",
                opis: "Ovo se odnosi na uloge kao npr. Učenik"
            }],
            rules: {
                obavezno: [function (v) {
                    return !!v || "Polje je obavezno";
                }],
                obavezno100: [function (v) {
                    return !!v || "Polje je obavezno";
                }, function (v) {
                    return !!v && v.length <= 100 || "Polje mora biti manje od 100 karaktera";
                }]
            }
        };
    },

    methods: {
        snimiOsnovno: function snimiOsnovno() {
            var _this = this;

            var that = this;

            this.$refs.formosnovno.validate();
            this.focusInvalidInput(this.$refs.formosnovno);

            if (!this.validOsnovno) return;

            var success = function success() {
                _this.proslijedi = true;
                that.$toast.success("Uspješno snimljene osnovne informacije");
            };
            var error = function error() {
                that.$toast.error("Izmjena uloge nije uspjela. Provjerite unesene podatke.");
            };
            console.log(that.resolved.uloga, that.$route.params.ulogaId);
            var promise = (0, _resources.UlogaResource)().update({
                ulogaId: that.$route.params.ulogaId
            }, that.resolved.uloga);

            promise.then(success, error);
        },
        snimiDozvoljeno: function snimiDozvoljeno() {
            var model = this.resolved.dozvoljeneAkcije.items.map(function (a) {
                return a.pravoAkcijaId;
            });
            var that = this;

            function success() {
                that.$toast.success("Uspješno snimljene dozvoljene akcije");
            }

            function error() {
                that.$toast.error("Dogodila se greška");
            }

            (0, _resources.UlogaResource)().snimiDozvoljeneAkcije({
                ulogaId: this.ulogaId
            }, {
                ulogaId: this.ulogaId,
                akcije: model
            }).then(success, error);
        },
        snimiDodatno: function snimiDodatno() {
            var model = this.resolved.dodatneInformacije.items.map(function (a) {
                return a.korisnikTipDodatneInformacijeId;
            });
            var that = this;

            function success() {
                that.$toast.success("Uspješno snimljene potrebne dodatne informacije");
            }

            function error() {
                that.$toast.error("Dogodila se greška");
            }

            (0, _resources.UlogaTipoviDodatneInformacijeResource)().snimiZaUlogu({
                ulogaId: this.ulogaId
            }, {
                ulogaId: this.ulogaId,
                dodatneInformacije: model
            }).then(success, error);
        },
        getDozvoljena: function getDozvoljena(akcija) {
            return this.resolved.dozvoljeneAkcije.items.some(function (a) {
                return a.pravoAkcijaId === akcija.id;
            });
        },
        potrebnoDodatno: function potrebnoDodatno(dodatno) {
            return this.resolved.dodatneInformacije.items.some(function (a) {
                return a.korisnikTipDodatneInformacijeId === dodatno.id;
            });
        },
        updateDozvoljeno: function updateDozvoljeno(vrijednost, akcija) {
            if (!vrijednost) {
                this.resolved.dozvoljeneAkcije.items = this.resolved.dozvoljeneAkcije.items.filter(function (a) {
                    return a.pravoAkcijaId !== akcija.id;
                });
            } else if (!this.resolved.dozvoljeneAkcije.items.some(function (a) {
                return a.pravoAkcijaId === akcija.id;
            })) {
                this.resolved.dozvoljeneAkcije.items.push({
                    pravoAkcijaId: akcija.id,
                    ulogaId: this.ulogaId
                });
            }
        },
        updatePotrebnoDodatno: function updatePotrebnoDodatno(vrijednost, dodatno) {
            if (!vrijednost) {
                this.resolved.dodatneInformacije.items = this.resolved.dodatneInformacije.items.filter(function (a) {
                    return a.korisnikTipDodatneInformacijeId !== dodatno.id;
                });
            } else if (!this.resolved.dodatneInformacije.items.some(function (a) {
                return a.korisnikTipDodatneInformacijeId === dodatno.id;
            })) {
                this.resolved.dodatneInformacije.items.push({
                    korisnikTipDodatneInformacijeId: dodatno.id,
                    ulogaId: this.ulogaId
                });
            }
        }
    },
    resolve: {
        uloga: function uloga() {
            return (0, _resources.UlogaResource)().get({
                ulogaId: this.ulogaId
            });
        },
        uloge: function uloge() {
            return (0, _resources.UlogaResource)().get();
        },
        grupe: function grupe() {
            return (0, _resources.UlogaResource)().grupePrava({
                ulogaId: this.ulogaId
            });
        },
        dozvoljeneAkcije: function dozvoljeneAkcije() {
            return (0, _resources.UlogaResource)().dozvoljeneAkcije({
                ulogaId: this.ulogaId
            });
        },
        dodatneInformacije: function dodatneInformacije() {
            return (0, _resources.UlogaTipoviDodatneInformacijeResource)().sveZaUlogu({
                ulogaId: this.ulogaId
            });
        },
        korisnikDodatneInformacijeUcenik: function korisnikDodatneInformacijeUcenik() {
            return (0, _resources.SifarnikResource)().get({
                sifarnik: 'KorisnikTipDodatneInformacije'
            });
        },
        frontendModuli: function frontendModuli() {
            return (0, _resources.SifarnikResource)().get({
                sifarnik: 'FrontendModul'
            });
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.resolved)?[_c('material-card',{attrs:{"title":'Izmjena uloge ' + _vm.naziv,"color":"primary","text":"Osnovne informacije"}},[_c('v-card-text',[_c('v-form',{ref:"formosnovno",model:{value:(_vm.validOsnovno),callback:function ($$v) {_vm.validOsnovno=$$v},expression:"validOsnovno"}},[_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno100,"counter":100,"label":"Naziv","required":""},model:{value:(_vm.resolved.uloga.naziv),callback:function ($$v) {_vm.$set(_vm.resolved.uloga, "naziv", $$v)},expression:"resolved.uloga.naziv"}}),_vm._v(" "),_c('v-text-field',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno100,"counter":100,"label":"Šifra","required":""},model:{value:(_vm.resolved.uloga.sifra),callback:function ($$v) {_vm.$set(_vm.resolved.uloga, "sifra", $$v)},expression:"resolved.uloga.sifra"}}),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno,"required":"","items":_vm.resolved.frontendModuli,"item-text":"naziv","item-value":"id","label":"Korisnički interfejs","bottom":""},model:{value:(_vm.resolved.uloga.frontendModulId),callback:function ($$v) {_vm.$set(_vm.resolved.uloga, "frontendModulId", $$v)},expression:"resolved.uloga.frontendModulId"}}),_vm._v(" "),_c('v-select',{staticClass:"required",attrs:{"rules":_vm.rules.obavezno,"multiple":true,"required":"","items":_vm.resolved.uloge.items,"item-text":"naziv","item-value":"id","label":"Dozvoljene uloge za dodavanje","bottom":""},model:{value:(_vm.resolved.uloga.dozvoljeneUlogeZaUpravljanje),callback:function ($$v) {_vm.$set(_vm.resolved.uloga, "dozvoljeneUlogeZaUpravljanje", $$v)},expression:"resolved.uloga.dozvoljeneUlogeZaUpravljanje"}}),_vm._v(" "),_c('v-layout',{staticClass:"mt-3"},[_c('v-spacer'),_vm._v(" "),_c('odustani-btn'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.snimiOsnovno}},[_vm._v("Snimi")])],1)],1)],1)],1),_vm._v(" "),_c('material-card',{staticClass:"pt-3",attrs:{"title":"Potrebne dodatne informacije","color":"primary"}},[_c('v-card-text',[_c('v-form',[_c('v-list',{attrs:{"subheader":"","two-line":""}},_vm._l((_vm.resolved.korisnikDodatneInformacijeUcenik),function(dodatno){return _c('v-list-tile',{key:dodatno.id},[_c('v-list-tile-action',[_c('v-checkbox',{attrs:{"input-value":_vm.potrebnoDodatno(dodatno)},on:{"change":function($event){return _vm.updatePotrebnoDodatno($event, dodatno)}}})],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',[_vm._v(_vm._s(dodatno.naziv))]),_vm._v(" "),_c('v-list-tile-sub-title',[_vm._v(_vm._s(dodatno.opis))])],1)],1)}),1),_vm._v(" "),_c('v-layout',{staticClass:"mt-3"},[_c('v-spacer'),_vm._v(" "),_c('odustani-btn'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.snimiDodatno}},[_vm._v("Spasi")])],1)],1)],1)],1),_vm._v(" "),_c('material-card',{staticClass:"pt-3",attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',{attrs:{"xs8":""}},[_c('span',{staticClass:"card-naslov"},[_vm._v("Dozvoljene akcije ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-autocomplete",attrs:{"xs4":""}},[_c('v-autocomplete',{staticClass:"ml-3 ",attrs:{"hide-details":"","item-text":"naziv","item-value":"id","items":_vm.resolved.grupe.items,"return-object":"","label":"Grupa"},model:{value:(_vm.odabranaGrupa),callback:function ($$v) {_vm.odabranaGrupa=$$v},expression:"odabranaGrupa"}})],1)],1)],1),_vm._v(" "),_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-card-text',[(_vm.odabranaGrupa != null)?[_c('v-layout',{attrs:{"row":"","wrap":""}},[(_vm.odabranaGrupa.pravoObjekti.items.length)?_vm._l((_vm.odabranaGrupa.pravoObjekti.items),function(objekt){return _c('v-flex',{key:objekt.id,staticClass:"elevation-1 mb-3",attrs:{"xs12":""}},[_c('v-list',{attrs:{"subheader":"","two-line":""}},[_c('v-subheader',[_vm._v(_vm._s(objekt.naziv))]),_vm._v(" "),(objekt.pravoAkcije.items.length)?_vm._l((objekt.pravoAkcije.items),function(akcija){return _c('v-list-tile',{key:akcija.id},[_c('v-list-tile-action',[_c('v-checkbox',{attrs:{"input-value":_vm.getDozvoljena(akcija)},on:{"change":function($event){return _vm.updateDozvoljeno($event, akcija)}}})],1),_vm._v(" "),_c('v-list-tile-content',[_c('v-list-tile-title',[_vm._v(_vm._s(akcija.naziv))]),_vm._v(" "),_c('v-list-tile-sub-title',[_vm._v(_vm._s(akcija.opis))])],1)],1)}):[_c('div',{staticClass:"ma-4"},[_vm._v("Objekt nema akcija")])]],2)],1)}):[_c('div',{staticClass:"ma-4"},[_vm._v("Grupa nema objekata")])]],2),_vm._v(" "),_c('v-layout',{staticClass:"mt-3"},[_c('v-spacer'),_vm._v(" "),_c('odustani-btn'),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.snimiDozvoljeno}},[_vm._v("Spasi")])],1)]:_vm._e()],2)],1)],1)]:_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/uloge/list.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _paginationMixin = require('helpers/pagination-mixin');

var _paginationMixin2 = _interopRequireDefault(_paginationMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaUloga',
    mixins: [_paginationMixin2.default],
    data: function data() {
        return {
            totalItems: 0,
            resolved: null,
            headers: [{
                text: 'Naziv',
                align: 'left',
                sortable: false,
                value: 'naziv'
            }, {
                text: 'Aktivan',
                align: 'left',
                sortable: false,
                value: 'aktivan'
            }, {
                text: '',
                align: 'left',
                sortable: false,
                value: ''
            }],
            inputs: {
                page: 1,
                count: 30
            }
        };
    },
    created: function created() {
        this.inputs = this.mergeQueryToInput(this.$route.query, this.inputs);
    },
    mounted: function mounted() {
        if (this.inputs.page) {
            this.pagination.page = this.inputs.page;
        }
        if (this.inputs.count) {
            this.pagination.count = this.inputs.count;
        }
    },


    resolve: {
        uloge: function uloge() {
            return (0, _resources.UlogaResource)().get();
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[_c('v-layout',{attrs:{"justify-center":"","wrap":""}},[_c('v-flex',{attrs:{"xs12":""}},[_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Uloge ")])]),_vm._v(" "),(_vm.imaPravo('korisnik_uloga_dodavanje'))?_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":"","to":{ name: 'home.uloga.dodavanje' }}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("DODAJ\r\n                            ")],1)],1):_vm._e()],1)],1),_vm._v(" "),(_vm.resolved)?_c('v-data-table',{attrs:{"headers":_vm.headers,"items":_vm.resolved.uloge.items,"pagination":_vm.pagination,"total-items":_vm.totalItems,"no-data-text":"Nema uloga za prikaz.","loading":_vm.loading,"rows-per-page-items":_vm.rowsPerPageItems},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"headerCell",fn:function(ref){
var header = ref.header;
return [_c('span',{staticClass:"subheading font-weight-light text--darken-3",domProps:{"textContent":_vm._s(header.text)}})]}},{key:"items",fn:function(props){return [_c('td',[_vm._v(_vm._s(props.item.naziv))]),_vm._v(" "),_c('td',[_vm._v(_vm._s(props.item.isDeleted ? 'Ne' : 'Da'))]),_vm._v(" "),_c('td',{staticClass:"text-xs-right"},[_c('v-menu',{staticClass:"toolbar-menu",attrs:{"open-on-hover":"","offset-y":"","bottom":"","left":"","content-class":"dropdown-menu","transition":"slide-y-transition"}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("settings")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.uloga.edit', params: { ulogaId: props.item.id }, query:{ naziv: props.item.naziv } }}},[_c('v-list-tile-title',[_vm._v("Izmijeni ulogu")])],1)],1)],1)],1)]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\r\n                        Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\r\n                    ")]}}],null,false,2905716021)}):_vm._e()],1)],1)],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/uloge/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _list = require('./list');

var _list2 = _interopRequireDefault(_list);

var _dodavanje = require('./dodavanje');

var _dodavanje2 = _interopRequireDefault(_dodavanje);

var _edit = require('./edit');

var _edit2 = _interopRequireDefault(_edit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Korisnik',

    routes: [{
        path: '',
        name: 'home.uloga.list',
        component: _list2.default
    }, {
        path: 'dodavanje',
        name: 'home.uloga.dodavanje',
        component: _dodavanje2.default
    }, {
        path: 'edit/:ulogaId',
        name: 'home.uloga.edit',
        component: _edit2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/uloge/pregled.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'PregledUloga',
    mixins: [_helpTipDialogMixin2.default],
    data: function data() {
        return {
            activeHelpTip: false,
            helpTipDialogTitle: "Pregled korisnika",
            helpTipDialogContent: 'Pregled podataka o korisniku.',
            resolved: null,
            identity: _identity2.default
        };
    },


    methods: {
        aktivirajKorisnika: function aktivirajKorisnika() {
            var that = this;

            var success = function success() {
                that.resolved.model.onemogucen = false;
                that.$toast.info("Korisnik aktiviran");
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.KorisnikResource)().onemogucen(that.$route.params, {
                onemogucen: false
            });

            promise.then(success, error);
        },
        deAktivirajKorisnika: function deAktivirajKorisnika() {
            var that = this;

            var success = function success() {
                that.resolved.model.onemogucen = true;
                that.$toast.info("Korisnik deaktiviran");
            };

            var error = function error(poruka) {
                that.$toast.error(poruka);
            };

            var promise = (0, _resources.KorisnikResource)().onemogucen(that.$route.params, {
                onemogucen: true
            });

            promise.then(success, error);
        }
    },
    resolve: {
        model: function model() {
            return (0, _resources.KorisnikResource)().get(this.$route.params);
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',{attrs:{"resolved":_vm.resolved}},[(_vm.resolved)?[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('h2',{staticClass:"glavni-naslov"},[_vm._v("Pregled korisnika\r\n                    "),_c('v-btn',{staticClass:"glavni-naslov",attrs:{"flat":"","icon":"","color":"secondary"},on:{"click":function () { return this$1.activeHelpTip = true; }}},[_c('v-icon',[_vm._v("help")])],1)],1)]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right"},[_c('v-menu',{attrs:{"open-on-hover":"","offset-y":""}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("more_vert")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.korisnik.edit'}}},[_c('v-list-tile-title',[_vm._v("Izmijeni korisnika")])],1),_vm._v(" "),(_vm.resolved.model.onemogucen)?_c('v-list-tile',{attrs:{"href":""},on:{"click":_vm.aktivirajKorisnika}},[_c('v-list-tile-title',[_vm._v("Aktiviraj korisnika")])],1):_vm._e(),_vm._v(" "),(!_vm.resolved.model.onemogucen)?_c('v-list-tile',{attrs:{"href":""},on:{"click":_vm.deAktivirajKorisnika}},[_c('v-list-tile-title',[_vm._v("Deaktiviraj korisnika")])],1):_vm._e()],1)],1)],1)],1),_vm._v(" "),_c('v-card',[_c('v-card-title',{staticClass:"grey lighten-4",attrs:{"primary-title":""}},[_vm._v("\r\n                "+_vm._s(_vm.resolved.model.punoIme)+"\r\n            ")]),_vm._v(" "),_c('v-card-text',[_c('table',{staticClass:"v-table"},[_c('tbody',[_c('tr',[_c('td',[_vm._v("Korisničko ime")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.resolved.model.korisnickoIme))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Uloga korisnika")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.resolved.model.uloga))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Ime i prezime")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.resolved.model.punoIme))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("E-mail")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.resolved.model.email))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Datum nastanka")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.resolved.model.datumKreiranja.substring(8,10) + '. ' + _vm.resolved.model.datumKreiranja.substring(5,7)+ '. '+_vm.resolved.model.datumKreiranja.substring(0,4) + '.'))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Status")]),_vm._v(" "),(!_vm.resolved.model.onemogucen)?_c('td',[_vm._v("Aktivan")]):_vm._e(),_vm._v(" "),(_vm.resolved.model.onemogucen)?_c('td',[_vm._v("Nije aktivan")]):_vm._e()])])])])],1)]:_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.helpTipDialogTitle,"content":_vm.helpTipDialogContent},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/widgets/blok.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    name: 'blok',

    props: {
        naziv: {
            type: String,
            default: ''
        },
        vrijednost: {
            default: ''
        },
        klasa: {
            type: String,
            default: ''
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('v-card',{staticClass:"blok-card"},[_c('v-card-title',{attrs:{"primary-title":""}},[_c('v-layout',{staticClass:"text-xs-center",attrs:{"row":""}},[_c('v-flex',[_vm._v("\r\n                "+_vm._s(_vm.naziv)+"\r\n            ")])],1)],1),_vm._v(" "),_c('v-card-text',[_c('p',{staticClass:"card-text text-xs-center"},[_vm._v(_vm._s(_vm.vrijednost))])])],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/zahtjev/dodavanje.vue", function(exports, require, module) {
;(function(){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require("api/resources");

var _identity = require("auth/identity");

var _identity2 = _interopRequireDefault(_identity);

var _upit = require("../components/upit");

var _upit2 = _interopRequireDefault(_upit);

var _helpTipDialogMixin = require("helpers/help-tip-dialog-mixin");

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _uploadMixin = require("helpers/upload-mixin");

var _uploadMixin2 = _interopRequireDefault(_uploadMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: "DodavanjeZahtjeva",

    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default, _uploadMixin2.default],
    props: {
        poruka: {
            type: String,
            default: 'Dodaj fajl u prilog zahtjeva'
        }
    },
    data: function data() {
        return {
            acceptedFiles: {
                type: String,
                default: ".jpg,.png,.jpeg"
            },

            dropzoneOptionsOsnovno: {
                maxFiles: 5,
                queueLimit: 5,
                maxFileSize: 30,
                acceptedFiles: this.acceptedFiles,
                addRemoveLinks: true,
                url: "test",
                dictDefaultMessage: '<i aria-hidden="true" class="material-icons icon">file_upload</i><br />' + this.poruka
            },
            activeHelpTip: false,
            proslijedi: false,
            activeUpozorenje: false,
            next: {},
            resolved: null,
            valid: false,
            identity: _identity2.default,
            projekatId: null,
            prikazDijelovaProjekta: true,
            prikazDodatnihOpcija: false,

            zahtjevModel: {
                naziv: null,
                opis: null,
                kategorija: null,
                tip: null,
                projekat: null,
                dokument: null
            },
            dijeloviProjekta: [],
            tipoviZahtjeva: [],
            prioritetiZahtjeva: [],
            projekti: [],
            dialogDodajZahtjev: true,
            inputs: {
                sve: true
            },
            rules: {
                nazivZahtjeva: [function (v) {
                    return !!v || "Morate unijeti naziv zahtjeva";
                }, function (v) {
                    return v && v.length <= 128 || "Naziv ne može biti veći od 128 karaktera";
                }],
                opisZahtjeva: [function (v) {
                    return !!v || "Morate unijeti opis zahtjeva";
                }]
            }
        };
    },
    beforeRouteLeave: function beforeRouteLeave(to, from, next) {
        if (!this.proslijedi) {
            this.activeUpozorenje = true;
            this.next = next;
        } else {
            next();
        }
    },
    created: function created() {
        this.ucitajSveProjekte();
    },

    methods: {
        snimiObjekt: function snimiObjekt(model) {
            this.zahtjevModel.dokument = model.result;

            this.result = model.result;
            this.uspjesanUploadSlike = true;
        },
        Odustani: function Odustani() {
            this.proslijedi = true;
        },
        Odgovor: function Odgovor(odgovor) {
            if (odgovor) {
                this.next();
            } else {
                this.next(false);
                this.activeUpozorenje = false;
            }
        },
        colorClass: function colorClass(color) {
            return color + " lighten-2";
        },
        ucitajKonfiguracijuProjekta: function ucitajKonfiguracijuProjekta(id) {
            this.ucitajDijeloveProjekta(id);
            this.ucitajTipoveZahtjeva(id);
            this.ucitajPrioriteteZahtjeva(id);
        },
        ucitajTipoveZahtjeva: function ucitajTipoveZahtjeva(id) {
            var _this = this;

            var success = function success(response) {

                var that = _this;
                that.tipoviZahtjeva = response.body;
                that.odrediDefaultniTip();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiTipoveZahtjevaZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        odrediDefaultniTip: function odrediDefaultniTip() {

            for (var i = 0; i < this.tipoviZahtjeva.length; i++) {

                if (this.tipoviZahtjeva[i].default == true) {
                    this.zahtjevModel.tip = this.tipoviZahtjeva[i].id;
                    break;
                }
            }
        },
        ucitajPrioriteteZahtjeva: function ucitajPrioriteteZahtjeva(id) {
            var _this2 = this;

            var success = function success(response) {

                var that = _this2;
                that.prioritetiZahtjeva = response.body;
                that.odrediDefaultniPrioritet();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevPrioriteteZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        odrediDefaultniPrioritet: function odrediDefaultniPrioritet() {

            for (var i = 0; i < this.prioritetiZahtjeva.length; i++) {

                if (this.prioritetiZahtjeva[i].default == true) {
                    this.zahtjevModel.prioritet = this.prioritetiZahtjeva[i].id;

                    break;
                }
            }
        },
        ucitajSveProjekte: function ucitajSveProjekte() {
            var _this3 = this;

            var success = function success(response) {

                var that = _this3;
                that.projekti = response.body;

                if (that.projekti.length != 0) that.zahtjevModel.projekat = that.projekti.items[0].id;

                that.ucitajKonfiguracijuProjekta(that.zahtjevModel.projekat);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(this.inputs);
            promise.then(success, error);
        },
        zatvoriDialog: function zatvoriDialog() {
            this.dialogDodajZahtjev = false;
            this.$emit("dialogDodajZahtjev", this.dialogDodajZahtjev);
        },
        ucitajDijeloveProjekta: function ucitajDijeloveProjekta(id) {
            var _this4 = this;

            this.dijeloviProjekta = [];
            var success = function success(response) {

                var that = _this4;
                that.dijeloviProjekta = response.body;

                for (var i = 0; i < that.dijeloviProjekta.length; i++) {
                    {
                        that.zahtjevModel.dioProjekta = that.dijeloviProjekta[i].id;
                        break;
                    }
                }
                that.ucitajKategorijeZahtjeva(that.zahtjevModel.dioProjekta);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajKategorijeZahtjeva: function ucitajKategorijeZahtjeva(id) {
            var _this5 = this;

            this.kategorijeZahtjeva = [];
            this.zahtjevModel.kategorija = null;
            var success = function success(response) {

                var that = _this5;
                that.kategorijeZahtjeva = response.body;
                for (var i = 0; i < that.kategorijeZahtjeva.length; i++) {
                    {
                        that.zahtjevModel.kategorija = that.kategorijeZahtjeva[i].id;
                        break;
                    }
                }
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: id
            });

            promise.then(success, error);
        },
        dodajNoviZahtjev: function dodajNoviZahtjev() {
            var _this6 = this;

            this.valid = this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (!this.valid) return;else {

                var that = this;
                var success = function success(model) {
                    _this6.proslijedi = true;
                    that.$router.go({
                        name: "home.zahtjev.pregled",
                        params: {
                            zahtjevId: model.body.id
                        }
                    });
                    that.$toast.success("Uspješno kreiran novi zahtjev.");
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };

                var zahtjev = {};

                zahtjev.projekatId = that.zahtjevModel.projekat;
                zahtjev.naziv = that.zahtjevModel.naziv;
                zahtjev.opis = that.zahtjevModel.opis;
                zahtjev.zahtjevKategorijaId = that.zahtjevModel.kategorija;
                zahtjev.zahtjevTipId = that.zahtjevModel.tip;
                zahtjev.zahtjevPrioritetId = that.zahtjevModel.prioritet;
                zahtjev.dioProjektaId = that.zahtjevModel.dioProjekta;
                zahtjev.dokumentId = that.zahtjevModel.dokument;

                var promise = (0, _resources.ZahtjevResource)().dodajNoviZahtjev({
                    projekatId: zahtjev.projekatId
                }, zahtjev);
                promise.then(success, error);
            }
        },
        ucitajPostavkeZahtjevaProjekta: function ucitajPostavkeZahtjevaProjekta(id) {
            this.projekatId = id;
        },
        removeAllFiles: function removeAllFiles() {
            this.$refs.dropzone.removeAllFiles();
            this.zahtjevModel.dokument = null;
        },
        prikaziDodatneOpcije: function prikaziDodatneOpcije() {
            this.prikazDodatnihOpcija = true;
        },
        sakrijDodatneOpcije: function sakrijDodatneOpcije() {
            this.prikazDodatnihOpcija = false;
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[[_c('v-layout',{attrs:{"row":"","justify-center":""}},[_c('v-dialog',{attrs:{"projekat":_vm.ucitajPostavkeZahtjevaProjekta,"persistent":"","max-width":"600px"},model:{value:(_vm.dialogDodajZahtjev),callback:function ($$v) {_vm.dialogDodajZahtjev=$$v},expression:"dialogDodajZahtjev"}},[_c('v-card',[_c('v-card-title',[_c('span',{staticClass:"headline"},[_vm._v("Dodavanje novog zahtjeva")])]),_vm._v(" "),_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs4":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.projekti.items,"item-text":"naziv","item-value":"id","label":"Projekat","bottom":""},on:{"input":_vm.ucitajKonfiguracijuProjekta},model:{value:(_vm.zahtjevModel.projekat),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "projekat", $$v)},expression:"zahtjevModel.projekat"}})],1),_vm._v(" "),_c('br'),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm12":"","md12":""}},[_c('v-text-field',{attrs:{"label":"Naslov","counter":128,"rules":_vm.rules.nazivZahtjeva,"required":""},model:{value:(_vm.zahtjevModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "naziv", $$v)},expression:"zahtjevModel.naziv"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm12":"","md12":""}},[_c('v-text-field',{attrs:{"multi-line":"","label":"Opis","rules":_vm.rules.opisZahtjeva,"required":""},model:{value:(_vm.zahtjevModel.opis),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "opis", $$v)},expression:"zahtjevModel.opis"}})],1),_vm._v(" "),(_vm.dijeloviProjekta.length!=0)?_c('v-flex',{style:({display: _vm.dijeloviProjekta.length>1 ? 'visible' : 'none'}),attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.dijeloviProjekta,"item-text":"naziv","item-value":"id","label":"Podprojekat","bottom":""},on:{"input":_vm.ucitajKategorijeZahtjeva},model:{value:(_vm.zahtjevModel.dioProjekta),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "dioProjekta", $$v)},expression:"zahtjevModel.dioProjekta"}})],1):_vm._e(),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.kategorijeZahtjeva,"item-text":"naziv","item-value":"id","label":"Kategorija zahtjeva","bottom":""},model:{value:(_vm.zahtjevModel.kategorija),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "kategorija", $$v)},expression:"zahtjevModel.kategorija"}})],1)],1),_vm._v(" "),_c('v-expansion-panel',{attrs:{"expand":"","value":[false]}},[_c('v-expansion-panel-content',[_c('div',{attrs:{"slot":"header"},slot:"header"},[_vm._v("Prikaz dodatnih opcija")]),_vm._v(" "),_c('v-container',{attrs:{"grid-list-md":""}},[_c('v-layout',{attrs:{"wrap":""}},[_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.tipoviZahtjeva,"item-text":"naziv","item-value":"id","label":"Tip zahtjeva","bottom":""},model:{value:(_vm.zahtjevModel.tip),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "tip", $$v)},expression:"zahtjevModel.tip"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm6":"","md6":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.prioritetiZahtjeva,"item-text":"naziv","item-value":"id","label":"Prioritet zahtjeva","bottom":""},model:{value:(_vm.zahtjevModel.prioritet),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "prioritet", $$v)},expression:"zahtjevModel.prioritet"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm12":"","md12":""}},[_c('vue-dropzone',{ref:"dropzone",attrs:{"id":"upload-file-zahtjev","options":_vm.dropzoneOptions},on:{"vdropzone-removed-file":_vm.removeAllFiles,"vdropzone-success":function (file, response) { return _vm.snimiObjekt(response); },"vdropzone-sending":function (file, xhr, formData) { return _vm.addParam(formData, _vm.zahtjevModel, _vm.vrstaDokumenta); }}},[_c('div',{staticClass:"dropzone-custom-content"},[_c('div',{staticClass:"text-xs-center"},[_c('i',{staticClass:"material-icons icon",attrs:{"aria-hidden":"true"}},[_vm._v("file_upload")]),_vm._v(" "),_c('p',[_vm._v(" Upload ")])])])])],1)],1)],1)],1)],1)],1)],1)],1),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.zatvoriDialog()}}},[_vm._v("Odustani")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"blue darken-1","flat":""},on:{"click":function($event){return _vm.dodajNoviZahtjev()}}},[_vm._v("Dodaj")])],1)],1)],1)],1)]],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/zahtjev/edit.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'EditZahtjev',
    mixins: [_helpTipDialogMixin2.default],
    props: ['zahtjevId'],

    data: function data() {
        return {
            childZahtjevId: Number(this.zahtjevId),
            activeHelpTip: false,
            resolved: null,
            identity: _identity2.default,
            zahtjevModel: null,
            ucitanZahtjev: false,
            tipoviZahtjeva: [],
            prioritetiZahtjeva: [],
            statusiZahtjeva: [],
            kategorijeZahtjeva: [],
            supportKorisnici: [],

            rules: {
                nazivZahtjeva: [function (v) {
                    return !!v || "Polje naziv ne može biti prazno";
                }, function (v) {
                    return v && v.length <= 128 || "Naziv ne može biti veći od 128 karaktera";
                }],
                opisZahtjeva: [function (v) {
                    return !!v || "Polje opis ne može biti prazno";
                }]
            }
        };
    },
    created: function created() {
        this.ucitajZahtjev();
    },

    methods: {
        ucitajZahtjev: function ucitajZahtjev() {
            var _this = this;

            var that = this;

            if (that.$route.params.zahtjevId != null) that.childZahtjevId = Number(that.$route.params.zahtjevId);

            that.loading = true;
            var success = function success(response) {
                that.zahtjevModel = response.body;
                that.ucitanZahtjev = true;
                that.ucitajTipoveZahtjeva(that.zahtjevModel.projekatId);
                that.ucitajStatuseZahtjeva(that.zahtjevModel.projekatId);
                that.ucitajPrioriteteZahtjeva(that.zahtjevModel.projekatId);
                that.ucitajDijeloveProjekta(that.zahtjevModel.projekatId);
            };
            var error = function error(poruka) {
                _this.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ZahtjevResource)().vratiZahtjev({
                zahtjevId: that.childZahtjevId
            });
            promise.then(success, error);
        },
        ucitajTipoveZahtjeva: function ucitajTipoveZahtjeva(id) {
            var _this2 = this;

            var success = function success(response) {

                var that = _this2;
                that.tipoviZahtjeva = response.body;

                for (var i = 0; i < that.tipoviZahtjeva.length; i++) {

                    if (that.tipoviZahtjeva[i].naziv == that.zahtjevModel.zahtjevTip) {
                        that.zahtjevModel.tip = that.tipoviZahtjeva[i].id;
                        break;
                    }
                }
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiTipoveZahtjevaZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        odrediDefaultniTip: function odrediDefaultniTip() {

            for (var i = 0; i < this.tipoviZahtjeva.length; i++) {

                if (this.tipoviZahtjeva[i].default == true) {
                    this.zahtjevModel.tip = this.tipoviZahtjeva[i].id;
                    break;
                }
            }
        },
        ucitajPrioriteteZahtjeva: function ucitajPrioriteteZahtjeva(id) {
            var _this3 = this;

            var success = function success(response) {

                var that = _this3;
                that.prioritetiZahtjeva = response.body;

                for (var i = 0; i < that.prioritetiZahtjeva.length; i++) {

                    if (that.prioritetiZahtjeva[i].naziv == that.zahtjevModel.zahtjevPrioritet) {
                        that.zahtjevModel.prioritet = that.prioritetiZahtjeva[i].id;
                        break;
                    }
                }
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevPrioriteteZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        odrediDefaultniPrioritet: function odrediDefaultniPrioritet() {

            for (var i = 0; i < this.prioritetiZahtjeva.length; i++) {

                if (this.prioritetiZahtjeva[i].default == true) {
                    this.zahtjevModel.prioritet = this.prioritetiZahtjeva[i].id;

                    break;
                }
            }
        },
        ucitajStatuseZahtjeva: function ucitajStatuseZahtjeva(id) {
            var _this4 = this;

            var success = function success(response) {

                var that = _this4;
                that.statusiZahtjeva = response.body;
                for (var i = 0; i < that.statusiZahtjeva.length; i++) {
                    if (that.statusiZahtjeva[i].naziv == that.zahtjevModel.zahtjevStatus.naziv) {
                        that.zahtjevModel.status = that.statusiZahtjeva[i].id;
                        break;
                    }
                }
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiStatuseZahtjevaZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        odrediDefaultniStatus: function odrediDefaultniStatus() {

            for (var i = 0; i < this.statusiZahtjeva.length; i++) {

                if (this.statusiZahtjeva[i].default == true) {
                    this.zahtjevModel.status = this.statusiZahtjeva[i].id;
                    break;
                }
            }
        },
        ucitajDijeloveProjekta: function ucitajDijeloveProjekta(id) {
            var _this5 = this;

            var success = function success(response) {

                var that = _this5;
                that.dijeloviProjekta = response.body;

                for (var i = 0; i < that.dijeloviProjekta.length; i++) {

                    if (that.dijeloviProjekta[i].naziv == that.zahtjevModel.dioProjekta) {
                        that.zahtjevModel.dioProjekta = that.dijeloviProjekta[i].id;
                        break;
                    }
                }

                var model = that.zahtjevModel;
                that.ucitajPostojecuKategorijuZahtjeva(model);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajPostojecuKategorijuZahtjeva: function ucitajPostojecuKategorijuZahtjeva(model) {
            var _this6 = this;

            var success = function success(response) {

                var that = _this6;
                that.kategorijeZahtjeva = response.body;

                for (var j = 0; j < that.kategorijeZahtjeva.length; j++) {

                    if (that.kategorijeZahtjeva[j].naziv == model.zahtjevKategorija) {
                        that.zahtjevModel.kategorija = that.kategorijeZahtjeva[j].id;

                        break;
                    }
                }

                that.ucitajSupportKorisnikeZaZahtjevKategoriju(that.zahtjevModel.kategorija);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };
            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: model.dioProjekta
            });

            promise.then(success, error);
        },
        ucitajKategorijeZahtjeva: function ucitajKategorijeZahtjeva(id) {
            var _this7 = this;

            var success = function success(response) {

                var that = _this7;
                that.kategorijeZahtjeva = response.body;
                for (var i = 0; i < that.kategorijeZahtjeva.length; i++) {
                    {
                        that.zahtjevModel.kategorija = that.kategorijeZahtjeva[i].id;
                        break;
                    }
                }
                that.zahtjevModel.dodijeljeniKorisnikIme = null;
                that.ucitajSupportKorisnikeZaZahtjevKategoriju(that.zahtjevModel.kategorija);
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: id
            });

            promise.then(success, error);
        },
        odustani: function odustani() {
            this.$emit("dialogEditZahtjeva", false);
        },
        onSubmit: function onSubmit() {
            var _this8 = this;

            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);

            if (this.valid) {
                var that = this;

                var success = function success(model) {
                    _this8.$toast.success("Uspješno ažuriran zahtjev.");


                    _this8.$emit("dialogEditZahtjeva", true);
                };
                var error = function error(poruka) {
                    that.$toast.error(poruka.body);
                };

                var zahtjev = {};
                zahtjev.naziv = that.zahtjevModel.naziv;
                zahtjev.opis = that.zahtjevModel.opis;
                zahtjev.zahtjevStatusId = that.zahtjevModel.status;
                zahtjev.zahtjevKategorijaId = that.zahtjevModel.kategorija;
                zahtjev.zahtjevTipId = that.zahtjevModel.tip;
                zahtjev.zahtjevPrioritetId = that.zahtjevModel.prioritet;
                zahtjev.dodijeljeniKorisnikIme = that.zahtjevModel.dodijeljeniKorisnikIme;

                var promise = (0, _resources.ZahtjevResource)().azurirajZahtjev({
                    zahtjevId: that.childZahtjevId
                }, zahtjev);

                promise.then(success, error);
            }
        },
        ucitajSupportKorisnikeZaZahtjevKategoriju: function ucitajSupportKorisnikeZaZahtjevKategoriju(id) {
            var _this9 = this;

            var that = this;

            var success = function success(response) {
                that.supportKorisnici = response.body;
            };
            var error = function error(poruka) {
                _this9.$toast.error(poruka.body);
            };

            var promise = (0, _resources.KorisnikResource)().vratiSupportKorisnikeZaZahtjevKategoriju({
                zahtjevKategorijaId: id
            });
            promise.then(success, error);
        },
        ucitajSupportKorisnike: function ucitajSupportKorisnike(id) {
            this.zahtjevModel.dodijeljeniKorisnikIme = null;
            this.ucitajSupportKorisnikeZaZahtjevKategoriju(id);
        }
    },
    resolve: {}
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitanZahtjev)?[_c('material-card',{attrs:{"title":"Izmijeni zahtjev","color":"primary"}},[_c('v-card-text',[_c('v-form',{ref:"form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-text-field',{staticClass:"required",attrs:{"counter":128,"label":"Naziv","rules":_vm.rules.nazivZahtjeva,"required":""},model:{value:(_vm.zahtjevModel.naziv),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "naziv", $$v)},expression:"zahtjevModel.naziv"}}),_vm._v(" "),_c('v-textarea',{staticClass:"required",attrs:{"multi-line":"","label":"Opis","rules":_vm.rules.opisZahtjeva,"required":""},model:{value:(_vm.zahtjevModel.opis),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "opis", $$v)},expression:"zahtjevModel.opis"}}),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('span',[_vm._v("Zahtjev kreirao: ")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.zahtjevModel.createdBy))])]),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('span',[_vm._v("Datum kreiranja: ")]),_vm._v(" "),_c('span',[_vm._v(" "+_vm._s(' '+_vm.zahtjevModel.datumKreiranja.substring(8,10) + '. ' + _vm.zahtjevModel.datumKreiranja.substring(5,7)+ '. '+_vm.zahtjevModel.datumKreiranja.substring(0,4) + '. '+_vm.zahtjevModel.datumKreiranja.substring(11,19)))])]),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('span',[_vm._v("Datum izmjene: ")]),_vm._v(" "),_c('span',[_vm._v(" "+_vm._s(' '+_vm.zahtjevModel.datumIzmjene.substring(8,10) + '. ' + _vm.zahtjevModel.datumIzmjene.substring(5,7)+ '. '+_vm.zahtjevModel.datumIzmjene.substring(0,4) + '. '+_vm.zahtjevModel.datumIzmjene.substring(11,19)))])]),_vm._v(" "),_c('span'),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.dijeloviProjekta,"item-text":"naziv","item-value":"id","label":"Dio projekta","bottom":""},on:{"input":_vm.ucitajKategorijeZahtjeva},model:{value:(_vm.zahtjevModel.dioProjekta),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "dioProjekta", $$v)},expression:"zahtjevModel.dioProjekta"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.kategorijeZahtjeva,"item-text":"naziv","item-value":"id","label":"Kategorija zahtjeva","bottom":""},on:{"input":_vm.ucitajSupportKorisnike},model:{value:(_vm.zahtjevModel.kategorija),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "kategorija", $$v)},expression:"zahtjevModel.kategorija"}})],1),_vm._v(" "),_c('span'),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.tipoviZahtjeva,"item-text":"naziv","item-value":"id","label":"Tip zahtjeva","bottom":""},model:{value:(_vm.zahtjevModel.tip),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "tip", $$v)},expression:"zahtjevModel.tip"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.statusiZahtjeva,"item-text":"naziv","item-value":"id","label":"Status zahtjeva","bottom":""},model:{value:(_vm.zahtjevModel.status),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "status", $$v)},expression:"zahtjevModel.status"}})],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","items":_vm.prioritetiZahtjeva,"item-text":"naziv","item-value":"id","label":"Prioritet zahtjeva","bottom":""},model:{value:(_vm.zahtjevModel.prioritet),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "prioritet", $$v)},expression:"zahtjevModel.prioritet"}})],1),_vm._v(" "),(_vm.imaPravo('zahtjev_zahtjev_edit_dodijeljeni_korisnik'))?_c('v-flex',{attrs:{"xs12":"","sm4":"","md4":""}},[_c('v-select',{staticClass:"required",attrs:{"required":"","clearable":"","items":_vm.supportKorisnici,"item-text":"korisnickoIme","item-value":"korisnickoIme","label":"Dodijeljeni korisnik","bottom":""},model:{value:(_vm.zahtjevModel.dodijeljeniKorisnikIme),callback:function ($$v) {_vm.$set(_vm.zahtjevModel, "dodijeljeniKorisnikIme", $$v)},expression:"zahtjevModel.dodijeljeniKorisnikIme"}})],1):_vm._e(),_vm._v(" "),_c('div',{staticClass:"text-xl-right my-3"},[_c('v-btn',{attrs:{"color":"tertiary"},on:{"click":_vm.odustani}},[_vm._v("Odustani ")]),_vm._v(" "),_c('v-btn',{attrs:{"color":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("Snimi")])],1)],1)],1)],1)]:_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.helpTipDialogTitle,"content":_vm.helpTipDialogContent},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/zahtjev/komentar/list.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _config = require('config');

var _config2 = _interopRequireDefault(_config);

var _uploadMixin = require('helpers/upload-mixin');

var _uploadMixin2 = _interopRequireDefault(_uploadMixin);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _upit = require('../../components/upit');

var _upit2 = _interopRequireDefault(_upit);

var _vue2Dropzone = require('vue2-dropzone');

var _vue2Dropzone2 = _interopRequireDefault(_vue2Dropzone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaKomentaraZahtjev',
    components: {
        Upit: _upit2.default
    },
    mixins: [_helpTipDialogMixin2.default, _uploadMixin2.default],
    props: {
        poruka: {
            type: String,
            default: 'Dodaj fajl u prilog komentara'
        },
        zahtjevId: Number
    },

    data: function data() {
        return {

            acceptedFiles: {
                type: String,
                default: ".pdf" },
            dropzoneOptionsOsnovno: {
                maxFiles: 1,
                queueLimit: 1,
                maxFileSize: 30,
                acceptedFiles: ".pdf,.txt,.jpg,.png,.jpeg,.doc,.docx,.xls,xlsx,.PDF,.TXT,.JPG,.PNG,.JPEG,.DOC,.DOCX,.XLS,.XLSX",
                addRemoveLinks: true,
                thumbnailWidth: 300,
                dictDefaultMessage: '<i aria-hidden="true" class="material-icons icon">file_upload</i><br />' + this.poruka
            },
            onFocus: false,
            valid: false,
            listaKomentara: [],
            model: {
                komentar: null,
                dokumentId: null
            },
            komentarLengthRules: [function (v) {
                return !!v || 'Ne možete poslati prazan komentar';
            }, function (v) {
                return v && v.length <= 2000 || 'Komentar ne može biti veći od 200 karaktera';
            }]

        };
    },
    created: function created() {},
    mounted: function mounted() {
        this.ucitajKomentareZahtjeva();
    },


    methods: {
        snimiObjekt: function snimiObjekt(model) {

            this.result = model.result;
            this.uspjesanUploadSlike = true;
        },
        onSubmit: function onSubmit() {
            var _this = this;

            var that = this;
            this.$refs.form.validate();
            this.focusInvalidInput(this.$refs.form);
            if (this.valid) {
                var success = function success(model) {
                    that.$toast.success("Uspješno dodano.");
                    _this.$refs.dropzone.removeAllFiles();
                    that.removeAllFiles();

                    that.$refs.form.reset();

                    that.ucitajKomentareZahtjeva();
                };
                var error = function error() {
                    _this.$toast.error('Nije uspjelo slanje komentara.');
                };
                var promise = (0, _resources.ZahtjevResource)().dodajKomentar({
                    zahtjevId: this.zahtjevId
                }, this.model);
                promise.then(success, error);
            }
        },
        ucitajKomentareZahtjeva: function ucitajKomentareZahtjeva() {
            var _this2 = this;

            var success = function success(response) {

                var that = _this2;
                that.listaKomentara = response.body.items;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ZahtjevResource)().vratiKomentareZahtjeva({
                zahtjevId: this.zahtjevId
            });

            promise.then(success, error);
        },
        removeAllFiles: function removeAllFiles() {
            this.model.dokumentId = null;
        }
    }

};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"color":"primary"}},[_c('br'),_vm._v(" "),_c('v-form',{ref:"form",staticClass:"upis-komentar-form",model:{value:(_vm.valid),callback:function ($$v) {_vm.valid=$$v},expression:"valid"}},[_c('v-textarea',{staticClass:"required",attrs:{"counter":2000,"label":"Komentar","rules":_vm.komentarLengthRules,"required":"","outline":""},model:{value:(_vm.model.komentar),callback:function ($$v) {_vm.$set(_vm.model, "komentar", $$v)},expression:"model.komentar"}}),_vm._v(" "),_c('v-layout',{attrs:{"pb-3":"","row":"","justify-space-around":""}},[_c('v-flex',[_c('vue-dropzone',{ref:"dropzone",attrs:{"id":"upload-file-komentar","options":_vm.dropzoneOptions},on:{"vdropzone-removed-file":_vm.removeAllFiles,"vdropzone-success":function (file, response) { return _vm.snimiObjekt(response); },"vdropzone-sending":function (file, xhr, formData) { return _vm.addParam(formData, _vm.model, _vm.vrstaDokumenta); }}},[_c('div',{staticClass:"dropzone-custom-content"},[_c('h3',{staticClass:"dropzone-custom-title"},[_vm._v("Drag and drop to upload content!")]),_vm._v(" "),_c('div',{staticClass:"text-xs-center"},[_c('i',{staticClass:"material-icons icon",attrs:{"aria-hidden":"true"}},[_vm._v("file_upload")]),_vm._v(" "),_c('p',[_vm._v(" Upload ")])])])])],1)],1),_vm._v(" "),_c('v-flex',{attrs:{"xs12":"","sm12":"","md12":"","lg12":"","text-xs-right":""}},[_c('v-btn',{attrs:{"type":"button"},on:{"click":_vm.onSubmit}},[_vm._v("Snimi")])],1)],1),_vm._v(" "),_c('h4',[_vm._v("Komentari: ")]),_vm._v(" "),_c('v-data-table',{attrs:{"no-data-text":"Nema komentara","items":_vm.listaKomentara,"hide-actions":true},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('tr',[_c('div',[_c('span',{staticClass:"text-boldiran"},[_vm._v(_vm._s(props.item.createdBy))]),_vm._v(" "),_c('span',{staticClass:"text-datum"},[_vm._v(_vm._s(props.item.datumKreiranja.substring(8,10) + '.' + props.item.datumKreiranja.substring(5,7)+ '.'+props.item.datumKreiranja.substring(0,4) + '. ' + props.item.datumKreiranja.substring(11,19)))]),_vm._v(" "),_c('br'),_vm._v(" "),_c('span',[_vm._v("\r\n                            "+_vm._s(props.item.komentar)+"\r\n                        ")])]),_vm._v(" "),_c('br')]),_vm._v(" "),(props.item.priloziKomentara.length!=0)?_c('tr',[_c('td',[_vm._v("Prilozi komentara:"),_c('a',{on:{"click":function($event){return _vm.preuzmiDokument(props.item.priloziKomentara[0].id)}}},[_vm._v(" "+_vm._s(props.item.priloziKomentara[0].naziv)+"\r\n                        ")])])]):_vm._e()]}}])}),_vm._v(" "),_c('br')],1)],1)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/zahtjev/list-draggable.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _dodavanje = require('../zahtjev/dodavanje.vue');

var _dodavanje2 = _interopRequireDefault(_dodavanje);

var _pregled = require('../zahtjev/pregled.vue');

var _pregled2 = _interopRequireDefault(_pregled);

var _list = require('./komentar/list.vue');

var _list2 = _interopRequireDefault(_list);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaZahtjevaDraggable',
    mixins: [_helpTipDialogMixin2.default],
    components: {
        DodavanjeZahtjeva: _dodavanje2.default,
        PregledZahtjev: _pregled2.default
    },
    props: ['listaZahtjeva', 'omogucenoDodavanjeIFiltriranje', 'naslov', 'headersiZaPrikaz', 'omogucenHeader', 'sakrijPrikazPaginacije'],

    data: function data() {

        return {
            onemogucenoAzuriranje: false,
            duzinaNazivaOpisa: 45,
            list: [],
            activeHelpTip: false,
            model: {
                items: []
            },
            totalItems: 0,
            loading: false,
            projekti: [],
            zahtjevStatusi: [],
            dialogPregledZahtjeva: false,
            pregledZahtjevaId: null,
            ucitaniZahtjevi: false,
            boja1: 'red',
            boja2: 'blue',
            boja3: 'greeen',

            inputs: {
                naziv: null,
                opis: null,
                statusId: null,
                projekatId: null,
                prethodniBrojDana: 7,
                sve: false,
                toDo: true,
                inProgress: true,
                done: true
            },
            projekatInputs: {
                page: 1,
                count: 10,
                sve: true
            },
            identity: _identity2.default,
            dialogDodajZahtjev: false,
            prethodniDani: [],
            red: null,
            kolona: null
        };
    },
    created: function created() {

        this.inputs.sve = true;

        if (!_identity2.default.imaPravo("zahtjev_zahtjev_edit_status")) this.onemogucenoAzuriranje = true;

        this.ucitajProjekte();
        this.inicijalizacijaNizaPrethodnihDana();
    },
    mounted: function mounted() {},


    methods: {
        checkMove: function checkMove() {
            if (_identity2.default.imaPravo("zahtjev_zahtjev_edit_status")) return true;
            return false;
        },
        azurirajStatusZahtjeva: function azurirajStatusZahtjeva(card, index) {
            var _this = this;

            if (card.added != null) {

                var that = this;
                var success = function success(response) {
                    _this.$toast.success('Uspješno ažuriranje statusa');
                };
                var error = function error(poruka) {
                    _this.$toast.error(poruka.body);
                    return false;
                };
                var promise = (0, _resources.ZahtjevResource)().azurirajStatusZahtjeva({
                    zahtjevId: card.added.element.id
                }, {
                    zahtjevStatusId: this.zahtjevStatusi[index].id
                });
                promise.then(success, error);
            }
        },
        ucitajProjekte: function ucitajProjekte() {
            var _this2 = this;

            var that = this;
            that.loading = true;
            var success = function success(response) {
                that.projekatInputs.sve = false;
                that.projekti = response.body.items;
                if (that.projekti.length != 0) {
                    that.inputs.projekatId = that.projekti[0].id;
                    that.ucitajStatuseZahtjeva(that.inputs.projekatId);
                }
            };
            var error = function error() {
                _this2.$toast.error('Nisu ucitani projekti.');
            };
            that.projekatInputs.sve = true;
            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(that.projekatInputs);
            promise.then(success, error);
        },
        ucitajIRasporediZahtjeve: function ucitajIRasporediZahtjeve() {
            var that = this;
            that.ucitaniZahtjevi = false;

            var success = function success(model) {
                that.model = model.body;
                that.totalItems = model.body.total;

                that.ograniciDuzinuNaziva();
                that.rasporediZahtjevePoStatusu();
                that.ucitaniZahtjevi = true;

                that.loading = false;
            };

            var error = function error() {
                that.$toast.error("Filtriranje nije uspješno");
            };

            var promise = (0, _resources.ZahtjevResource)().vratiSveZahtjeve(this.inputs);

            promise.then(success, error);
        },
        otvoriDialogDodajZahtjev: function otvoriDialogDodajZahtjev() {
            this.dialogDodajZahtjev = true;
            var projekatId = this.$route.params.projekatId;
            this.$emit("projekat", projekatId);
        },
        zatvoriDialogDodajZahtjev: function zatvoriDialogDodajZahtjev(dialogDodajZahtjev) {
            this.dialogDodajZahtjev = dialogDodajZahtjev;
        },
        ucitajStatuseZahtjeva: function ucitajStatuseZahtjeva(id) {
            var _this3 = this;

            var success = function success(response) {

                var that = _this3;
                that.zahtjevStatusi = response.body;
                that.ucitajIRasporediZahtjeve();
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiStatuseZahtjevaZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        otvoriZahtjev: function otvoriZahtjev(id) {
            this.pregledZahtjevaId = id;
            this.dialogPregledZahtjeva = true;
        },
        rasporediZahtjevePoStatusu: function rasporediZahtjevePoStatusu() {
            var zahtjevStatusiLength = this.zahtjevStatusi.length;
            for (var a = 0; a < zahtjevStatusiLength; a++) {
                this.list[a] = [];
            }

            var modelItemsLength = this.model.items.length;
            for (var j = 0; j < zahtjevStatusiLength; j++) {

                for (var i = 0; i < modelItemsLength; i++) {

                    if (this.model.items[i].zahtjevStatus == this.zahtjevStatusi[j].naziv) {
                        this.list[j].push(this.model.items[i]);
                    }
                }
            }
        },
        ograniciDuzinuNaziva: function ograniciDuzinuNaziva() {
            var modelItemsLength = this.model.items.length;
            for (var i = 0; i < modelItemsLength; i++) {
                if (this.model.items[i].naziv.length > this.duzinaNazivaOpisa) {
                    this.model.items[i].naziv = this.model.items[i].naziv.slice(0, this.duzinaNazivaOpisa - 3) + "...";
                }
            }
        },
        ograniciDuzinuOpisa: function ograniciDuzinuOpisa() {
            var modelItemsLength = this.model.items.length;
            for (var j = 0; j < modelItemsLength; j++) {
                if (this.model.items[j].opis.length > this.duzinaNazivaOpisa) {
                    this.model.items[j].opis = this.model.items[j].opis.slice(0, this.duzinaNazivaOpisa - 3) + "...";
                }
            }
        },
        inicijalizacijaNizaPrethodnihDana: function inicijalizacijaNizaPrethodnihDana() {
            for (var i = 1; i <= 365; i++) {
                this.prethodniDani.push(i);
            }
        },
        azuriranjeZahtjeva: function azuriranjeZahtjeva(zahtjev, azuriran) {
            var _this4 = this;

            this.dialogPregledZahtjeva = false;
            if (azuriran) {

                var red = null;

                for (var i = 0; i < this.zahtjevStatusi.length; i++) {
                    var foundIndex = this.list[i].findIndex(function (x) {
                        return x.id == _this4.pregledZahtjevaId;
                    });
                    if (foundIndex != -1) {
                        red = i;
                        break;
                    }
                }

                if (zahtjev != null) {

                    this.list[red][foundIndex] = zahtjev;
                    if (this.zahtjevStatusi[red].naziv != zahtjev.zahtjevStatus) {
                        this.list[red].splice(foundIndex, 1);
                    }
                    var indexZahtjevStatus = this.zahtjevStatusi.findIndex(function (x) {
                        return x.naziv == zahtjev.zahtjevStatus.naziv;
                    });

                    if (indexZahtjevStatus != -1) {

                        if (zahtjev.naziv.length > this.duzinaNazivaOpisa) {
                            zahtjev.naziv = zahtjev.naziv.slice(0, this.duzinaNazivaOpisa - 3) + "...";
                        }
                        this.list[indexZahtjevStatus].push(zahtjev);
                    }
                } else {
                    this.list[red].splice(foundIndex, 1);
                }
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Zadaci")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":""},on:{"click":function($event){return _vm.otvoriDialogDodajZahtjev()}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                        DODAJ\r\n                    ")],1)],1)],1)],1),_vm._v(" "),(_vm.dialogDodajZahtjev)?_c('dodavanje-zahtjeva',{on:{"dialogDodajZahtjev":_vm.zatvoriDialogDodajZahtjev}}):_vm._e(),_vm._v(" "),_c('v-layout',{attrs:{"row":""}},[_c('v-flex',{attrs:{"xs6":"","md4":"","lg3":""}},[_c('v-card-text',{staticStyle:{"max-width":"75%"}},[_c('v-select',{attrs:{"items":_vm.projekti,"item-text":"naziv","label":"Projekat","item-value":"id","hide-details":"","bottom":""},on:{"input":_vm.ucitajStatuseZahtjeva},model:{value:(_vm.inputs.projekatId),callback:function ($$v) {_vm.$set(_vm.inputs, "projekatId", $$v)},expression:"inputs.projekatId"}})],1)],1),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right",attrs:{"xs6":"","md8":"","lg9":""}},[_c('v-card-text',{staticClass:"text-xs-right prethodni-broj-dana"},[_c('v-autocomplete',{attrs:{"placeholder":"Svi zahtjevi","clearable":"","filled":"true","items":_vm.prethodniDani,"item-text":"naziv","item-value":"brojDana","label":"Zahtjevi za prethodni broj dana","hide-details":"","bottom":""},on:{"input":_vm.ucitajIRasporediZahtjeve},model:{value:(_vm.inputs.prethodniBrojDana),callback:function ($$v) {_vm.$set(_vm.inputs, "prethodniBrojDana", $$v)},expression:"inputs.prethodniBrojDana"}})],1)],1)],1),_vm._v(" "),_c('v-container',{staticClass:"about",attrs:{"fill-height":"","fluid":"","grid-list-md":"","mt-0":""}},[_c('v-layout',{attrs:{"column":"","fill-height":""}},[_c('v-layout',{attrs:{"row":"","fill-height":""}},_vm._l((_vm.zahtjevStatusi),function(status,index){return _c('v-flex',{staticClass:"kolona zahtjev-statusi",attrs:{"elevation":6}},[(status.oznaka =='0')?_c('v-flex',{staticClass:"text-xs-center bojastatus"},[_c('h6',[_vm._v(_vm._s(status.naziv))])]):(status.oznaka =='1')?_c('v-flex',{staticClass:"text-xs-center bojastatus1"},[_c('h6',[_vm._v(_vm._s(status.naziv))])]):(status.oznaka =='2')?_c('v-flex',{staticClass:"text-xs-center bojastatus2"},[_c('h6',[_vm._v(_vm._s(status.naziv))])]):_vm._e(),_vm._v(" "),_c('v-divider'),_vm._v(" "),(_vm.ucitaniZahtjevi)?_c('draggable',{staticClass:"draggable-area",attrs:{"ghost-class":"ghost","move":_vm.checkMove,"id":index,"options":{group: "zahtjevi"},"animation":"200","disabled":_vm.onemogucenoAzuriranje},on:{"change":function($event){return _vm.azurirajStatusZahtjeva($event,index)}},model:{value:(_vm.list[index]),callback:function ($$v) {_vm.$set(_vm.list, index, $$v)},expression:"list[index]"}},_vm._l((_vm.list[index]),function(element,index){return _c('v-flex',{staticClass:"draggable-item",on:{"click":function($event){return _vm.otvoriZahtjev(element.id)}}},[_c('v-card',{staticClass:"task",attrs:{"dark":""}},[_c('v-card-text',[_vm._v("\r\n                                        "+_vm._s(element.naziv)+"\r\n                                    ")])],1)],1)}),1):_vm._e()],1)}),1)],1)],1)],1),_vm._v(" "),(_vm.dialogPregledZahtjeva)?_c('pregled-zahtjev',{attrs:{"zahtjev-id":_vm.pregledZahtjevaId},on:{"azuriraniZahtjev":_vm.azuriranjeZahtjeva}}):_vm._e()],1)}
__vue__options__.staticRenderFns = []
__vue__options__._scopeId = "data-v-6ff7b43e"

});

;require.register("modules/home/zahtjev/list.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _paginationMixin = require('helpers/pagination-mixin');

var _paginationMixin2 = _interopRequireDefault(_paginationMixin);

var _dodavanje = require('../zahtjev/dodavanje.vue');

var _dodavanje2 = _interopRequireDefault(_dodavanje);

var _pregled = require('../zahtjev/pregled.vue');

var _pregled2 = _interopRequireDefault(_pregled);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'ListaZahtjevaProjekat',
    mixins: [_paginationMixin2.default, _helpTipDialogMixin2.default],
    components: {
        DodavanjeZahtjeva: _dodavanje2.default,
        PregledZahtjev: _pregled2.default
    },
    props: ['listaZahtjeva', 'omogucenoDodavanjeIFiltriranje', 'naslov', 'headersiZaPrikaz', 'omogucenHeader', 'sakrijPrikazPaginacije'],

    data: function data() {

        return {
            duzinaNazivaOpisa: 30,
            list: [],
            childSakrijPrikazPaginacije: this.sakrijPrikazPaginacije,
            childOmogucenoDodavanjeIFiltriranje: this.omogucenoDodavanjeIFiltriranje,
            childOmogucenHeader: this.omogucenHeader,
            childHeadersiZaPrikaz: [],
            prikazKategorije: false,
            prikazStatusa: false,
            prikazCreatedBy: false,
            prikazPodprojekat: false,
            childNaslov: this.naslov,
            activeHelpTip: false,
            model: {
                items: []
            },
            totalItems: 0,
            filterMenu: false,
            filtrirano: false,
            loading: false,
            projekti: [],
            dijeloviProjekta: [],
            zahtjevKategorije: [],
            zahtjevTipovi: [],
            zahtjevPrioriteti: [],
            zahtjevStatusi: [],

            headers: [{
                text: 'Naziv',
                align: 'left',
                sortable: false,
                value: 'naziv',
                prikaz: true
            }, {
                text: 'Opis',
                align: 'left',
                sortable: false,
                value: 'opis',
                prikaz: true

            }, {
                text: 'Tip',
                align: 'left',
                sortable: false,
                value: 'tip',
                prikaz: true

            }, {
                text: 'Kategorija',
                align: 'left',
                sortable: false,
                value: 'kategorija',
                prikaz: true

            }, {
                text: 'Prioritet',
                align: 'left',
                sortable: false,
                value: 'prioritet',
                prikaz: true

            }, {
                text: 'Status',
                align: 'left',
                sortable: false,
                value: 'status',
                prikaz: true
            }, {
                text: 'Datum kreiranja',
                align: 'left',
                sortable: false,
                value: 'datumKreiranja',
                prikaz: true
            }, {
                text: 'Kreirao',
                align: 'left',
                sortable: false,
                value: 'createdBy',
                prikaz: true

            }, {
                text: 'Projekat',
                align: 'left',
                sortable: false,
                value: 'projekat',
                prikaz: true
            }, {
                text: 'Podprojekat',
                align: 'left',
                sortable: false,
                value: 'dioProjekta',
                prikaz: true

            }, {
                text: '',
                align: 'left',
                sortable: false,
                value: '',
                prikaz: true
            }],
            inputs: {
                naziv: null,
                opis: null,
                dioProjektaId: null,
                statusId: null,
                prioritetId: null,
                tipId: null,
                kategorijaId: null,
                korisnik: null,
                page: 1,
                count: 10,
                projekatId: null,
                prethodniBrojDana: null,
                sve: false,
                toDo: true,
                inProgress: true,
                done: true
            },
            projekatInputs: {
                page: 1,
                count: 10,
                sve: true
            },
            identity: _identity2.default,
            dialogDodajZahtjev: false,
            dialogPregledZahtjeva: false

        };
    },
    created: function created() {
        this.pagination.rowsPerPage = 15;


        if (this.naslov == null) this.childNaslov = "Zahtjevi";

        if (this.omogucenoDodavanjeIFiltriranje == null) this.childOmogucenoDodavanjeIFiltriranje = true;

        if (this.omogucenHeader == null) this.childOmogucenHeader = true;

        if (this.childSakrijPrikazPaginacije == null) this.childSakrijPrikazPaginacije = false;

        if (this.headersiZaPrikaz == null) {
            this.childHeadersiZaPrikaz = this.headers;
        } else {
            this.odabirHeadersaZaPrikaz();
        }

        this.inputs.projekatId = null;
    },
    mounted: function mounted() {

        if (this.inputs.page) {
            this.pagination.page = this.inputs.page;
        }
        if (this.inputs.count) {
            this.pagination.count = this.inputs.count;
        }
    },


    methods: {
        otvoriFiltriranje: function otvoriFiltriranje() {
            this.ucitajProjekte();
        },
        filtriraj: function filtriraj() {
            this.filterMenu = false;
            this.resetujPaginaciju();
        },
        ponistiFilter: function ponistiFilter() {
            this.inputs.naziv = "";
            this.inputs.opis = "";
            this.inputs.dioProjektaId = null;
            this.inputs.statusId = null;
            this.inputs.prioritetId = null;
            this.inputs.tipId = null;
            this.inputs.kategorijaId = null;
            this.inputs.createdBy = "";
            this.inputs.projekatId = null;

            this.inputs.toDo = true;
            this.inputs.inProgress = true;
            this.inputs.done = false;

            this.dijeloviProjekta = [];
            this.zahtjevKategorije = [];
            this.zahtjevTipovi = [];
            this.zahtjevPrioriteti = [];
            this.zahtjevStatusi = [];

            this.filterMenu = false;
            this.filtrirano = false;
            this.resetujPaginaciju();
        },
        ucitajKonfiguracijuProjekta: function ucitajKonfiguracijuProjekta(id) {
            this.zahtjevKategorije = [];

            this.ucitajZahtjevTipove(id);
            this.ucitajPrioriteteZahtjeva(id);
            this.ucitajStatuseZahtjeva(id);
            this.ucitajDijeloveProjekta(id);
        },
        ucitajProjekte: function ucitajProjekte() {
            var _this = this;

            var that = this;
            that.loading = true;
            var success = function success(response) {
                that.projekatInputs.sve = false;
                that.projekti = response.body.items;
            };
            var error = function error() {
                _this.$toast.error('Nisu ucitani projekti.');
            };
            that.projekatInputs.sve = true;
            var promise = (0, _resources.ProjekatResource)().vratiSveProjekte(that.projekatInputs);
            promise.then(success, error);
        },
        updateData: function updateData() {
            var _this2 = this;

            var that = this;

            if (that.listaZahtjeva == null || !that.listaZahtjeva) {
                this.osvjeziQuery(this.inputs);

                var success = function success(model) {
                    console.log(_this2.inputs, "test");
                    that.model = model.body;
                    that.totalItems = model.body.total;
                    that.ograniciDuzinuNazivaIOpisa();
                    that.loading = false;
                    if (that.inputs.projekatId) that.ucitajStatuseZahtjeva(that.inputs.projekatId);
                };

                var error = function error() {
                    that.$toast.error("Filtriranje nije uspješno");
                };

                var promise = (0, _resources.ZahtjevResource)().vratiSveZahtjeve(this.inputs);

                promise.then(success, error);
            } else {
                that.model.items = that.listaZahtjeva;

                that.ograniciDuzinuNazivaIOpisa();
            }
        },
        otvoriDialogDodajZahtjev: function otvoriDialogDodajZahtjev() {
            this.dialogDodajZahtjev = true;
            var projekatId = this.$route.params.projekatId;
            this.$emit("projekat", projekatId);
        },
        zatvoriDialogDodajZahtjev: function zatvoriDialogDodajZahtjev(dialogDodajZahtjev) {
            this.dialogDodajZahtjev = dialogDodajZahtjev;
        },
        ucitajZahtjevTipove: function ucitajZahtjevTipove(id) {
            var _this3 = this;

            var success = function success(response) {

                var that = _this3;
                that.zahtjevTipovi = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiTipoveZahtjevaZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajPrioriteteZahtjeva: function ucitajPrioriteteZahtjeva(id) {
            var _this4 = this;

            var success = function success(response) {

                var that = _this4;
                that.zahtjevPrioriteti = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevPrioriteteZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajStatuseZahtjeva: function ucitajStatuseZahtjeva(id) {
            var _this5 = this;

            console.log(id, "status");
            var success = function success(response) {

                var that = _this5;
                that.zahtjevStatusi = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiStatuseZahtjevaZaProjekat({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajDijeloveProjekta: function ucitajDijeloveProjekta(id) {
            var _this6 = this;

            var success = function success(response) {

                var that = _this6;
                that.dijeloviProjekta = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiDijeloveProjekta({
                projekatId: id
            });

            promise.then(success, error);
        },
        ucitajKategorijeZahtjeva: function ucitajKategorijeZahtjeva(id) {
            var _this7 = this;

            var success = function success(response) {

                var that = _this7;
                that.zahtjevKategorije = response.body;
            };
            var error = function error() {
                console.log("nije uspjelo");
            };

            var promise = (0, _resources.ProjekatResource)().vratiZahtjevKategorijeZaDioProjekta({
                dioProjektaId: id
            });

            promise.then(success, error);
        },
        otvoriZahtjev: function otvoriZahtjev(id) {
            this.pregledZahtjevaId = id;
            this.dialogPregledZahtjeva = true;
        },
        odabirHeadersaZaPrikaz: function odabirHeadersaZaPrikaz() {
            var niz = this.headersiZaPrikaz.split("");

            for (var i = 0; i < niz.length; i++) {

                if (niz[i] == 0) {
                    this.headers[i].prikaz = false;
                }
            }

            var n = [];
            for (var j = 0; j < this.headers.length; j++) {
                if (this.headers[j].prikaz == true) n.push(this.headers[j]);
            }
            this.childHeadersiZaPrikaz = n;
        },
        showColumn: function showColumn(col) {
            return this.headers.find(function (h) {
                return h.text === col;
            }).prikaz;
        },
        ograniciDuzinuNazivaIOpisa: function ograniciDuzinuNazivaIOpisa() {
            var modelItemLength = this.model.items.length;
            for (var i = 0; i < modelItemLength; i++) {
                if (this.model.items[i].naziv.length > this.duzinaNazivaOpisa) {
                    this.model.items[i].naziv = this.model.items[i].naziv.slice(0, this.duzinaNazivaOpisa - 3) + "...";
                }
            }
            for (var j = 0; j < modelItemLength; j++) {
                if (this.model.items[j].opis.length > this.duzinaNazivaOpisa) {
                    this.model.items[j].opis = this.model.items[j].opis.slice(0, this.duzinaNazivaOpisa - 3) + "...";
                }
            }
        },
        azuriranjeZahtjeva: function azuriranjeZahtjeva(zahtjev, azuriran) {

            this.dialogPregledZahtjeva = false;

            if (azuriran) {
                this.updateData();
            }
        }
    }
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[_c('material-card',{attrs:{"color":"primary"}},[(_vm.childOmogucenHeader)?_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Zadaci ")])]),_vm._v(" "),(_vm.childOmogucenoDodavanjeIFiltriranje)?_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-btn',{attrs:{"flat":""},on:{"click":function($event){return _vm.otvoriDialogDodajZahtjev()}}},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("add_circle")]),_vm._v("\r\n                DODAJ\r\n            ")],1),_vm._v(" "),_c('v-menu',{attrs:{"close-on-content-click":false,"content-class":"dropdown-menu","bottom":"","left":"","offset-y":"","transition":"slide-y-transition"},model:{value:(_vm.filterMenu),callback:function ($$v) {_vm.filterMenu=$$v},expression:"filterMenu"}},[_c('v-btn',{staticClass:"toolbar-btn",attrs:{"slot":"activator","flat":""},on:{"click":_vm.otvoriFiltriranje},slot:"activator"},[_c('v-icon',{staticClass:"mr-2"},[_vm._v("filter_list")]),_vm._v("Filtriraj\r\n                ")],1),_vm._v(" "),_c('v-card',[_c('v-card-title',[_c('div',{staticClass:"filter-title"},[_vm._v("\r\n                            Filtriraj po\r\n                        ")])]),_vm._v(" "),_c('v-form',{staticClass:"filter",on:{"submit":function($event){$event.preventDefault();return _vm.filtriraj()}}},[_c('v-card-text',{staticClass:"pt-0"},[_c('v-text-field',{attrs:{"label":"Naziv","hide-details":""},model:{value:(_vm.inputs.naziv),callback:function ($$v) {_vm.$set(_vm.inputs, "naziv", $$v)},expression:"inputs.naziv"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-text-field',{attrs:{"label":"Opis","hide-details":""},model:{value:(_vm.inputs.opis),callback:function ($$v) {_vm.$set(_vm.inputs, "opis", $$v)},expression:"inputs.opis"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-select',{attrs:{"items":_vm.projekti,"item-text":"naziv","label":"Projekat","item-value":"id","hide-details":"","bottom":""},on:{"input":_vm.ucitajKonfiguracijuProjekta},model:{value:(_vm.inputs.projekatId),callback:function ($$v) {_vm.$set(_vm.inputs, "projekatId", $$v)},expression:"inputs.projekatId"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-select',{attrs:{"items":_vm.dijeloviProjekta,"item-text":"naziv","label":"Dio projekta","item-value":"id","hide-details":"","bottom":""},on:{"input":_vm.ucitajKategorijeZahtjeva},model:{value:(_vm.inputs.dioProjektaId),callback:function ($$v) {_vm.$set(_vm.inputs, "dioProjektaId", $$v)},expression:"inputs.dioProjektaId"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-select',{attrs:{"clearable":"","items":_vm.zahtjevKategorije,"item-text":"naziv","label":"Kategorija zahtjeva","item-value":"id","hide-details":"","bottom":""},model:{value:(_vm.inputs.kategorijaId),callback:function ($$v) {_vm.$set(_vm.inputs, "kategorijaId", $$v)},expression:"inputs.kategorijaId"}}),_vm._v(" "),_c('strong',[_vm._v("*Potrebno odabrati dio projekta za pretragu po kategoriji")])],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-select',{attrs:{"clearable":"","items":_vm.zahtjevTipovi,"item-text":"naziv","label":"Tip zahtjeva","item-value":"id","hide-details":"","bottom":""},model:{value:(_vm.inputs.tipId),callback:function ($$v) {_vm.$set(_vm.inputs, "tipId", $$v)},expression:"inputs.tipId"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-select',{attrs:{"clearable":"","items":_vm.zahtjevPrioriteti,"item-text":"naziv","label":"Prioritet zahtjeva","item-value":"id","hide-details":"","bottom":""},model:{value:(_vm.inputs.prioritetId),callback:function ($$v) {_vm.$set(_vm.inputs, "prioritetId", $$v)},expression:"inputs.prioritetId"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-select',{attrs:{"clearable":"","items":_vm.zahtjevStatusi,"item-text":"naziv","label":"Status zahtjeva","item-value":"id","hide-details":"","bottom":""},model:{value:(_vm.inputs.statusId),callback:function ($$v) {_vm.$set(_vm.inputs, "statusId", $$v)},expression:"inputs.statusId"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('v-text-field',{attrs:{"label":"Korisnik","hide-details":""},model:{value:(_vm.inputs.createdBy),callback:function ($$v) {_vm.$set(_vm.inputs, "createdBy", $$v)},expression:"inputs.createdBy"}})],1),_vm._v(" "),_c('v-card-text',{staticClass:"pt-0"},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.inputs.toDo),expression:"inputs.toDo"}],attrs:{"type":"checkbox","id":"todo"},domProps:{"checked":Array.isArray(_vm.inputs.toDo)?_vm._i(_vm.inputs.toDo,null)>-1:(_vm.inputs.toDo)},on:{"change":function($event){var $$a=_vm.inputs.toDo,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.$set(_vm.inputs, "toDo", $$a.concat([$$v])))}else{$$i>-1&&(_vm.$set(_vm.inputs, "toDo", $$a.slice(0,$$i).concat($$a.slice($$i+1))))}}else{_vm.$set(_vm.inputs, "toDo", $$c)}}}}),_vm._v(" "),_c('label',{attrs:{"for":"todo"}},[_vm._v("Potrebno uraditi")]),_vm._v(" "),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.inputs.inProgress),expression:"inputs.inProgress"}],attrs:{"type":"checkbox","id":"inprogress"},domProps:{"checked":Array.isArray(_vm.inputs.inProgress)?_vm._i(_vm.inputs.inProgress,null)>-1:(_vm.inputs.inProgress)},on:{"change":function($event){var $$a=_vm.inputs.inProgress,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.$set(_vm.inputs, "inProgress", $$a.concat([$$v])))}else{$$i>-1&&(_vm.$set(_vm.inputs, "inProgress", $$a.slice(0,$$i).concat($$a.slice($$i+1))))}}else{_vm.$set(_vm.inputs, "inProgress", $$c)}}}}),_vm._v(" "),_c('label',{attrs:{"for":"inprogress"}},[_vm._v("Radi se")]),_vm._v(" "),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.inputs.done),expression:"inputs.done"}],attrs:{"type":"checkbox","id":"done"},domProps:{"checked":Array.isArray(_vm.inputs.done)?_vm._i(_vm.inputs.done,null)>-1:(_vm.inputs.done)},on:{"change":function($event){var $$a=_vm.inputs.done,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.$set(_vm.inputs, "done", $$a.concat([$$v])))}else{$$i>-1&&(_vm.$set(_vm.inputs, "done", $$a.slice(0,$$i).concat($$a.slice($$i+1))))}}else{_vm.$set(_vm.inputs, "done", $$c)}}}}),_vm._v(" "),_c('label',{attrs:{"for":"done"}},[_vm._v("Završen")])]),_vm._v(" "),_c('v-card-actions',[_c('v-spacer'),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary"},on:{"click":function($event){return _vm.ponistiFilter()}}},[_vm._v("Poništi")]),_vm._v(" "),_c('v-btn',{attrs:{"flat":"","color":"primary","type":"submit"}},[_vm._v("Filtriraj")])],1)],1)],1)],1)],1):_vm._e()],1)],1):_vm._e(),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"hide-actions":_vm.childSakrijPrikazPaginacije,"headers":_vm.childHeadersiZaPrikaz,"items":_vm.model.items,"pagination":_vm.pagination,"total-items":_vm.totalItems,"no-data-text":"Nema zadataka za prikaz.","loading":_vm.loading,"rows-per-page-items":_vm.rowsPerPageItems,"columns":_vm.columns,"rows":_vm.rows},on:{"update:pagination":function($event){_vm.pagination=$event}},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('tr',{on:{"click":function($event){return _vm.otvoriZahtjev(props.item.id)}}},[(_vm.showColumn('Naziv'))?_c('td',[_vm._v(_vm._s(props.item.naziv))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Opis'))?_c('td',{staticStyle:{"max-width":"250px"}},[_vm._v(_vm._s(props.item.opis))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Tip'))?_c('td',[_vm._v(_vm._s(props.item.zahtjevTip))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Kategorija'))?_c('td',[_vm._v(_vm._s(props.item.zahtjevKategorija))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Prioritet'))?_c('td',[_vm._v(_vm._s(props.item.zahtjevPrioritet))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Status'))?_c('td',[(props.item.zahtjevStatus === 'Potrebno uraditi')?_c('v-flex',{staticClass:"status-to-do"},[_vm._v(" "+_vm._s(props.item.zahtjevStatus))]):(props.item.zahtjevStatus === 'Radi se')?_c('v-flex',{staticClass:"status-in-progress"},[_vm._v(" "+_vm._s(props.item.zahtjevStatus))]):(props.item.zahtjevStatus === 'Završen')?_c('v-flex',{staticClass:"status-done"},[_vm._v(" "+_vm._s(props.item.zahtjevStatus))]):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.showColumn('Datum kreiranja'))?_c('td',[_vm._v(_vm._s(props.item.datumKreiranja.substring(8,10) + '.' + props.item.datumKreiranja.substring(5,7)+ '.'+props.item.datumKreiranja.substring(0,4) + '. ' + props.item.datumKreiranja.substring(11,19))+" ")]):_vm._e(),_vm._v(" "),(_vm.showColumn('Kreirao'))?_c('td',[_vm._v(_vm._s(props.item.createdBy))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Projekat'))?_c('td',[_vm._v(_vm._s(props.item.projekat))]):_vm._e(),_vm._v(" "),(_vm.showColumn('Podprojekat'))?_c('td',[_vm._v(_vm._s(props.item.dioProjekta))]):_vm._e(),_vm._v(" "),(_vm.showColumn(''))?_c('td',{staticClass:"text-xs-right"},[_c('v-menu',{attrs:{"open-on-hover":"","offset-y":""}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("settings")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{attrs:{"to":{ name: 'home.zahtjev.pregled', params: {zahtjevId: props.item.id }}}},[_c('v-list-tile-title',[_vm._v("Pregled zahtjeva")])],1)],1)],1)],1):_vm._e()])]}},{key:"pageText",fn:function(ref){
var pageStart = ref.pageStart;
var pageStop = ref.pageStop;
return [_vm._v("\r\n                    Od "+_vm._s(pageStart)+" do "+_vm._s(pageStop)+"\r\n                ")]}}])})],1),_vm._v(" "),(_vm.dialogPregledZahtjeva)?_c('pregled-zahtjev',{attrs:{"zahtjev-id":_vm.pregledZahtjevaId},on:{"azuriraniZahtjev":_vm.azuriranjeZahtjeva}}):_vm._e(),_vm._v(" "),(_vm.dialogDodajZahtjev)?_c('dodavanje-zahtjeva',{on:{"dialogDodajZahtjev":_vm.zatvoriDialogDodajZahtjev}}):_vm._e()],1)],1)}
__vue__options__.staticRenderFns = []
__vue__options__._scopeId = "data-v-8debc5be"

});

;require.register("modules/home/zahtjev/module.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _list = require('./list');

var _list2 = _interopRequireDefault(_list);

var _dodavanje = require('./dodavanje');

var _dodavanje2 = _interopRequireDefault(_dodavanje);

var _pregled = require('./pregled');

var _pregled2 = _interopRequireDefault(_pregled);

var _edit = require('./edit');

var _edit2 = _interopRequireDefault(_edit);

var _listDraggable = require('./list-draggable');

var _listDraggable2 = _interopRequireDefault(_listDraggable);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'Zahtjev',

    routes: [{
        path: 'list',
        name: 'home.zahtjev.list',
        component: _list2.default
    }, {
        path: 'list-draggable',
        name: 'home.zahtjev.list-draggable',
        component: _listDraggable2.default
    }, {
        path: 'dodavanje',
        name: 'home.zahtjev.dodavanje',
        component: _dodavanje2.default
    }, {
        path: 'edit/:zahtjevId',
        name: 'home.zahtjev.edit',
        component: _edit2.default
    }, {
        path: ':zahtjevId',
        name: 'home.zahtjev.pregled',
        component: _pregled2.default
    }]
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('router-view')}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/zahtjev/pregled.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _uploadMixin = require('helpers/upload-mixin');

var _uploadMixin2 = _interopRequireDefault(_uploadMixin);

var _list = require('./komentar/list.vue');

var _list2 = _interopRequireDefault(_list);

var _edit = require('./edit.vue');

var _edit2 = _interopRequireDefault(_edit);

var _izmjenaZahtjevaHistorija = require('./status-historija/izmjena-zahtjeva-historija');

var _izmjenaZahtjevaHistorija2 = _interopRequireDefault(_izmjenaZahtjevaHistorija);

var _obrisiModal = require('../components/obrisi-modal');

var _obrisiModal2 = _interopRequireDefault(_obrisiModal);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'PregledZahtjev',
    components: {
        ListaKomentaraZahtjev: _list2.default,
        EditZahtjev: _edit2.default,
        IzmjenaZahtjevaHistorija: _izmjenaZahtjevaHistorija2.default,
        ObrisiModal: _obrisiModal2.default
    },
    props: ['zahtjevId'],
    mixins: [_helpTipDialogMixin2.default, _uploadMixin2.default],
    data: function data() {
        return {
            childZahtjevId: Number(this.zahtjevId),
            activeHelpTip: false,
            resolved: null,
            identity: _identity2.default,
            zahtjevModel: null,
            ucitanZahtjev: false,
            prilog: null,
            dialogEditZahtjeva: false,
            azuriraniZahtjev: null,
            azuriran: false,
            dialogHistorijaStatusaZahtjeva: false,
            dialogBrisanjeZahtjeva: false
        };
    },

    watch: {
        $route: function $route(to, from) {
            this.ucitajZahtjev(to.params.zahtjevId);
        }
    },
    created: function created() {
        this.ucitajZahtjev();
    },

    methods: {
        ucitajZahtjev: function ucitajZahtjev() {
            var _this = this;

            var that = this;
            that.ucitanZahtjev = false;

            if (isNaN(that.$route.params.zahtjevId)) return;
            if (that.$route.params.zahtjevId != null) that.childZahtjevId = Number(that.$route.params.zahtjevId);

            var success = function success(response) {
                that.zahtjevModel = response.body;

                if (that.zahtjevModel == null) {
                    that.$emit("azuriraniZahtjev", that.azuriraniZahtjev);
                }
                that.prilagodiPrikazPotrosenogVremena();

                if (that.zahtjevModel.dodijeljeniKorisnikIme == null) that.zahtjevModel.dodijeljeniKorisnikIme = '-';

                that.ucitanZahtjev = true;

                that.otvoriKorisnikoveNotifikacijeZaZahtjev();
            };
            var error = function error(poruka) {
                _this.$emit("azuriraniZahtjev", null, true);

                _this.$toast.error(poruka.body);
            };

            var promise = (0, _resources.ZahtjevResource)().vratiZahtjev({
                zahtjevId: that.childZahtjevId
            });
            promise.then(success, error);
        },
        otvoriEditZahtjeva: function otvoriEditZahtjeva() {
            this.dialogEditZahtjeva = true;
        },
        prilagodiPrikazPotrosenogVremena: function prilagodiPrikazPotrosenogVremena() {

            var vrijeme = '';
            var brojCifaraDani = 0;

            for (var i = 0; i < this.zahtjevModel.potrosenoVrijeme.length; i++) {
                if (this.zahtjevModel.potrosenoVrijeme[i] == ':') {
                    brojCifaraDani = i;
                    break;
                }
            }
            if (!(this.zahtjevModel.potrosenoVrijeme.substr(0, 2) == '00')) {
                vrijeme = vrijeme + this.zahtjevModel.potrosenoVrijeme.substr(0, brojCifaraDani) + 'd ';
            }
            if (!(this.zahtjevModel.potrosenoVrijeme.substr(brojCifaraDani + 1, 2) == '00')) {
                vrijeme = vrijeme + this.zahtjevModel.potrosenoVrijeme.substr(brojCifaraDani + 1, 2) + 'h ';
            }
            if (!(this.zahtjevModel.potrosenoVrijeme.substr(brojCifaraDani + 4, 2) == '00')) {
                vrijeme = vrijeme + (this.zahtjevModel.potrosenoVrijeme.substr(brojCifaraDani + 4, 2) + 'm ');
            }
            if (!(this.zahtjevModel.potrosenoVrijeme.substr(brojCifaraDani + 7, 2) == '00')) {
                vrijeme = vrijeme + (this.zahtjevModel.potrosenoVrijeme.substr(brojCifaraDani + 7, 2) + 's');
            }
            if (vrijeme == '') vrijeme = "-";

            this.zahtjevModel.potrosenoVrijeme = vrijeme;
        },
        zatvoriDialogEditZahtjev: function zatvoriDialogEditZahtjev(azuriran) {
            if (azuriran) {
                this.azuriran = azuriran;
                this.ucitajZahtjev();
            }
            this.dialogEditZahtjeva = false;
        },
        zatvoriDialogPregledZahtjev: function zatvoriDialogPregledZahtjev() {
            this.azuriraniZahtjev = this.zahtjevModel;
            this.$emit("azuriraniZahtjev", this.azuriraniZahtjev, this.azuriran);
        },
        vratiIzmjeneStatusaZahtjeva: function vratiIzmjeneStatusaZahtjeva(id) {
            var _this2 = this;

            var that = this;

            var success = function success(response) {
                for (var i = 0; i < response.body.length; i++) {
                    var datum = response.body[i].datumKreiranja;
                    var prilagodjeniDatum = datum.substring(8, 10) + '.' + datum.substring(5, 7) + '.' + datum.substring(0, 4) + '. ' + datum.substring(11, 19);
                }
            };
            var error = function error(poruka) {
                _this2.$toast.error(poruka.body);
            };
            var promise = (0, _resources.ZahtjevResource)().vratiIzmjeneStatusaZahtjeva({
                zahtjevId: id
            });

            promise.then(success, error);
        },
        otvoriHistorijuStatusaZahtjeva: function otvoriHistorijuStatusaZahtjeva() {
            this.dialogHistorijaStatusaZahtjeva = true;
        },
        otvoriDialogBrisanjeZahtjeva: function otvoriDialogBrisanjeZahtjeva() {
            this.dialogBrisanjeZahtjeva = true;
        },
        closeModal: function closeModal(event) {
            if (event.obrisi) {
                this.brisanjeZahtjeva();
            }
            this.dialogBrisanjeZahtjeva = false;
        },
        brisanjeZahtjeva: function brisanjeZahtjeva() {
            var _this3 = this;

            var that = this;
            var success = function success(response) {
                that.$toast.success("Zahtjev uspješno izbrisan");
                that.$emit("azuriraniZahtjev", null, true);
            };
            var error = function error(poruka) {
                _this3.$toast.error(poruka.body);
            };
            var promise = (0, _resources.ZahtjevResource)().brisanjeZahtjeva({
                zahtjevId: that.zahtjevModel.id
            }, {});

            promise.then(success, error);
        },
        zatvoriDialogHistorijaStatusaZahtjeva: function zatvoriDialogHistorijaStatusaZahtjeva() {
            this.dialogHistorijaStatusaZahtjeva = false;
        },
        otvoriKorisnikoveNotifikacijeZaZahtjev: function otvoriKorisnikoveNotifikacijeZaZahtjev() {

            var that = this;
            var success = function success(response) {};
            var error = function error() {};
            var promise = (0, _resources.NotifikacijeResource)().otvoriKorisnikoveNotifikacijeZaZahtjev({
                zahtjevId: that.childZahtjevId
            }, {});

            promise.then(success, error);
        }
    },
    resolve: {}
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitanZahtjev)?[(_vm.ucitanZahtjev)?_c('v-dialog',{attrs:{"max-width":"1000px"},on:{"input":_vm.zatvoriDialogPregledZahtjev},model:{value:(_vm.ucitanZahtjev),callback:function ($$v) {_vm.ucitanZahtjev=$$v},expression:"ucitanZahtjev"}},[_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Pregled zahtjeva ")])]),_vm._v(" "),_c('v-flex',{staticClass:"text-xs-right toolbar-btn"},[_c('v-menu',{staticClass:"toolbar-menu",attrs:{"open-on-hover":"","offset-y":"","bottom":"","left":"","content-class":"dropdown-menu","transition":"slide-y-transition"}},[_c('v-icon',{attrs:{"slot":"activator"},slot:"activator"},[_vm._v("more_vert")]),_vm._v(" "),_c('v-list',[_c('v-list-tile',{on:{"click":_vm.otvoriEditZahtjeva}},[_c('v-list-tile-title',[_vm._v("Izmjena zahtjeva")])],1),_vm._v(" "),_c('v-list-tile',{on:{"click":_vm.otvoriHistorijuStatusaZahtjeva}},[_c('v-list-tile-title',[_vm._v("Pregled promjena statusa zahtjeva")])],1),_vm._v(" "),_c('v-list-tile',{on:{"click":_vm.otvoriDialogBrisanjeZahtjeva}},[_c('v-list-tile-title',[_vm._v("Brisanje zahtjeva")])],1)],1)],1)],1)],1)],1),_vm._v(" "),_c('v-card-text',[_c('p',{staticClass:"text-boldiran text-centriran"},[_vm._v("\r\n                        "+_vm._s(_vm.zahtjevModel.naziv)+"\r\n                    ")]),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('br'),_vm._v(" "),_c('pre',{staticClass:"opis-zahtjeva-text"},[_vm._v(_vm._s(_vm.zahtjevModel.opis))]),_vm._v(" "),_c('br'),_vm._v(" "),_c('v-divider'),_vm._v(" "),_c('br'),_vm._v(" "),_c('table',{staticClass:"v-table"},[_c('tbody',[_c('tr',[_c('td',[_vm._v("Status: ")]),_vm._v(" "),(_vm.zahtjevModel.zahtjevStatus.oznaka=='0')?_c('td',{staticClass:"status-to-do"},[_vm._v(_vm._s(_vm.zahtjevModel.zahtjevStatus.naziv))]):_vm._e(),_vm._v(" "),(_vm.zahtjevModel.zahtjevStatus.oznaka=='1')?_c('td',{staticClass:"status-in-progress"},[_vm._v(_vm._s(_vm.zahtjevModel.zahtjevStatus.naziv))]):_vm._e(),_vm._v(" "),(_vm.zahtjevModel.zahtjevStatus.oznaka=='2')?_c('td',{staticClass:"status-done"},[_vm._v(_vm._s(_vm.zahtjevModel.zahtjevStatus.naziv))]):_vm._e()]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Dio projekta: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.dioProjekta))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Kategorija: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.zahtjevKategorija))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Zahtjev kreirao: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.createdBy))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Datum kreiranja: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.datumKreiranja.substring(8,10) + '. ' + _vm.zahtjevModel.datumKreiranja.substring(5,7)+ '. '+_vm.zahtjevModel.datumKreiranja.substring(0,4) + '. '+_vm.zahtjevModel.datumKreiranja.substring(11,19)))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Datum izmjene: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.datumIzmjene.substring(8,10) + '. ' + _vm.zahtjevModel.datumIzmjene.substring(5,7)+ '. '+_vm.zahtjevModel.datumIzmjene.substring(0,4) + '. ' +_vm.zahtjevModel.datumIzmjene.substring(11,19)))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Tip: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.zahtjevTip))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v("Prioritet: ")]),_vm._v(" "),_c('td',[_vm._v(_vm._s(_vm.zahtjevModel.zahtjevPrioritet))])]),_vm._v(" "),_c('tr',[_c('td',[_vm._v(" Potrošeno vrijeme ")]),_vm._v(" "),_c('td',[_c('v-chip',[_vm._v(_vm._s(_vm.zahtjevModel.potrosenoVrijeme))])],1)]),_vm._v(" "),_c('tr',[_c('td',[_vm._v(" Dodijeljeni korisnik ")]),_vm._v(" "),_c('td',[_c('v-chip',[_vm._v(_vm._s(_vm.zahtjevModel.dodijeljeniKorisnikIme))])],1)]),_vm._v(" "),(_vm.zahtjevModel.dokumenti.length!=0)?_c('tr',[_c('td',[_vm._v(" Prilozi zahtjeva: ")]),_vm._v(" "),_c('td',[_c('a',{on:{"click":function($event){return _vm.preuzmiDokument(_vm.zahtjevModel.dokumenti[0].id)}}},[_vm._v(" "+_vm._s(_vm.zahtjevModel.dokumenti[0].naziv)+"\r\n                                    ")])])]):_vm._e()])])],1),_vm._v(" "),_c('lista-komentara-zahtjev',{attrs:{"zahtjev-id":_vm.childZahtjevId}}),_vm._v(" "),(_vm.dialogEditZahtjeva)?_c('v-dialog',{attrs:{"max-width":"1000px"},on:{"input":_vm.zatvoriDialogPregledZahtjev},model:{value:(_vm.dialogEditZahtjeva),callback:function ($$v) {_vm.dialogEditZahtjeva=$$v},expression:"dialogEditZahtjeva"}},[_c('edit-zahtjev',{attrs:{"zahtjev-id":_vm.childZahtjevId},on:{"dialogEditZahtjeva":_vm.zatvoriDialogEditZahtjev}})],1):_vm._e(),_vm._v(" "),(_vm.dialogHistorijaStatusaZahtjeva)?_c('izmjena-zahtjeva-historija',{attrs:{"zahtjevId":_vm.zahtjevId},on:{"close":_vm.zatvoriDialogHistorijaStatusaZahtjeva}}):_vm._e(),_vm._v(" "),_c('obrisi-modal',{attrs:{"aktivan":_vm.dialogBrisanjeZahtjeva,"item":_vm.zahtjevId,"header":"Brisanje zahtjeva","body":"Jeste li sigurni da želite obrisati zahtjev?","width":"350"},on:{"close":function($event){return _vm.closeModal($event)}}})],1)],1):_vm._e()]:_vm._e(),_vm._v(" "),(_vm.activeHelpTip)?_c('help-tip-dialog',{attrs:{"title":_vm.helpTipDialogTitle,"content":_vm.helpTipDialogContent},on:{"zatvori":_vm.ZatvoriHelpDialog}}):_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("modules/home/zahtjev/status-historija/izmjena-zahtjeva-historija.vue", function(exports, require, module) {
;(function(){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _resources = require('api/resources');

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

var _helpTipDialogMixin = require('helpers/help-tip-dialog-mixin');

var _helpTipDialogMixin2 = _interopRequireDefault(_helpTipDialogMixin);

var _uploadMixin = require('helpers/upload-mixin');

var _uploadMixin2 = _interopRequireDefault(_uploadMixin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    name: 'IzmjenaZahtjevaHistorija',
    components: {},
    props: ['zahtjevId'],
    mixins: [_helpTipDialogMixin2.default, _uploadMixin2.default],
    data: function data() {
        return {
            childZahtjevId: Number(this.zahtjevId),
            activeHelpTip: false,
            resolved: null,
            identity: _identity2.default,
            ucitaneIzmjeneZahtjeva: false,
            izmjeneZahtjeva: [],
            headers: [{
                text: 'Datum promjene',
                align: 'left',
                sortable: false
            }, {
                text: 'Novi zahtjev status',
                align: 'left',
                sortable: false

            }]
        };
    },
    created: function created() {
        this.vratiIzmjeneStatusaZahtjeva(this.childZahtjevId);
    },

    methods: {
        zatvoriDialog: function zatvoriDialog() {
            this.dialogEditZahtjeva = false;

            this.$emit("close");
        },
        vratiIzmjeneStatusaZahtjeva: function vratiIzmjeneStatusaZahtjeva(id) {
            var _this = this;

            var that = this;

            var success = function success(response) {
                that.izmjeneZahtjeva = response.body;
                that.ucitaneIzmjeneZahtjeva = true;
            };
            var error = function error(poruka) {
                _this.$toast.error(poruka.body);
            };
            var promise = (0, _resources.ZahtjevResource)().vratiIzmjeneStatusaZahtjeva({
                zahtjevId: id
            });

            promise.then(success, error);
        }
    },
    resolve: {}
};
})()
if (module.exports.__esModule) module.exports = module.exports.default
var __vue__options__ = (typeof module.exports === "function"? module.exports.options: module.exports)
__vue__options__.render = function render () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page',[(_vm.ucitaneIzmjeneZahtjeva)?[(_vm.ucitaneIzmjeneZahtjeva)?_c('v-dialog',{attrs:{"max-width":"1000px"},on:{"input":_vm.zatvoriDialog},model:{value:(_vm.ucitaneIzmjeneZahtjeva),callback:function ($$v) {_vm.ucitaneIzmjeneZahtjeva=$$v},expression:"ucitaneIzmjeneZahtjeva"}},[_c('material-card',{attrs:{"color":"primary"}},[_c('v-flex',{attrs:{"slot":"header"},slot:"header"},[_c('v-layout',{attrs:{"row":"","justify-space-between":""}},[_c('v-flex',[_c('span',{staticClass:"card-naslov"},[_vm._v("Historija statusa zahtjeva ")])])],1)],1),_vm._v(" "),_c('v-card-text',[_c('v-data-table',{attrs:{"headers":_vm.headers,"hide-actions":true,"items":_vm.izmjeneZahtjeva},scopedSlots:_vm._u([{key:"items",fn:function(props){return [_c('tr',[_c('td',[_vm._v(_vm._s(props.item.datumKreiranja.substring(8,10) + '.' + props.item.datumKreiranja.substring(5,7)+ '.'+props.item.datumKreiranja.substring(0,4) + '. ' + props.item.datumKreiranja.substring(11,16)))]),_vm._v(" "),(props.item.noviZahtjevStatus.oznaka=='0')?_c('td',{staticClass:"status-to-do"},[_vm._v(_vm._s(props.item.noviZahtjevStatus.naziv))]):_vm._e(),_vm._v(" "),(props.item.noviZahtjevStatus.oznaka=='1')?_c('td',{staticClass:"status-in-progress"},[_vm._v(_vm._s(props.item.noviZahtjevStatus.naziv))]):_vm._e(),_vm._v(" "),(props.item.noviZahtjevStatus.oznaka=='2')?_c('td',{staticClass:"status-done"},[_vm._v(_vm._s(props.item.noviZahtjevStatus.naziv))]):_vm._e()])]}}],null,false,487927101)})],1)],1)],1):_vm._e()]:_vm._e()],2)}
__vue__options__.staticRenderFns = []

});

;require.register("postavke/chartist.js", function(exports, require, module) {
'use strict';

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(require('vue-chartist'));

});

require.register("postavke/index.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _resources = require('api/resources');

var _postavke = require('./postavke');

var _postavke2 = _interopRequireDefault(_postavke);

require('./chartist');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  init: function init() {
    return new _promise2.default(function (resolve) {
      var promise = (0, _resources.PostavkeResource)().get();

      promise.then(function (response) {
        _postavke2.default.setPostavke(response.body);
        resolve();
      }, function () {
        console.log("Postavke nisu učitane...");
        resolve();
      });
    });
  }
};

});

require.register("postavke/postavke.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _identity = require('auth/identity');

var _identity2 = _interopRequireDefault(_identity);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  postavke: null,

  getPostavke: function getPostavke() {
    return this.postavke;
  },
  setPostavke: function setPostavke(postavke) {
    this.postavke = postavke;
  },
  naslovSistema: function naslovSistema() {
    if (this.postavke) return this.postavke.naslovSistema;
    return 'Project Management System';
  },
  trajanjeSesije: function trajanjeSesije() {
    if (this.postavke) return this.postavke.trajanjeSesije;
    return 5;
  },
  urlKarte: function urlKarte() {
    if (this.postavke) return this.postavke.urlKarte;
    return 'http://{s}.tile.osm.org/{z}/{x}/{y}.png';
  },
  autorskaPravaKarte: function autorskaPravaKarte() {
    if (this.postavke) return this.postavke.autorskaPravaKarte;
    return '';
  }
};

});

require.register("vuex-store/index.js", function(exports, require, module) {
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = require('vue');

var _vue2 = _interopRequireDefault(_vue);

var _vuex = require('vuex');

var _vuex2 = _interopRequireDefault(_vuex);

var _vuexPersistedstate = require('vuex-persistedstate');

var _vuexPersistedstate2 = _interopRequireDefault(_vuexPersistedstate);

var _store = require('../modules/home/store');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(_vuex2.default);

exports.default = new _vuex2.default.Store({
  modules: {
    home: _store2.default
  },
  plugins: [(0, _vuexPersistedstate2.default)({
    key: 'tmsVuex'
  })]
});

});

require.alias("vue/dist/vue.common.js", "vue");
require.alias("vue-spinner/dist/vue-spinner.js", "vue-spinner");require.register("___globals___", function(exports, require, module) {
  
});})();require('___globals___');

